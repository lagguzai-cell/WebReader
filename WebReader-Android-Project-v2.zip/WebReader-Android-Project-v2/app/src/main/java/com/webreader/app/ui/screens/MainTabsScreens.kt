package com.webreader.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddLink
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.webreader.app.model.AppThemePalette
import com.webreader.app.model.MangaSeries
import com.webreader.app.model.MangaSourceSite
import com.webreader.app.ui.WebReaderUiState

@Composable
fun LibraryTabScreen(
    state: WebReaderUiState,
    onSelectCategory: (String) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onToggleUnreadOnly: () -> Unit,
    onToggleDownloadedOnly: () -> Unit,
    onOpenSeries: (String) -> Unit,
    onOpenAddWebsiteDialog: () -> Unit,
    onPickBackupFile: () -> Unit,
    onAddCategory: (String) -> Unit
) {
    var showNewCategoryDialog by remember { mutableStateOf(false) }
    var newCategoryName by remember { mutableStateOf("") }

    val favoriteSeries = state.seriesList.filter { series ->
        series.isFavorite &&
            (state.selectedCategory == "All" || series.categoryName.equals(state.selectedCategory, ignoreCase = true) ||
                (state.selectedCategory == "Completed" && series.status.equals("Completed", ignoreCase = true))) &&
            (state.librarySearchQuery.isBlank() ||
                series.title.contains(state.librarySearchQuery, ignoreCase = true) ||
                series.sourceName.contains(state.librarySearchQuery, ignoreCase = true)) &&
            (!state.unreadOnlyFilter || series.unreadCount > 0) &&
            (!state.downloadedOnlyFilter || series.downloadedCount > 0)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    text = "Your Library",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "${state.seriesList.size} series • Your reading, all in one place",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onPickBackupFile,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Import backup", maxLines = 1)
                }
                Button(
                    onClick = onOpenAddWebsiteDialog,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.AddLink, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Add website", maxLines = 1)
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = state.librarySearchQuery,
            onValueChange = onSearchQueryChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Search your library or website source...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }
        )

        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(state.categories) { cat ->
                FilterChip(
                    selected = state.selectedCategory == cat,
                    onClick = { onSelectCategory(cat) },
                    label = { Text(cat) }
                )
            }
            item {
                AssistChip(
                    onClick = { showNewCategoryDialog = true },
                    label = { Text("+ Category") }
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = state.unreadOnlyFilter,
                onClick = onToggleUnreadOnly,
                label = { Text("Unread Only") }
            )
            FilterChip(
                selected = state.downloadedOnlyFilter,
                onClick = onToggleDownloadedOnly,
                label = { Text("Downloaded Offline") }
            )
        }

        Spacer(Modifier.height(6.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 88.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(favoriteSeries, key = { it.id }) { series ->
                MangaLibraryCard(series = series, onClick = { onOpenSeries(series.id) })
            }
        }
    }

    if (showNewCategoryDialog) {
        AlertDialog(
            onDismissRequest = { showNewCategoryDialog = false },
            title = { Text("Create Library Category") },
            text = {
                OutlinedTextField(
                    value = newCategoryName,
                    onValueChange = { newCategoryName = it },
                    label = { Text("Category Name (e.g., Action Manhwa)") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onAddCategory(newCategoryName)
                        newCategoryName = ""
                        showNewCategoryDialog = false
                    }
                ) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewCategoryDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun MangaLibraryCard(
    series: MangaSeries,
    onClick: () -> Unit
) {
    val coverColor = Color(series.coverColorHex)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(155.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(coverColor, coverColor.copy(alpha = 0.65f), Color(0xFF0F172A))
                        )
                    )
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Surface(
                        color = Color(0xCC0F172A),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = series.sourceName,
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (series.unreadCount > 0) {
                            Badge(containerColor = MaterialTheme.colorScheme.primary) {
                                Text(
                                    text = "${series.unreadCount}",
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                        if (series.downloadedCount > 0) {
                            Badge(containerColor = Color(0xFF10B981)) {
                                Text(
                                    text = "DL ${series.downloadedCount}",
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }
                }

                Column(
                    modifier = Modifier.align(Alignment.BottomStart)
                ) {
                    Text(
                        text = series.title,
                        color = Color.White,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${series.chapters.size} chapters • ${series.status}",
                        color = Color(0xFFE2E8F0),
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
fun BrowseAndWebsitesTabScreen(
    state: WebReaderUiState,
    onSelectSource: (String?) -> Unit,
    onGlobalSearchChange: (String) -> Unit,
    onOpenSeries: (String) -> Unit,
    onOpenWebsiteBrowser: (String, String) -> Unit,
    onOpenAddWebsiteDialog: () -> Unit,
    onTogglePinSource: (String) -> Unit,
    onSwitchSourceMirror: (String) -> Unit
) {
    val filteredSeries = state.seriesList.filter { series ->
        (state.activeSourceFilterId == null || series.sourceId == state.activeSourceFilterId) &&
            (state.globalSearchQuery.isBlank() ||
                series.title.contains(state.globalSearchQuery, ignoreCase = true) ||
                series.genres.any { it.contains(state.globalSearchQuery, ignoreCase = true) } ||
                series.sourceName.contains(state.globalSearchQuery, ignoreCase = true))
    }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onOpenAddWebsiteDialog,
                icon = { Icon(Icons.Default.AddLink, contentDescription = null) },
                text = { Text("Add Any Website / Paste Link") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Built-In Sources & Custom Websites",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "No extension APKs needed! MangaEffect, ManhwaTop, ManhuaTop, MangaTown, MangaDex, Asura Scans & Bato.to are built right in.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            item {
                OutlinedTextField(
                    value = state.globalSearchQuery,
                    onValueChange = onGlobalSearchChange,
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("Global Search across all manga websites...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Your Websites (${state.sources.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (state.activeSourceFilterId != null) {
                        TextButton(onClick = { onSelectSource(null) }) {
                            Text("Show All Sources")
                        }
                    }
                }
            }

            items(state.sources, key = { it.id }) { source ->
                SourceWebsiteRowCard(
                    source = source,
                    isSelected = state.activeSourceFilterId == source.id,
                    onFilterClick = {
                        onSelectSource(if (state.activeSourceFilterId == source.id) null else source.id)
                    },
                    onOpenBrowser = { onOpenWebsiteBrowser(source.baseUrl, source.name) },
                    onTogglePin = { onTogglePinSource(source.id) },
                    onSwitchMirror = { onSwitchSourceMirror(source.id) }
                )
            }

            item {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = if (state.activeSourceFilterId == null)
                        "Catalogue Series (${filteredSeries.size})"
                    else
                        "Series from Selected Website (${filteredSeries.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            items(filteredSeries, key = { it.id }) { series ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenSeries(series.id) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(series.coverColorHex)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = series.sourceName.take(2).uppercase(),
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = series.title, fontWeight = FontWeight.Bold)
                            Text(
                                text = "${series.sourceName} • ${series.chapters.size} Chapters • ${series.status}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = series.genres.joinToString(" • "),
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Icon(
                            imageVector = if (series.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = null,
                            tint = if (series.isFavorite) Color(0xFFEF4444) else Color.Gray
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SourceWebsiteRowCard(
    source: MangaSourceSite,
    isSelected: Boolean,
    onFilterClick: () -> Unit,
    onOpenBrowser: () -> Unit,
    onTogglePin: () -> Unit,
    onSwitchMirror: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onFilterClick() },
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected)
                MaterialTheme.colorScheme.primaryContainer
            else
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(source.accentColorHex)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = source.name.take(2).uppercase(),
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = source.name, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(6.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = if (source.isBuiltIn) "Built-In" else "Custom Site",
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(
                    text = source.baseUrl,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${source.parserType.label} • ${source.defaultReaderMode.label}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (source.mirrors.size > 1) {
                IconButton(onClick = onSwitchMirror) {
                    Icon(Icons.Default.Sync, contentDescription = "Switch Domain Mirror")
                }
            }
            IconButton(onClick = onOpenBrowser) {
                Icon(Icons.Default.Language, contentDescription = "Open Website in Ad-Free Browser")
            }
            IconButton(onClick = onTogglePin) {
                Icon(
                    Icons.Default.PushPin,
                    contentDescription = "Pin Favorite",
                    tint = if (source.isPinnedFavorite) MaterialTheme.colorScheme.primary else Color.Gray
                )
            }
        }
    }
}

@Composable
fun UpdatesAndDownloadsTabScreen(
    state: WebReaderUiState,
    onOpenReader: (String, String) -> Unit,
    onToggleDownload: (String, String) -> Unit
) {
    val recentChapters = state.seriesList.flatMap { series ->
        series.chapters.take(2).map { ch -> series to ch }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 88.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Spacer(Modifier.height(12.dp))
            Text(
                text = "Chapter Updates & Offline Queue",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                text = "Tap any chapter to read immediately or save it offline for reading without mobile data.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        items(recentChapters, key = { (_, ch) -> ch.id }) { (series, ch) ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenReader(series.id, ch.id) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(series.coverColorHex)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${ch.number.toInt()}",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = series.title, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text(
                            text = "${ch.title} • ${series.sourceName}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "${ch.uploadDateText} • ${if (ch.isDownloaded) "Saved Offline" else "Online Stream"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (ch.isDownloaded) Color(0xFF10B981) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { onToggleDownload(series.id, ch.id) }) {
                        Icon(
                            imageVector = if (ch.isDownloaded) Icons.Default.DownloadDone else Icons.Default.CloudDownload,
                            contentDescription = "Download Chapter",
                            tint = if (ch.isDownloaded) Color(0xFF10B981) else MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryAndBookmarksTabScreen(
    state: WebReaderUiState,
    onResumeChapter: (String, String) -> Unit
) {
    val totalReadMinutes = (state.historyRecords.sumOf { it.readDurationSeconds } / 60).coerceAtLeast(1)
    val totalReadChapters = state.seriesList.sumOf { s -> s.chapters.count { it.isRead } }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 88.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Spacer(Modifier.height(12.dp))
            Text(
                text = "Reading History & Bookmarks",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${state.seriesList.count { it.isFavorite }}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text("In Library", style = MaterialTheme.typography.labelSmall)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$totalReadChapters",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text("Chapters Read", style = MaterialTheme.typography.labelSmall)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${totalReadMinutes}m",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text("Reading Time", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        if (state.bookmarks.isNotEmpty()) {
            item {
                Text(
                    text = "Saved Page Bookmarks (${state.bookmarks.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            items(state.bookmarks, key = { it.id }) { bm ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onResumeChapter(bm.mangaId, bm.chapterId) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Bookmark, contentDescription = null, tint = Color(0xFFFBBF24))
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = bm.mangaTitle, fontWeight = FontWeight.Bold)
                            Text(text = bm.note, style = MaterialTheme.typography.bodySmall)
                        }
                        Icon(Icons.Default.PlayArrow, contentDescription = "Open")
                    }
                }
            }
        }

        item {
            Text(
                text = "Recent Reading Sessions (${state.historyRecords.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(state.historyRecords, key = { it.id }) { rec ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onResumeChapter(rec.mangaId, rec.chapterId) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.History, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = rec.mangaTitle, fontWeight = FontWeight.Bold)
                        Text(
                            text = "${rec.chapterTitle} • ${rec.sourceName} (Page ${rec.pageIndex + 1})",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Button(onClick = { onResumeChapter(rec.mangaId, rec.chapterId) }) {
                        Text("Resume")
                    }
                }
            }
        }
    }
}

@Composable
fun BackupAndSettingsTabScreen(
    state: WebReaderUiState,
    onPickBackupFileToImport: () -> Unit,
    onCreateBackupFileToExport: () -> Unit,
    onLoadSampleTachiyomiBackup: () -> Unit,
    onSelectThemePalette: (AppThemePalette) -> Unit,
    onToggleAdBlocker: (Boolean) -> Unit,
    onToggleAutoMirror: (Boolean) -> Unit,
    onToggleImageProxy: (Boolean) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 88.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(12.dp))
            Text(
                text = "Tachiyomi Backup & App Settings",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Backup, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "Standard Tachiyomi (.tachibk) & Kotatsu Backup",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Import your old Tachiyomi backup (.tachibk / .proto.gz / .json) or Kotatsu (.zip) file. WebReader automatically links series to MangaEffect, ManhwaTop, ManhuaTop, MangaTown, MangaDex, Asura Scans, Bato.to, or creates custom website sources for you.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onPickBackupFileToImport,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Import Backup")
                        }
                        OutlinedButton(
                            onClick = onCreateBackupFileToExport,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Backup, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Export .tachibk")
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    TextButton(
                        onClick = onLoadSampleTachiyomiBackup,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Test Instant Demo .tachibk Restore (Adds 3 Classic Series)")
                    }
                }
            }
        }

        state.lastBackupSummary?.let { summary ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Last Backup Import Summary (${summary.formatName})",
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "• Series Restored: ${summary.importedMangaCount}\n" +
                                "• Chapters Restored: ${summary.importedChaptersCount}\n" +
                                "• Categories: ${summary.importedCategories.joinToString(", ")}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        if (summary.autoCreatedCustomSites.isNotEmpty()) {
                            Text(
                                text = "• Auto-Added Custom Sites: ${summary.autoCreatedCustomSites.joinToString(", ")}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }

        item {
            Card {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Smart Website & Network Protection",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    SettingSwitchRow(
                        title = "Built-In Ad & Pop-Up Blocker",
                        subtitle = "Blocks redirect ads and pop-ups on custom manga websites",
                        checked = state.adBlockEnabled,
                        onCheckedChange = onToggleAdBlocker
                    )
                    SettingSwitchRow(
                        title = "Auto-Switch Broken Website Mirrors",
                        subtitle = "Automatically switches between .com, .org, .to, and .net mirrors when a site changes domain",
                        checked = state.autoMirrorSwitchEnabled,
                        onCheckedChange = onToggleAutoMirror
                    )
                    SettingSwitchRow(
                        title = "Kotatsu Image Proxy Acceleration",
                        subtitle = "Routes blocked comic images through a fast proxy so pages never fail to load",
                        checked = state.imageProxyEnabled,
                        onCheckedChange = onToggleImageProxy
                    )
                }
            }
        }

        item {
            Card {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "App Color Theme",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    AppThemePalette.entries.forEach { palette ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectThemePalette(palette) }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(Color(palette.primaryHex))
                                )
                                Spacer(Modifier.width(12.dp))
                                Text(text = palette.label, fontWeight = FontWeight.Medium)
                            }
                            if (state.themePalette == palette) {
                                Text(
                                    text = "Active",
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(text = title, fontWeight = FontWeight.SemiBold)
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SeriesDetailScreen(
    series: MangaSeries,
    categories: List<String>,
    allSources: List<MangaSourceSite>,
    onBack: () -> Unit,
    onToggleFavorite: () -> Unit,
    onChangeCategory: (String) -> Unit,
    onOpenReader: (String) -> Unit,
    onToggleChapterDownload: (String) -> Unit,
    onDownloadAllUnread: () -> Unit,
    onOpenInWebView: (String, String) -> Unit,
    onMigrateToSource: (MangaSourceSite) -> Unit
) {
    var showCategoryDialog by remember { mutableStateOf(false) }
    var showSwitchSiteDialog by remember { mutableStateOf(false) }

    val firstUnreadChapter = series.chapters.lastOrNull { !it.isRead } ?: series.chapters.firstOrNull()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = series.title,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showSwitchSiteDialog = true }) {
                        Icon(Icons.Default.SwapHoriz, contentDescription = "Switch Website")
                    }
                    IconButton(onClick = { onOpenInWebView(series.mangaUrl, series.title) }) {
                        Icon(Icons.Default.Language, contentDescription = "Open Website")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 88.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .width(92.dp)
                                    .height(132.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(series.coverColorHex)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = series.sourceName,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                            Spacer(Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = series.title,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = "Author: ${series.author}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    text = "Website: ${series.sourceName} • ${series.status}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Category: ${series.categoryName}",
                                    style = MaterialTheme.typography.labelSmall
                                )
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = onToggleFavorite) {
                                        Icon(
                                            imageVector = if (series.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(Modifier.width(4.dp))
                                        Text(if (series.isFavorite) "In Library" else "Add")
                                    }
                                    OutlinedButton(onClick = { showCategoryDialog = true }) {
                                        Icon(Icons.Default.FolderSpecial, contentDescription = null, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }

                        Spacer(Modifier.height(12.dp))
                        Text(
                            text = series.description,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(Modifier.height(8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(series.genres) { genre ->
                                AssistChip(onClick = {}, label = { Text(genre) })
                            }
                        }

                        Spacer(Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (firstUnreadChapter != null) {
                                Button(
                                    onClick = { onOpenReader(firstUnreadChapter.id) },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Read ${firstUnreadChapter.title}")
                                }
                            }
                            OutlinedButton(onClick = onDownloadAllUnread) {
                                Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("DL Unread")
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = "Chapters (${series.chapters.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            items(series.chapters, key = { it.id }) { ch ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenReader(ch.id) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (ch.isRead)
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                        else
                            MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = ch.title,
                                fontWeight = if (ch.isRead) FontWeight.Normal else FontWeight.Bold,
                                color = if (ch.isRead) Color.Gray else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${ch.uploadDateText} • ${ch.scanlator}" +
                                    if (ch.lastPageRead > 0 && !ch.isRead) " • Page ${ch.lastPageRead + 1}" else "",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray
                            )
                        }
                        IconButton(onClick = { onToggleChapterDownload(ch.id) }) {
                            Icon(
                                imageVector = if (ch.isDownloaded) Icons.Default.DownloadDone else Icons.Default.CloudDownload,
                                contentDescription = "Download Chapter",
                                tint = if (ch.isDownloaded) Color(0xFF10B981) else MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }

    if (showCategoryDialog) {
        AlertDialog(
            onDismissRequest = { showCategoryDialog = false },
            title = { Text("Select Library Category") },
            text = {
                Column {
                    categories.forEach { cat ->
                        TextButton(
                            onClick = {
                                onChangeCategory(cat)
                                showCategoryDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(cat)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCategoryDialog = false }) { Text("Close") }
            }
        )
    }

    if (showSwitchSiteDialog) {
        AlertDialog(
            onDismissRequest = { showSwitchSiteDialog = false },
            title = { Text("Switch Website Source") },
            text = {
                LazyColumn(modifier = Modifier.height(240.dp)) {
                    items(allSources) { site ->
                        TextButton(
                            onClick = {
                                onMigrateToSource(site)
                                showSwitchSiteDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("${site.name} (${site.baseUrl})")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSwitchSiteDialog = false }) { Text("Cancel") }
            }
        )
    }
}
