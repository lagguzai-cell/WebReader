package com.webreader.app.ui.screens

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.widget.ImageView
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.webreader.app.data.SourceCatalogEngine
import com.webreader.app.model.ChapterItem
import com.webreader.app.model.ColorFilterPreset
import com.webreader.app.model.MangaSeries
import com.webreader.app.model.MangaSourceSite
import com.webreader.app.model.PageBookmark
import com.webreader.app.model.ReaderMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnifiedReaderScreen(
    series: MangaSeries,
    chapter: ChapterItem,
    allSources: List<MangaSourceSite>,
    bookmarks: List<PageBookmark>,
    colorFilterPreset: ColorFilterPreset,
    onBack: () -> Unit,
    onSelectChapter: (String) -> Unit,
    onMarkReadProgress: (String, Boolean, Int) -> Unit,
    onTogglePageBookmark: (Int) -> Unit,
    onChangeReaderMode: (ReaderMode) -> Unit,
    onChangeColorFilter: (ColorFilterPreset) -> Unit,
    onSwitchSource: (MangaSourceSite) -> Unit,
    onOpenInWebView: (String, String) -> Unit
) {
    val effectiveMode = remember(series.preferredReaderMode, series.sourceId) {
        if (series.preferredReaderMode != ReaderMode.AUTO) {
            series.preferredReaderMode
        } else {
            val isWebtoonSource = series.sourceId in setOf("manhwatop", "manhuatop", "asurascans", "batoto") ||
                series.genres.any { it.contains("Manhwa", true) || it.contains("Manhua", true) || it.contains("Webtoon", true) }
            if (isWebtoonSource) ReaderMode.WEBTOON else ReaderMode.LEFT_TO_RIGHT
        }
    }

    val totalPages = chapter.pageUrls.size.coerceAtLeast(1)
    var currentPage by remember(chapter.id) { mutableIntStateOf(chapter.lastPageRead.coerceIn(0, totalPages - 1)) }
    var showHudBars by remember { mutableStateOf(true) }
    var showSettingsSheet by remember { mutableStateOf(false) }
    var showThumbnailsSheet by remember { mutableStateOf(false) }
    var showSwitchSiteSheet by remember { mutableStateOf(false) }
    var showTapGridOverlay by remember { mutableStateOf(false) }

    val webtoonListState = rememberLazyListState(initialFirstVisibleItemIndex = currentPage)
    val coroutineScope = rememberCoroutineScope()

    val isCurrentPageBookmarked = bookmarks.any {
        it.chapterId == chapter.id && it.pageIndex == currentPage
    }

    val chapterIndex = series.chapters.indexOfFirst { it.id == chapter.id }
    val nextChapter = if (chapterIndex > 0) series.chapters[chapterIndex - 1] else null
    val prevChapter = if (chapterIndex >= 0 && chapterIndex < series.chapters.lastIndex) series.chapters[chapterIndex + 1] else null

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF090D16))
            .pointerInput(effectiveMode, currentPage, totalPages) {
                detectTapGestures { offset ->
                    val width = size.width.toFloat().coerceAtLeast(1f)
                    val xRatio = offset.x / width
                    when {
                        xRatio < 0.30f -> {
                            val target = if (effectiveMode == ReaderMode.RIGHT_TO_LEFT) {
                                (currentPage + 1).coerceAtMost(totalPages - 1)
                            } else {
                                (currentPage - 1).coerceAtLeast(0)
                            }
                            currentPage = target
                            onMarkReadProgress(chapter.id, target == totalPages - 1, target)
                            if (effectiveMode == ReaderMode.WEBTOON) {
                                coroutineScope.launch { webtoonListState.animateScrollToItem(target) }
                            }
                        }
                        xRatio > 0.70f -> {
                            val target = if (effectiveMode == ReaderMode.RIGHT_TO_LEFT) {
                                (currentPage - 1).coerceAtLeast(0)
                            } else {
                                (currentPage + 1).coerceAtMost(totalPages - 1)
                            }
                            currentPage = target
                            onMarkReadProgress(chapter.id, target == totalPages - 1, target)
                            if (effectiveMode == ReaderMode.WEBTOON) {
                                coroutineScope.launch { webtoonListState.animateScrollToItem(target) }
                            }
                        }
                        else -> showHudBars = !showHudBars
                    }
                }
            }
    ) {
        if (effectiveMode == ReaderMode.WEBTOON) {
            LazyColumn(
                state = webtoonListState,
                modifier = Modifier.fillMaxSize()
            ) {
                itemsIndexed((0 until totalPages).toList()) { pageIdx, _ ->
                    ComicPanelCanvas(
                        series = series,
                        chapter = chapter,
                        pageIndex = pageIdx,
                        totalPages = totalPages,
                        isWebtoonStrip = true,
                        onOpenChapterWebsite = { onOpenInWebView(chapter.url, "${series.title} - ${chapter.title}") }
                    )
                }
                item {
                    ChapterTransitionFooter(
                        currentChapter = chapter,
                        nextChapter = nextChapter,
                        onLoadNext = {
                            onMarkReadProgress(chapter.id, true, totalPages - 1)
                            if (nextChapter != null) onSelectChapter(nextChapter.id)
                        }
                    )
                }
            }
        } else if (effectiveMode == ReaderMode.DOUBLE_PAGE) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    ComicPanelCanvas(
                        series = series,
                        chapter = chapter,
                        pageIndex = currentPage,
                        totalPages = totalPages,
                        isWebtoonStrip = false,
                        onOpenChapterWebsite = { onOpenInWebView(chapter.url, "${series.title} - ${chapter.title}") }
                    )
                }
                Box(modifier = Modifier.weight(1f)) {
                    val secondPage = (currentPage + 1).coerceAtMost(totalPages - 1)
                    ComicPanelCanvas(
                        series = series,
                        chapter = chapter,
                        pageIndex = secondPage,
                        totalPages = totalPages,
                        isWebtoonStrip = false,
                        onOpenChapterWebsite = { onOpenInWebView(chapter.url, "${series.title} - ${chapter.title}") }
                    )
                }
            }
        } else {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                ComicPanelCanvas(
                    series = series,
                    chapter = chapter,
                    pageIndex = currentPage,
                    totalPages = totalPages,
                    isWebtoonStrip = false,
                    onOpenChapterWebsite = { onOpenInWebView(chapter.url, "${series.title} - ${chapter.title}") }
                )
            }
        }

        // Color filter overlay
        when (colorFilterPreset) {
            ColorFilterPreset.WARM_NIGHT -> Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x38F59E0B))
            )
            ColorFilterPreset.DIM_DARK -> Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x55000000))
            )
            ColorFilterPreset.GRAYSCALE -> Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x2864748B))
            )
            ColorFilterPreset.NONE -> Unit
        }

        // Optional 3x3 Tap Grid Guide Overlay (Kotatsu style)
        if (showTapGridOverlay) {
            TapGridGuideOverlay(onDismiss = { showTapGridOverlay = false })
        }

        // Top & Bottom Reader HUD Bars
        if (showHudBars) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = series.title,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.titleSmall,
                                color = Color.White
                            )
                            Text(
                                text = "${chapter.title} • ${series.sourceName} (${effectiveMode.label})",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                    },
                    actions = {
                        IconButton(onClick = { onTogglePageBookmark(currentPage) }) {
                            Icon(
                                imageVector = if (isCurrentPageBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                contentDescription = "Bookmark Page",
                                tint = if (isCurrentPageBookmarked) Color(0xFFFBBF24) else Color.White
                            )
                        }
                        IconButton(onClick = { showSwitchSiteSheet = true }) {
                            Icon(Icons.Default.SwapHoriz, contentDescription = "Switch Website", tint = Color.White)
                        }
                        IconButton(onClick = { onOpenInWebView(chapter.url, "${series.title} - ${chapter.title}") }) {
                            Icon(Icons.Default.Language, contentDescription = "Open in WebView", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xE60F172A)
                    )
                )

                Surface(
                    color = Color(0xE60F172A),
                    tonalElevation = 8.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            IconButton(
                                enabled = prevChapter != null,
                                onClick = { prevChapter?.let { onSelectChapter(it.id) } }
                            ) {
                                Icon(
                                    Icons.Default.SkipPrevious,
                                    contentDescription = "Previous Chapter",
                                    tint = if (prevChapter != null) Color.White else Color.Gray
                                )
                            }

                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Page ${currentPage + 1} of $totalPages",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White
                                )
                                Slider(
                                    value = currentPage.toFloat(),
                                    onValueChange = { newVal ->
                                        val target = newVal.toInt().coerceIn(0, totalPages - 1)
                                        currentPage = target
                                        onMarkReadProgress(chapter.id, target == totalPages - 1, target)
                                        if (effectiveMode == ReaderMode.WEBTOON) {
                                            coroutineScope.launch { webtoonListState.scrollToItem(target) }
                                        }
                                    },
                                    valueRange = 0f..(totalPages - 1).toFloat(),
                                    steps = (totalPages - 2).coerceAtLeast(0)
                                )
                            }

                            IconButton(
                                enabled = nextChapter != null,
                                onClick = {
                                    onMarkReadProgress(chapter.id, true, totalPages - 1)
                                    nextChapter?.let { onSelectChapter(it.id) }
                                }
                            ) {
                                Icon(
                                    Icons.Default.SkipNext,
                                    contentDescription = "Next Chapter",
                                    tint = if (nextChapter != null) Color.White else Color.Gray
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            OutlinedButton(onClick = { showThumbnailsSheet = true }) {
                                Icon(Icons.Default.ViewAgenda, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Pages & Chapters", fontSize = 12.sp, color = Color.White)
                            }
                            OutlinedButton(onClick = { showTapGridOverlay = !showTapGridOverlay }) {
                                Icon(Icons.Default.GridOn, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("3x3 Tap Grid", fontSize = 12.sp, color = Color.White)
                            }
                            OutlinedButton(onClick = { showSettingsSheet = true }) {
                                Icon(Icons.Default.Palette, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Reader Mode", fontSize = 12.sp, color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }

    // Kotatsu-style Page Thumbnails & Chapter Switcher Sheet
    if (showThumbnailsSheet) {
        ModalBottomSheet(onDismissRequest = { showThumbnailsSheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "Page Scrubber (${chapter.title})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(10.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    itemsIndexed((0 until totalPages).toList()) { idx, _ ->
                        val selected = idx == currentPage
                        Card(
                            modifier = Modifier
                                .width(84.dp)
                                .height(118.dp)
                                .clickable {
                                    currentPage = idx
                                    if (effectiveMode == ReaderMode.WEBTOON) {
                                        coroutineScope.launch { webtoonListState.scrollToItem(idx) }
                                    }
                                    showThumbnailsSheet = false
                                }
                                .border(
                                    width = if (selected) 2.dp else 1.dp,
                                    color = if (selected) MaterialTheme.colorScheme.primary else Color.Gray,
                                    shape = RoundedCornerShape(10.dp)
                                ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color(series.coverColorHex).copy(alpha = 0.22f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "P.${idx + 1}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text(
                    text = "Quick Chapter Switcher",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(modifier = Modifier.height(200.dp)) {
                    itemsIndexed(series.chapters.take(25)) { _, ch ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showThumbnailsSheet = false
                                    onSelectChapter(ch.id)
                                }
                                .padding(vertical = 10.dp, horizontal = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = ch.title,
                                fontWeight = if (ch.id == chapter.id) FontWeight.Bold else FontWeight.Normal,
                                color = if (ch.id == chapter.id) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (ch.isRead) "Read" else ch.uploadDateText,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    // Reader Mode & Color Filter Sheet
    if (showSettingsSheet) {
        ModalBottomSheet(onDismissRequest = { showSettingsSheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "Reader Mode & Eye-Care Filter",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(12.dp))
                ReaderMode.entries.forEach { mode ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { onChangeReaderMode(mode) },
                        colors = CardDefaults.cardColors(
                            containerColor = if (series.preferredReaderMode == mode)
                                MaterialTheme.colorScheme.primaryContainer
                            else
                                MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(text = mode.label, fontWeight = FontWeight.SemiBold)
                            Text(text = mode.description, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(text = "Color Filter", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(ColorFilterPreset.entries) { _, preset ->
                        FilterChip(
                            selected = colorFilterPreset == preset,
                            onClick = { onChangeColorFilter(preset) },
                            label = { Text(preset.label) }
                        )
                    }
                }
                Spacer(Modifier.height(20.dp))
            }
        }
    }

    // One-Tap "Switch Site" (Alternatives / Migration) Sheet
    if (showSwitchSiteSheet) {
        ModalBottomSheet(onDismissRequest = { showSwitchSiteSheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "Switch Website for '${series.title}'",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "If ${series.sourceName} is slow or missing chapters, tap any built-in or custom website below to switch instantly while keeping your read chapters.",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(12.dp))
                LazyColumn(modifier = Modifier.height(260.dp)) {
                    itemsIndexed(allSources) { _, site ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable {
                                    onSwitchSource(site)
                                    showSwitchSiteSheet = false
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = site.name, fontWeight = FontWeight.Bold)
                                    Text(text = site.baseUrl, style = MaterialTheme.typography.bodySmall)
                                }
                                Text(
                                    text = if (site.id == series.sourceId) "Current" else "Switch",
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun ComicPanelCanvas(
    series: MangaSeries,
    chapter: ChapterItem,
    pageIndex: Int,
    totalPages: Int,
    isWebtoonStrip: Boolean,
    onOpenChapterWebsite: () -> Unit
) {
    val pageUrl = chapter.pageUrls.getOrNull(pageIndex)?.takeIf { it.startsWith("https://") || it.startsWith("http://") }
    var bitmap by remember(pageUrl) { mutableStateOf<Bitmap?>(null) }
    var loadError by remember(pageUrl) { mutableStateOf(pageUrl == null) }

    LaunchedEffect(pageUrl) {
        bitmap = null
        loadError = pageUrl == null
        if (pageUrl != null) {
            val loaded = withContext(Dispatchers.IO) {
                runCatching {
                    val connection = java.net.URL(pageUrl).openConnection() as java.net.HttpURLConnection
                    connection.connectTimeout = 12_000
                    connection.readTimeout = 15_000
                    connection.instanceFollowRedirects = true
                    connection.setRequestProperty(
                        "User-Agent",
                        "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 Chrome/124.0.0.0 Mobile Safari/537.36"
                    )
                    connection.setRequestProperty("Referer", chapter.url)
                    connection.connect()
                    if (connection.responseCode !in 200..299) {
                        connection.disconnect()
                        null
                    } else {
                        connection.inputStream.use { BitmapFactory.decodeStream(it) }.also {
                            connection.disconnect()
                        }
                    }
                }.getOrNull()
            }
            bitmap = loaded
            loadError = loaded == null
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(if (isWebtoonStrip) 520.dp else 580.dp)
            .padding(horizontal = if (isWebtoonStrip) 0.dp else 12.dp, vertical = if (isWebtoonStrip) 2.dp else 12.dp)
            .clip(if (isWebtoonStrip) RoundedCornerShape(0.dp) else RoundedCornerShape(12.dp))
            .background(Color(0xFF090D16)),
        contentAlignment = Alignment.Center
    ) {
        when {
            bitmap != null -> {
                AndroidView(
                    factory = { context ->
                        ImageView(context).apply {
                            scaleType = ImageView.ScaleType.FIT_CENTER
                            adjustViewBounds = true
                            setBackgroundColor(android.graphics.Color.BLACK)
                        }
                    },
                    update = { view ->
                        if (view.tag != pageUrl) {
                            view.setImageBitmap(bitmap)
                            view.tag = pageUrl
                        } else if (view.drawable == null) {
                            view.setImageBitmap(bitmap)
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
            loadError -> {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = null,
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = "Page image unavailable",
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = if (pageUrl == null) {
                            "This chapter has no extracted image URLs yet. Open the chapter website to load its reader."
                        } else {
                            "The source rejected the image request or returned an unsupported format. Open the chapter website to continue."
                        },
                        color = Color(0xFFB6C2D2),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onOpenChapterWebsite) {
                        Icon(Icons.Default.Language, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Open chapter website")
                    }
                    Text(
                        text = "${pageIndex + 1} / $totalPages",
                        color = Color(0xFF94A3B8),
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 12.dp)
                    )
                }
            }
            else -> {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    androidx.compose.material3.CircularProgressIndicator(color = Color(0xFF8B8AFB))
                    Spacer(Modifier.height(12.dp))
                    Text("Loading page ${pageIndex + 1}…", color = Color(0xFFB6C2D2))
                }
            }
        }
    }
}

@Composable
private fun ChapterTransitionFooter(
    currentChapter: ChapterItem,
    nextChapter: ChapterItem?,
    onLoadNext: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Finished ${currentChapter.title}",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(8.dp))
            if (nextChapter != null) {
                Text(
                    text = "Up Next: ${nextChapter.title}",
                    color = Color(0xFF94A3B8),
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = onLoadNext) {
                    Text("Continue to ${nextChapter.title}")
                }
            } else {
                Text(
                    text = "You've reached the latest available chapter!",
                    color = Color(0xFF34D399),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Composable
private fun TapGridGuideOverlay(onDismiss: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xAA000000))
            .clickable { onDismiss() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            val labels = listOf(
                listOf("Prev Page", "Prev Page", "Next Page"),
                listOf("Prev Page", "Toggle Menu\n(Tap to close guide)", "Next Page"),
                listOf("Prev Page", "Next Page", "Next Page")
            )
            labels.forEach { rowLabels ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    rowLabels.forEach { text ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxSize()
                                .padding(vertical = 4.dp)
                                .border(2.dp, Color(0xFF38BDF8), RoundedCornerShape(12.dp))
                                .background(Color(0x551E293B), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = text,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Built-in Ad-Blocking WebView & Smart Image Extractor for Bato.to, MangaEffect,
 * ManhwaTop, ManhuaTop, MangaTown, or any user-added manga website.
 */
@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun AdFreeWebViewScreen(
    initialUrl: String,
    title: String,
    adBlockEnabled: Boolean,
    onClose: () -> Unit,
    onSaveSiteToCatalog: (String, String) -> Unit,
    onExtractImagesToReader: (String, String, List<String>) -> Unit
) {
    var currentUrl by remember { mutableStateOf(initialUrl) }
    var currentTitle by remember { mutableStateOf(title) }
    var isLoading by remember { mutableStateOf(true) }
    var blockedAdsCount by remember { mutableIntStateOf(0) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = currentTitle.ifBlank { "Built-In Manga Browser" },
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = "$currentUrl • $blockedAdsCount ads blocked",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Close Browser")
                    }
                }
            )
        },
        bottomBar = {
            BottomAppBar {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { onSaveSiteToCatalog(currentTitle, currentUrl) }
                    ) {
                        Text("Save Website to App")
                    }
                    Button(
                        onClick = {
                            val wv = webViewRef
                            if (wv != null) {
                                wv.evaluateJavascript(
                                    """
                                    (function() {
                                        var imgs = Array.from(document.querySelectorAll('img'));
                                        var urls = imgs.map(function(i) {
                                            return i.getAttribute('data-src') || i.getAttribute('data-lazy-src') || i.src || '';
                                        }).filter(function(u) {
                                            return u.indexOf('http') === 0 && (u.width === undefined || true);
                                        });
                                        return JSON.stringify(urls.slice(0, 60));
                                    })();
                                    """.trimIndent()
                                ) { rawJson ->
                                    val cleaned = rawJson
                                        ?.trim()
                                        ?.removeSurrounding("\"")
                                        ?.replace("\\\"", "\"")
                                        ?: "[]"
                                    val urls = Regex("""https?://[^"',\]]+""")
                                        .findAll(cleaned)
                                        .map { it.value }
                                        .filter { !SourceCatalogEngine.isAdUrl(it) }
                                        .distinct()
                                        .toList()
                                    val finalList = urls.ifEmpty {
                                        (1..12).map { p -> "$currentUrl/page-$p.jpg" }
                                    }
                                    onExtractImagesToReader(currentTitle, currentUrl, finalList)
                                }
                            }
                        }
                    ) {
                        Text("Extract to Reader")
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (isLoading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.loadsImagesAutomatically = true
                        settings.userAgentString =
                            "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

                        webViewClient = object : WebViewClient() {
                            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                isLoading = true
                                if (!url.isNullOrBlank()) currentUrl = url
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                isLoading = false
                                if (!url.isNullOrBlank()) currentUrl = url
                                view?.title?.takeIf { it.isNotBlank() }?.let { currentTitle = it }
                            }

                            override fun shouldInterceptRequest(
                                view: WebView?,
                                request: WebResourceRequest?
                            ): WebResourceResponse? {
                                val reqUrl = request?.url?.toString().orEmpty()
                                if (adBlockEnabled && SourceCatalogEngine.isAdUrl(reqUrl)) {
                                    blockedAdsCount++
                                    return WebResourceResponse(
                                        "text/plain",
                                        "UTF-8",
                                        ByteArrayInputStream(ByteArray(0))
                                    )
                                }
                                return super.shouldInterceptRequest(view, request)
                            }
                        }
                        loadUrl(initialUrl)
                        webViewRef = this
                    }
                }
            )
        }
    }
}
