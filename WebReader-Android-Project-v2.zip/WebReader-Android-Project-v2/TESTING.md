# WebReader QA notes

## What was changed in this repair pass

- Replaced the decorative, fake comic-panel canvas with an image-loading view that requests the actual chapter image URL.
- Added network timeouts, a mobile browser User-Agent, and a chapter Referer header for common hotlink-protection cases.
- Added an honest unavailable-image state and an **Open chapter website** action instead of presenting drawn placeholders as manga pages.
- Removed fabricated image URLs from the built-in sample catalogue. Sample entries now show the unavailable-image state until real page URLs are extracted.
- Reduced the minimum reader page count from 12 to 1, so an empty page list no longer pretends that 12 pages exist.
- Reworked the Library header actions into a phone-friendly stacked layout.
- Added a GitHub Actions workflow that installs Android SDK/Gradle, runs the unit-test task and builds a debug APK.

## Verification performed in this repair pass

- ZIP structure and source files inspected.
- Static checks are run before packaging; see `QA-RESULTS.md`.
- A real Gradle build and emulator/device run cannot be performed in this execution environment because Gradle is not installed, the archive omitted the wrapper, and outbound network/DNS is unavailable. Use the included GitHub Actions workflow to perform the real build in GitHub.

## Manual black-box test plan

1. Install the built debug APK on Android 8+.
2. Launch the app; verify all five bottom tabs render and remain usable.
3. In Library, verify Import backup and Add website fit on a narrow phone screen without horizontal clipping.
4. Add a reachable manga/chapter URL and confirm the loading/status message is understandable.
5. Open a chapter with extracted direct image URLs; confirm a real image is rendered and page navigation updates the page counter.
6. Open a chapter with no image URLs; confirm a clear fallback is shown and **Open chapter website** opens the chapter in WebView.
7. Test a blocked/404 image; confirm the app shows a fallback rather than a fake panel or crash.
8. Test page bookmark, chapter progress, previous/next chapter, reader mode, and returning to Library.
9. Import a valid backup, inspect the resulting library, then export and verify a non-empty backup file.
10. Test airplane mode and a slow connection; verify failures are surfaced and the app remains navigable.
11. Repeat launch and navigation after force-stop to check persisted preferences and reading progress.

## Scope and limitations

The build workflow validates compilation and the configured unit-test task, but the manual tests above still need to be run on a real emulator or device. Website availability, anti-bot rules, and each site's HTML structure can change independently; one successful build does not guarantee every source parser works.
