# WebReader v2.0 — 64-Bit Native Android Manga & Webtoon Reader

**WebReader v2.0** (`com.webreader.app`) is a completely rebuilt 64-bit Android app combining **Tachiyomi's** 3-column cover grid, reader, and `.tachibk` backup engine with **Kotatsu's** live website scrapers and `wsrv.nl` image proxy.

## What's New in v2.0

1. **Real Cover Art & Real Comic Page Bitmap Loader (`NetworkBitmapImage.kt`)**:
   - Decodes real JPG/PNG/WebP manga covers and chapter pages using `BitmapFactory` + memory `LruCache` + persistent disk caching.
   - Automatically sends `Referer` and mobile `User-Agent` headers and falls back to Kotatsu's `https://wsrv.nl` image proxy when a site blocks direct image hotlinking.
2. **Real Live Website Scrapers (`SourceCatalogEngine.kt`)**:
   - **MangaDex Official REST API v5**: Fetches live popular titles, search results, cover images, English chapter feeds, and `/at-home/server/` page images.
   - **Madara WordPress Engine (`MangaEffect`, `ManhwaTop`, `ManhuaTop`)**: Scrapes live series cards, AJAX chapter lists (`/ajax/chapters/`), and `.wp-manga-chapter-img` comic strips.
   - **MangaTown, Asura Scans & Bato.to**: Scrapes live directories, search queries, and `imgHttps` / reader page images.
   - **Integrated Clean Reader WebView Mode**: One-tap toggle in the reader and series screen that loads any Cloudflare-protected or dynamic JS manga website with pop-up ads and headers stripped out, while syncing Cloudflare cookies automatically.
3. **3-Column Cover Grid & Zoomable 1x–4x Reader**:
   - Comfortable 3-column portrait cover grid with gradient title scrims and unread badges.
   - Pinch-to-zoom (1x to 4x) and double-tap zoom in both Continuous Webtoon Scroll and Left-to-Right / Right-to-Left Pager modes.
