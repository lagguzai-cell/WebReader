package com.webreader.app

import com.webreader.app.data.SourceCatalogEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class WebReaderInstrumentedTest {

    @Test
    fun builtInSources_includeAllSevenRequestedSites() {
        val ids = SourceCatalogEngine.defaultBuiltInSources.map { it.id }.toSet()
        assertEquals(7, ids.size)
        assertTrue(ids.containsAll(listOf("mangadex", "mangaeffect", "manhwatop", "manhuatop", "mangatown", "asurascans", "batoto")))
    }
}
