package com.webreader.app

import com.webreader.app.data.SourceCatalogEngine
import com.webreader.app.data.TachiyomiBackupEngine
import com.webreader.app.model.ChapterItem
import com.webreader.app.model.MangaSeries
import com.webreader.app.model.ReaderMode
import com.webreader.app.ui.WebReaderUiState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Automated Unit Test Suite for WebReader v2.1.0:
 * - Verifies all 7 built-in sources (MangaDex, MangaEffect, ManhwaTop, ManhuaTop, MangaTown, Asura Scans, Bato.to)
 * - Verifies Madara & Bato.to HTML chapter/image scraping regexes
 * - Verifies standard Tachiyomi Protobuf (.tachibk / .proto.gz) round-trip export & import
 * - Verifies separation of Saved Library membership (isSavedInLibrary) from Favorites (isFavorite),
 *   including empty Saved Library state vs. Starter Catalog state
 * - Verifies custom website URL normalization and ad-blocker domain filtering
 */
class ScraperAndBackupUnitTest {

    @Test
    fun builtInSources_includeAllSevenRequestedSites() {
        val ids = SourceCatalogEngine.defaultBuiltInSources.map { it.id }.toSet()
        assertTrue(ids.contains("mangadex"))
        assertTrue(ids.contains("mangaeffect"))
        assertTrue(ids.contains("manhwatop"))
        assertTrue(ids.contains("manhuatop"))
        assertTrue(ids.contains("mangatown"))
        assertTrue(ids.contains("asurascans"))
        assertTrue(ids.contains("batoto"))
        assertEquals(7, ids.size)
    }

    @Test
    fun savedSeriesAndFavorites_areIndependentlyFilteredAndEmptySavedLibraryDoesNotLeakStarterCatalog() {
        // 1. When savedLibrarySeries is empty and showStarterCatalog is false (Saved tab),
        // displayedLibrarySeries must be empty so the empty-library UI state renders.
        val emptySavedState = WebReaderUiState(
            savedLibrarySeries = emptyList(),
            showStarterCatalog = false,
            favoritesOnlyFilter = false
        )
        assertTrue(emptySavedState.displayedLibrarySeries.isEmpty())

        // 2. When showStarterCatalog is true (All Catalog tab), starter titles are displayed.
        val starterCatalogState = emptySavedState.copy(showStarterCatalog = true)
        assertTrue(starterCatalogState.displayedLibrarySeries.isNotEmpty())

        // 3. Ordinary saved series (isSavedInLibrary = true, isFavorite = false) remain accessible
        // alongside starred favorites (isSavedInLibrary = true, isFavorite = true).
        val ordinarySavedSeries = MangaSeries(
            id = "saved_ordinary_1",
            sourceId = "mangaeffect",
            sourceName = "MangaEffect",
            title = "Lightning Degree",
            author = "Aolhoti",
            description = "Saved in library, not starred as favorite",
            mangaUrl = "https://mangaeffect.com/manga/lightning-degree/",
            coverUrl = "https://mangaeffect.com/cover1.jpg",
            isSavedInLibrary = true,
            isFavorite = false
        )
        val starredFavoriteSeries = MangaSeries(
            id = "saved_fav_2",
            sourceId = "manhwatop",
            sourceName = "ManhwaTop",
            title = "Solo Leveling",
            author = "Chugong",
            description = "Saved in library and starred as favorite",
            mangaUrl = "https://manhwatop.com/manhwa/solo-leveling/",
            coverUrl = "https://manhwatop.com/cover2.jpg",
            isSavedInLibrary = true,
            isFavorite = true
        )

        val savedViewState = WebReaderUiState(
            savedLibrarySeries = listOf(ordinarySavedSeries, starredFavoriteSeries),
            showStarterCatalog = false,
            favoritesOnlyFilter = false
        )
        assertEquals(2, savedViewState.displayedLibrarySeries.size)

        // 4. Enabling Favorites Only filters to starred favorites without deleting ordinary saved series
        val favoritesOnlyState = savedViewState.copy(favoritesOnlyFilter = true)
        assertEquals(1, favoritesOnlyState.displayedLibrarySeries.size)
        assertEquals("Solo Leveling", favoritesOnlyState.displayedLibrarySeries.first().title)
        assertEquals(2, favoritesOnlyState.savedLibrarySeries.size)
    }

    @Test
    fun extractComicImagesFromHtml_extractsMadaraAndBatotoImagesAndBlocksAds() {
        val sampleHtml = """
            <html>
            <body>
                <div class="reading-content">
                    <img class="wp-manga-chapter-img" data-src="https://manhwatop.com/wp-content/uploads/ch1/001.jpg" />
                    <img class="wp-manga-chapter-img" data-lazy-src="https://mangaeffect.com/wp-content/uploads/ch1/002.webp" />
                    <img src="https://doubleclick.net/ads/banner.jpg" />
                </div>
                <script>
                    const imgHttps = ["https://n01.mbxma.org/media/mbch/003.png", "https://popads.net/ad.jpg"];
                </script>
            </body>
            </html>
        """.trimIndent()

        val extracted = SourceCatalogEngine.extractComicImagesFromHtml(sampleHtml, "https://manhwatop.com/ch-1")
        assertEquals(3, extracted.size)
        assertTrue(extracted.any { it.endsWith("001.jpg") })
        assertTrue(extracted.any { it.endsWith("002.webp") })
        assertTrue(extracted.any { it.endsWith("003.png") })
        assertFalse(extracted.any { it.contains("doubleclick") || it.contains("popads") })
    }

    @Test
    fun tachiyomiBackup_roundTripExportAndImportPreservesSeriesChaptersAndSavedVsFavoriteFlags() {
        val sampleSeries = listOf(
            MangaSeries(
                id = "test_solo",
                sourceId = "manhwatop",
                sourceName = "ManhwaTop",
                title = "Solo Leveling",
                author = "Chugong",
                description = "Test backup description",
                status = "Completed",
                genres = listOf("Manhwa", "Action"),
                mangaUrl = "https://manhwatop.com/manhwa/solo-leveling/",
                coverUrl = "https://manhwatop.com/covers/solo.jpg",
                isSavedInLibrary = true,
                isFavorite = true,
                categoryName = "Manhwa & Webtoons",
                preferredReaderMode = ReaderMode.WEBTOON,
                chapters = listOf(
                    ChapterItem(
                        id = "ch_1",
                        mangaId = "test_solo",
                        title = "Chapter 1",
                        number = 1f,
                        url = "https://manhwatop.com/manhwa/solo-leveling/chapter-1/",
                        isRead = true,
                        lastPageRead = 14
                    )
                )
            ),
            MangaSeries(
                id = "test_non_fav_saved",
                sourceId = "mangaeffect",
                sourceName = "MangaEffect",
                title = "Lightning Degree",
                author = "Aolhoti",
                description = "Saved but not favorite",
                status = "Ongoing",
                genres = listOf("Manhwa"),
                mangaUrl = "https://mangaeffect.com/manga/lightning-degree/",
                coverUrl = "https://mangaeffect.com/covers/ld.jpg",
                isSavedInLibrary = true,
                isFavorite = false,
                categoryName = "Manhwa & Webtoons",
                preferredReaderMode = ReaderMode.WEBTOON,
                chapters = emptyList()
            )
        )

        val gzBytes = TachiyomiBackupEngine.exportTachiyomiProtoGz(
            seriesList = sampleSeries,
            categories = listOf("All", "Manhwa & Webtoons"),
            sources = SourceCatalogEngine.defaultBuiltInSources
        )
        assertTrue(gzBytes.isNotEmpty())
        assertEquals(0x1F.toByte(), gzBytes[0])
        assertEquals(0x8B.toByte(), gzBytes[1])

        val imported = TachiyomiBackupEngine.importBackupBytes(
            rawBytes = gzBytes,
            fileName = "test_backup.tachibk",
            existingSources = SourceCatalogEngine.defaultBuiltInSources
        )
        assertTrue(imported.isSuccess)
        val payload = imported.getOrThrow()
        assertEquals(2, payload.seriesList.size)
        val restoredSolo = payload.seriesList.first { it.title == "Solo Leveling" }
        assertTrue(restoredSolo.isSavedInLibrary)
        assertTrue(restoredSolo.isFavorite)
        assertEquals(1, restoredSolo.chapters.size)
        assertTrue(restoredSolo.chapters.first().isRead)
        assertEquals(14, restoredSolo.chapters.first().lastPageRead)

        val restoredLightning = payload.seriesList.first { it.title == "Lightning Degree" }
        assertTrue(restoredLightning.isSavedInLibrary)
        assertFalse(restoredLightning.isFavorite)
    }

    @Test
    fun normalizeWebsiteUrl_addsHttpsAndStripsTrailingSlash() {
        assertEquals("https://bato.to", SourceCatalogEngine.normalizeWebsiteUrl("bato.to/"))
        assertEquals("https://mangaeffect.com", SourceCatalogEngine.normalizeWebsiteUrl("http://mangaeffect.com/"))
    }
}
