package com.webreader.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.webreader.app.data.ImageCacheManager
import com.webreader.app.data.SourceCatalogEngine
import com.webreader.app.data.TachiyomiBackupEngine
import com.webreader.app.data.WebReaderPreferences
import com.webreader.app.model.BackupImportSummary
import com.webreader.app.model.ChapterItem
import com.webreader.app.model.LibrarySortOption
import com.webreader.app.model.MangaSeries
import com.webreader.app.model.MangaSourceSite
import com.webreader.app.model.PageBookmarkItem
import com.webreader.app.model.ReaderMode
import com.webreader.app.model.ReadingHistoryRecord
import com.webreader.app.model.SourceParserType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class WebReaderUiState(
    val sources: List<MangaSourceSite> = SourceCatalogEngine.defaultBuiltInSources,
    val selectedSourceId: String = "mangadex",
    val categories: List<String> = listOf("All", "Manhwa & Webtoons", "Manga", "Manhua"),
    val selectedCategory: String = "All",
    val librarySearchQuery: String = "",
    val showStarterCatalog: Boolean = false,
    val favoritesOnlyFilter: Boolean = false,
    val unreadOnlyFilter: Boolean = false,
    val downloadedOnlyFilter: Boolean = false,
    val selectedStatusFilter: String = "All",
    val selectedLanguageFilter: String = "All",
    val sortOption: LibrarySortOption = LibrarySortOption.LAST_UPDATED,
    val savedLibrarySeries: List<MangaSeries> = emptyList(),
    val starterCatalogSeries: List<MangaSeries> = SourceCatalogEngine.starterCatalogSeries(),
    val browseResults: List<MangaSeries> = emptyList(),
    val browseQuery: String = "",
    val isBrowseLoading: Boolean = false,
    val browseErrorMessage: String? = null,
    val activeMangaDetail: MangaSeries? = null,
    val isDetailLoading: Boolean = false,
    val detailStatusMessage: String? = null,
    val activeReadingManga: MangaSeries? = null,
    val activeReadingChapter: ChapterItem? = null,
    val activeChapterPages: List<String> = emptyList(),
    val isReaderLoading: Boolean = false,
    val readerErrorMessage: String? = null,
    val currentReaderPage: Int = 0,
    val activeReaderMode: ReaderMode = ReaderMode.WEBTOON,
    val activeWebViewUrl: String? = null,
    val activeWebViewTitle: String = "",
    val historyRecords: List<ReadingHistoryRecord> = emptyList(),
    val pageBookmarks: List<PageBookmarkItem> = emptyList(),
    val lastBackupSummary: BackupImportSummary? = null,
    val adBlockEnabled: Boolean = true,
    val dataSaverEnabled: Boolean = false,
    val amoledDarkMode: Boolean = true,
    val defaultReaderMode: ReaderMode = ReaderMode.WEBTOON,
    val statusBannerMessage: String? = null
) {
    val activeSource: MangaSourceSite
        get() = sources.find { it.id == selectedSourceId } ?: sources.first()

    /**
     * Strictly separates user-saved library series (and starred favorites) from the starter catalog:
     * - When showStarterCatalog is false (Saved Library or Favorites ★ mode), only savedLibrarySeries
     *   are included so empty saved/favorite states render accurately and unsaved starter titles never leak in.
     * - When showStarterCatalog is true (All Catalog mode), starterCatalogSeries are merged with savedLibrarySeries
     *   so saved/favorite badges stay synchronized.
     */
    val displayedLibrarySeries: List<MangaSeries>
        get() {
            val baseList = if (showStarterCatalog) {
                val savedById = savedLibrarySeries.associateBy { it.id }
                val mergedStarter = starterCatalogSeries.map { savedById[it.id] ?: it }
                val extraSaved = savedLibrarySeries.filter { s -> starterCatalogSeries.none { it.id == s.id } }
                extraSaved + mergedStarter
            } else {
                savedLibrarySeries
            }
            val filtered = baseList.filter { manga ->
                val matchesCategory = selectedCategory == "All" ||
                    manga.categoryName.equals(selectedCategory, ignoreCase = true) ||
                    manga.genres.any { it.contains(selectedCategory.split(" ").first(), ignoreCase = true) }
                val matchesQuery = librarySearchQuery.isBlank() ||
                    manga.title.contains(librarySearchQuery, ignoreCase = true) ||
                    manga.author.contains(librarySearchQuery, ignoreCase = true) ||
                    manga.sourceName.contains(librarySearchQuery, ignoreCase = true)
                val matchesFavorites = !favoritesOnlyFilter || manga.isFavorite
                val matchesUnread = !unreadOnlyFilter || manga.unreadCount > 0 || manga.chapters.isEmpty()
                val matchesDownloaded = !downloadedOnlyFilter || manga.downloadedCount > 0
                val matchesStatus = selectedStatusFilter == "All" ||
                    manga.status.equals(selectedStatusFilter, ignoreCase = true)
                matchesCategory && matchesQuery && matchesFavorites && matchesUnread && matchesDownloaded && matchesStatus
            }

            return when (sortOption) {
                LibrarySortOption.ALPHABETICAL -> filtered.sortedBy { it.title.lowercase() }
                LibrarySortOption.UNREAD_COUNT -> filtered.sortedByDescending { it.unreadCount }
                LibrarySortOption.LAST_UPDATED -> filtered.sortedWith(
                    compareByDescending<MangaSeries> { it.isFavorite }
                        .thenByDescending { it.lastReadAt }
                        .thenByDescending { it.dateAdded }
                )
            }
        }

    val activeFilterCount: Int
        get() = listOf(
            favoritesOnlyFilter,
            unreadOnlyFilter,
            downloadedOnlyFilter,
            selectedStatusFilter != "All",
            selectedLanguageFilter != "All"
        ).count { it }
}

class WebReaderViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = WebReaderPreferences(application.applicationContext)

    private val _uiState = MutableStateFlow(WebReaderUiState())
    val uiState: StateFlow<WebReaderUiState> = _uiState.asStateFlow()

    init {
        ImageCacheManager.init(application.applicationContext)

        val savedCustomSources = prefs.loadCustomSources()
        val allSources = (SourceCatalogEngine.defaultBuiltInSources + savedCustomSources).distinctBy { it.id }
        val savedSeries = prefs.loadSavedLibrarySeries()
        val savedHistory = prefs.loadHistory()
        val savedBookmarks = prefs.loadBookmarks()

        _uiState.update { state ->
            state.copy(
                sources = allSources,
                savedLibrarySeries = savedSeries,
                showStarterCatalog = savedSeries.isEmpty(),
                historyRecords = savedHistory,
                pageBookmarks = savedBookmarks,
                adBlockEnabled = prefs.adBlockEnabled,
                dataSaverEnabled = prefs.dataSaverEnabled,
                amoledDarkMode = prefs.amoledDarkMode,
                defaultReaderMode = prefs.defaultReaderMode
            )
        }

        // Trigger initial live browse on the default source so the Explore tab is ready
        browseActiveSource("")
    }

    fun clearStatusBanner() {
        _uiState.update { it.copy(statusBannerMessage = null) }
    }

    fun selectCategory(category: String) {
        _uiState.update { it.copy(selectedCategory = category) }
    }

    fun updateLibrarySearch(query: String) {
        _uiState.update { it.copy(librarySearchQuery = query) }
    }

    fun toggleStarterCatalogView(showCatalog: Boolean) {
        _uiState.update { it.copy(showStarterCatalog = showCatalog) }
    }

    fun toggleFavoritesOnlyFilter(enabled: Boolean? = null) {
        _uiState.update { state ->
            val next = enabled ?: !state.favoritesOnlyFilter
            state.copy(favoritesOnlyFilter = next)
        }
    }

    fun toggleUnreadOnlyFilter(enabled: Boolean? = null) {
        _uiState.update { state ->
            val next = enabled ?: !state.unreadOnlyFilter
            state.copy(unreadOnlyFilter = next)
        }
    }

    fun toggleDownloadedOnlyFilter(enabled: Boolean? = null) {
        _uiState.update { state ->
            val next = enabled ?: !state.downloadedOnlyFilter
            state.copy(downloadedOnlyFilter = next)
        }
    }

    fun selectStatusFilter(status: String) {
        _uiState.update { it.copy(selectedStatusFilter = status) }
    }

    fun selectLanguageFilter(language: String) {
        _uiState.update { it.copy(selectedLanguageFilter = language) }
    }

    fun selectSortOption(option: LibrarySortOption) {
        _uiState.update { it.copy(sortOption = option) }
    }

    fun resetLibraryFilters() {
        _uiState.update {
            it.copy(
                favoritesOnlyFilter = false,
                unreadOnlyFilter = false,
                downloadedOnlyFilter = false,
                selectedStatusFilter = "All",
                selectedLanguageFilter = "All",
                sortOption = LibrarySortOption.LAST_UPDATED
            )
        }
    }

    fun selectSource(sourceId: String) {
        _uiState.update { it.copy(selectedSourceId = sourceId, browseErrorMessage = null) }
        browseActiveSource(_uiState.value.browseQuery)
    }

    fun updateBrowseQuery(query: String) {
        _uiState.update { it.copy(browseQuery = query) }
    }

    fun browseActiveSource(query: String = _uiState.value.browseQuery) {
        val currentSource = _uiState.value.activeSource
        _uiState.update {
            it.copy(
                browseQuery = query,
                isBrowseLoading = true,
                browseErrorMessage = null
            )
        }

        viewModelScope.launch {
            val liveResults = runCatching {
                SourceCatalogEngine.searchOrBrowseSource(currentSource, query)
            }.getOrDefault(emptyList())

            val savedById = _uiState.value.savedLibrarySeries.associateBy { it.id }
            val merged = if (liveResults.isNotEmpty()) {
                liveResults.map { item ->
                    val existing = savedById[item.id]
                    if (existing != null) {
                        item.copy(
                            isSavedInLibrary = existing.isSavedInLibrary,
                            isFavorite = existing.isFavorite,
                            chapters = existing.chapters.ifEmpty { item.chapters }
                        )
                    } else item
                }
            } else {
                // Fallback to matching starter items for that source if live site is blocked by Cloudflare
                _uiState.value.starterCatalogSeries.filter {
                    it.sourceId == currentSource.id &&
                        (query.isBlank() || it.title.contains(query, ignoreCase = true))
                }.map { item ->
                    val existing = savedById[item.id]
                    if (existing != null) {
                        item.copy(
                            isSavedInLibrary = existing.isSavedInLibrary,
                            isFavorite = existing.isFavorite
                        )
                    } else item
                }
            }

            val errorMsg = when {
                liveResults.isEmpty() && merged.isEmpty() && query.isNotBlank() ->
                    "No series matched \"$query\" on ${currentSource.name}. Try another keyword or open ${currentSource.name} in Browser Reader."
                liveResults.isEmpty() && merged.isEmpty() ->
                    "${currentSource.name} did not return a catalog feed (site may require Cloudflare verification or device is offline)."
                liveResults.isEmpty() && merged.isNotEmpty() ->
                    "Showing cached starter titles for ${currentSource.name}. Open Browser Reader if Cloudflare blocks live requests."
                else -> null
            }

            _uiState.update {
                it.copy(
                    browseResults = merged,
                    isBrowseLoading = false,
                    browseErrorMessage = errorMsg
                )
            }
        }
    }

    fun addCustomWebsite(nameInput: String, urlInput: String) {
        val cleanUrl = SourceCatalogEngine.normalizeWebsiteUrl(urlInput)
        if (cleanUrl.isBlank()) return
        val cleanName = nameInput.trim().ifBlank { SourceCatalogEngine.extractDomainLabel(cleanUrl) }
        val slug = cleanName.lowercase().replace(Regex("[^a-z0-9]+"), "").ifBlank { "site_${System.currentTimeMillis()}" }

        val newSite = MangaSourceSite(
            id = "custom_$slug",
            tachiyomiSourceId = (slug.hashCode().toLong() and 0x7FFFFFFFL),
            name = cleanName,
            baseUrl = cleanUrl,
            mirrors = listOf(cleanUrl),
            language = "EN",
            parserType = SourceParserType.CUSTOM_SMART,
            defaultReaderMode = ReaderMode.AUTO,
            isPinnedFavorite = true,
            isBuiltIn = false,
            accentColorHex = 0xFF0EA5E9
        )

        _uiState.update { state ->
            val updatedSources = (state.sources + newSite).distinctBy { it.id }
            prefs.saveCustomSources(updatedSources)
            state.copy(
                sources = updatedSources,
                selectedSourceId = newSite.id,
                statusBannerMessage = "Added custom website: ${newSite.name} (${newSite.baseUrl})"
            )
        }
        browseActiveSource("")
    }

    /**
     * Adds or removes a series from the user's Saved Library.
     * Removing from Saved Library also clears its starred favorite flag.
     * Also synchronizes browseResults and starterCatalogSeries in-memory states.
     */
    fun toggleSavedInLibrary(manga: MangaSeries) {
        _uiState.update { state ->
            val exists = state.savedLibrarySeries.any { it.id == manga.id && it.isSavedInLibrary }
            val nextSaved = !exists
            val nextFav = if (nextSaved) manga.isFavorite else false
            val updatedItem = manga.copy(isSavedInLibrary = nextSaved, isFavorite = nextFav)

            val updatedSaved = if (exists) {
                state.savedLibrarySeries.filterNot { it.id == manga.id }
            } else {
                listOf(updatedItem) + state.savedLibrarySeries.filterNot { it.id == manga.id }
            }
            prefs.saveSavedLibrarySeries(updatedSaved)

            val updatedBrowse = state.browseResults.map {
                if (it.id == manga.id) it.copy(isSavedInLibrary = nextSaved, isFavorite = nextFav) else it
            }

            val updatedDetail = if (state.activeMangaDetail?.id == manga.id) {
                state.activeMangaDetail.copy(isSavedInLibrary = nextSaved, isFavorite = nextFav)
            } else state.activeMangaDetail

            state.copy(
                savedLibrarySeries = updatedSaved,
                browseResults = updatedBrowse,
                activeMangaDetail = updatedDetail,
                statusBannerMessage = if (nextSaved) {
                    "Saved '${manga.title}' to Library"
                } else {
                    "Removed '${manga.title}' from Library"
                }
            )
        }
    }

    /**
     * Toggles the starred Favorite status of a series WITHOUT deleting it from the Saved Library
     * when un-starring. If a series was not yet saved in the library, starring it automatically
     * saves it to the library as well.
     */
    fun toggleFavorite(manga: MangaSeries) {
        _uiState.update { state ->
            val existingSaved = state.savedLibrarySeries.find { it.id == manga.id }
            val currentlyFav = existingSaved?.isFavorite ?: manga.isFavorite
            val nextFav = !currentlyFav

            val updatedManga = (existingSaved ?: manga).copy(
                isSavedInLibrary = true,
                isFavorite = nextFav
            )
            val updatedSaved = listOf(updatedManga) + state.savedLibrarySeries.filterNot { it.id == manga.id }
            prefs.saveSavedLibrarySeries(updatedSaved)

            val updatedBrowse = state.browseResults.map {
                if (it.id == manga.id) it.copy(isSavedInLibrary = true, isFavorite = nextFav) else it
            }

            val updatedDetail = if (state.activeMangaDetail?.id == manga.id) {
                state.activeMangaDetail.copy(isSavedInLibrary = true, isFavorite = nextFav)
            } else state.activeMangaDetail

            state.copy(
                savedLibrarySeries = updatedSaved,
                browseResults = updatedBrowse,
                activeMangaDetail = updatedDetail,
                statusBannerMessage = if (nextFav) {
                    "Marked '${manga.title}' as Favorite ★ (Saved in Library)"
                } else {
                    "Removed ★ from '${manga.title}' (Kept in Saved Library)"
                }
            )
        }
    }

    fun openMangaDetail(manga: MangaSeries) {
        val savedMatch = _uiState.value.savedLibrarySeries.find { it.id == manga.id }
        val initial = savedMatch ?: manga
        _uiState.update {
            it.copy(
                activeMangaDetail = initial,
                isDetailLoading = true,
                detailStatusMessage = "Fetching live chapters from ${initial.sourceName}..."
            )
        }

        viewModelScope.launch {
            val sourceSite = _uiState.value.sources.find { it.id == initial.sourceId }
                ?: SourceCatalogEngine.defaultBuiltInSources.first()

            val refreshed = runCatching {
                SourceCatalogEngine.fetchSeriesDetailsAndChapters(initial, sourceSite)
            }.getOrDefault(initial)

            // Preserve read/bookmarked flags from saved chapters
            val savedChaptersByUrl = initial.chapters.associateBy { it.url }
            val mergedChapters = refreshed.chapters.map { ch ->
                val prev = savedChaptersByUrl[ch.url]
                if (prev != null) {
                    ch.copy(
                        isRead = prev.isRead,
                        isBookmarked = prev.isBookmarked,
                        lastPageRead = prev.lastPageRead,
                        isDownloaded = prev.isDownloaded
                    )
                } else ch
            }

            val finalManga = refreshed.copy(
                isSavedInLibrary = initial.isSavedInLibrary,
                isFavorite = initial.isFavorite,
                chapters = mergedChapters
            )

            _uiState.update { state ->
                val updatedSaved = if (finalManga.isSavedInLibrary || finalManga.isFavorite) {
                    state.savedLibrarySeries.map { if (it.id == finalManga.id) finalManga else it }
                } else state.savedLibrarySeries
                if (finalManga.isSavedInLibrary || finalManga.isFavorite) {
                    prefs.saveSavedLibrarySeries(updatedSaved)
                }

                state.copy(
                    activeMangaDetail = finalManga,
                    savedLibrarySeries = updatedSaved,
                    isDetailLoading = false,
                    detailStatusMessage = if (mergedChapters.isNotEmpty()) {
                        "Loaded ${mergedChapters.size} chapters from ${sourceSite.name}"
                    } else {
                        "Could not scrape chapter list directly (Cloudflare or custom layout). Tap 'Read in Browser' to read on ${sourceSite.name}."
                    }
                )
            }
        }
    }

    fun closeMangaDetail() {
        _uiState.update { it.copy(activeMangaDetail = null, detailStatusMessage = null) }
    }

    fun openChapterInReader(manga: MangaSeries, chapter: ChapterItem, initialPage: Int = 0) {
        val resolvedMode = when {
            manga.preferredReaderMode != ReaderMode.AUTO -> manga.preferredReaderMode
            else -> _uiState.value.defaultReaderMode
        }

        _uiState.update {
            it.copy(
                activeReadingManga = manga,
                activeReadingChapter = chapter,
                activeChapterPages = emptyList(),
                isReaderLoading = true,
                readerErrorMessage = null,
                currentReaderPage = initialPage,
                activeReaderMode = resolvedMode
            )
        }

        recordReadingHistory(manga, chapter, initialPage)

        viewModelScope.launch {
            val sourceSite = _uiState.value.sources.find { it.id == manga.sourceId }
                ?: SourceCatalogEngine.defaultBuiltInSources.first()

            val pages = runCatching {
                SourceCatalogEngine.fetchChapterPageUrls(chapter, sourceSite, _uiState.value.dataSaverEnabled)
            }.getOrDefault(emptyList())

            if (pages.isNotEmpty()) {
                _uiState.update {
                    it.copy(
                        activeChapterPages = pages,
                        isReaderLoading = false,
                        readerErrorMessage = null
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        activeChapterPages = emptyList(),
                        isReaderLoading = false,
                        readerErrorMessage = "Direct image extraction was blocked by Cloudflare or dynamic JS on ${sourceSite.name}. Tap 'Open in Clean WebView Reader' below to read this chapter directly with ad-blocking enabled."
                    )
                }
            }
        }
    }

    fun updateReaderPage(pageIndex: Int) {
        _uiState.update { it.copy(currentReaderPage = pageIndex.coerceAtLeast(0)) }
    }

    fun cycleReaderMode() {
        val modes = listOf(ReaderMode.WEBTOON, ReaderMode.LEFT_TO_RIGHT, ReaderMode.RIGHT_TO_LEFT)
        val current = _uiState.value.activeReaderMode
        val next = modes[(modes.indexOf(current) + 1) % modes.size]
        _uiState.update { it.copy(activeReaderMode = next) }
    }

    fun switchToAdjacentChapter(nextChapter: Boolean) {
        val manga = _uiState.value.activeReadingManga ?: return
        val currentChapter = _uiState.value.activeReadingChapter ?: return
        val chapters = manga.chapters
        val idx = chapters.indexOfFirst { it.id == currentChapter.id || it.url == currentChapter.url }
        if (idx == -1) return

        // Chapters are sorted newest-first (index 0 = latest, index N = chapter 1)
        val targetIdx = if (nextChapter) idx - 1 else idx + 1
        if (targetIdx in chapters.indices) {
            markChapterReadState(manga.id, currentChapter.id, isRead = true)
            openChapterInReader(manga, chapters[targetIdx], initialPage = 0)
        } else {
            _uiState.update {
                it.copy(
                    statusBannerMessage = if (nextChapter) "You've reached the latest chapter!" else "Already at the first chapter."
                )
            }
        }
    }

    fun closeReader() {
        val manga = _uiState.value.activeReadingManga
        val chapter = _uiState.value.activeReadingChapter
        val page = _uiState.value.currentReaderPage
        if (manga != null && chapter != null) {
            markChapterReadState(manga.id, chapter.id, isRead = true, lastPage = page)
        }
        _uiState.update {
            it.copy(
                activeReadingManga = null,
                activeReadingChapter = null,
                activeChapterPages = emptyList(),
                readerErrorMessage = null
            )
        }
    }

    fun toggleCurrentPageBookmark() {
        val manga = _uiState.value.activeReadingManga ?: return
        val chapter = _uiState.value.activeReadingChapter ?: return
        val pageIdx = _uiState.value.currentReaderPage
        val pageUrl = _uiState.value.activeChapterPages.getOrNull(pageIdx) ?: chapter.url
        val bookmarkId = "${chapter.id}_p$pageIdx"

        _uiState.update { state ->
            val exists = state.pageBookmarks.any { it.id == bookmarkId }
            val updated = if (exists) {
                state.pageBookmarks.filterNot { it.id == bookmarkId }
            } else {
                listOf(
                    PageBookmarkItem(
                        id = bookmarkId,
                        mangaId = manga.id,
                        mangaTitle = manga.title,
                        chapterId = chapter.id,
                        chapterTitle = chapter.title,
                        chapterUrl = chapter.url,
                        pageIndex = pageIdx,
                        pageImageUrl = pageUrl,
                        createdAtMs = System.currentTimeMillis()
                    )
                ) + state.pageBookmarks
            }
            prefs.saveBookmarks(updated)
            state.copy(
                pageBookmarks = updated,
                statusBannerMessage = if (exists) "Removed page ${pageIdx + 1} bookmark" else "Bookmarked ${chapter.title} • Page ${pageIdx + 1}"
            )
        }
    }

    fun removePageBookmark(bookmarkId: String) {
        _uiState.update { state ->
            val updated = state.pageBookmarks.filterNot { it.id == bookmarkId }
            prefs.saveBookmarks(updated)
            state.copy(pageBookmarks = updated)
        }
    }

    fun openInAppWebView(url: String, title: String = "Browser Reader") {
        val clean = SourceCatalogEngine.normalizeWebsiteUrl(url)
        if (clean.isBlank()) return
        _uiState.update {
            it.copy(
                activeWebViewUrl = clean,
                activeWebViewTitle = title
            )
        }
    }

    fun closeInAppWebView() {
        _uiState.update {
            it.copy(
                activeWebViewUrl = null,
                activeWebViewTitle = ""
            )
        }
    }

    /**
     * Called from the in-app WebView "Extract Comic Pages to Native Reader" button!
     */
    fun launchExtractedWebPagesInNativeReader(pageUrl: String, pageTitle: String, imageUrls: List<String>) {
        if (imageUrls.isEmpty()) {
            _uiState.update {
                it.copy(statusBannerMessage = "No comic images detected on this page yet. Scroll down to load images first.")
            }
            return
        }
        val syntheticChapter = ChapterItem(
            id = "web_extracted_${pageUrl.hashCode()}",
            mangaId = "web_series_${pageUrl.hashCode()}",
            title = pageTitle.ifBlank { "Web Extracted Chapter" },
            number = 1f,
            url = pageUrl,
            pageUrls = imageUrls
        )
        val syntheticManga = MangaSeries(
            id = syntheticChapter.mangaId,
            sourceId = _uiState.value.selectedSourceId,
            sourceName = SourceCatalogEngine.extractDomainLabel(pageUrl),
            title = pageTitle.ifBlank { "Web Reader Series" },
            author = SourceCatalogEngine.extractDomainLabel(pageUrl),
            description = "Extracted directly from $pageUrl",
            mangaUrl = pageUrl,
            coverUrl = imageUrls.first(),
            preferredReaderMode = ReaderMode.WEBTOON,
            chapters = listOf(syntheticChapter)
        )

        _uiState.update {
            it.copy(
                activeWebViewUrl = null,
                activeReadingManga = syntheticManga,
                activeReadingChapter = syntheticChapter,
                activeChapterPages = imageUrls,
                isReaderLoading = false,
                readerErrorMessage = null,
                currentReaderPage = 0,
                activeReaderMode = ReaderMode.WEBTOON
            )
        }
    }

    fun markChapterReadState(mangaId: String, chapterId: String, isRead: Boolean, lastPage: Int = 0) {
        _uiState.update { state ->
            fun updateManga(m: MangaSeries): MangaSeries {
                if (m.id != mangaId) return m
                return m.copy(
                    lastReadAt = System.currentTimeMillis(),
                    chapters = m.chapters.map { ch ->
                        if (ch.id == chapterId) ch.copy(isRead = isRead, lastPageRead = lastPage) else ch
                    }
                )
            }

            val updatedSaved = state.savedLibrarySeries.map(::updateManga)
            prefs.saveSavedLibrarySeries(updatedSaved)

            state.copy(
                savedLibrarySeries = updatedSaved,
                activeMangaDetail = state.activeMangaDetail?.let(::updateManga),
                activeReadingManga = state.activeReadingManga?.let(::updateManga)
            )
        }
    }

    fun toggleChapterDownload(manga: MangaSeries, chapter: ChapterItem) {
        viewModelScope.launch {
            val sourceSite = _uiState.value.sources.find { it.id == manga.sourceId }
                ?: SourceCatalogEngine.defaultBuiltInSources.first()

            val pages = SourceCatalogEngine.fetchChapterPageUrls(chapter, sourceSite, _uiState.value.dataSaverEnabled)
            withContext(Dispatchers.IO) {
                pages.take(15).forEach { imgUrl ->
                    ImageCacheManager.loadBitmap(imgUrl, referer = chapter.url)
                }
            }

            _uiState.update { state ->
                fun updateManga(m: MangaSeries): MangaSeries {
                    if (m.id != manga.id) return m
                    return m.copy(
                        chapters = m.chapters.map { ch ->
                            if (ch.id == chapter.id) ch.copy(isDownloaded = !ch.isDownloaded) else ch
                        }
                    )
                }
                val updatedSaved = state.savedLibrarySeries.map(::updateManga)
                prefs.saveSavedLibrarySeries(updatedSaved)
                state.copy(
                    savedLibrarySeries = updatedSaved,
                    activeMangaDetail = state.activeMangaDetail?.let(::updateManga),
                    statusBannerMessage = "Cached chapter '${chapter.title}' for offline reading"
                )
            }
        }
    }

    private fun recordReadingHistory(manga: MangaSeries, chapter: ChapterItem, pageIndex: Int) {
        val record = ReadingHistoryRecord(
            id = "${manga.id}_${chapter.id}",
            mangaId = manga.id,
            mangaTitle = manga.title,
            mangaCoverUrl = manga.coverUrl,
            sourceId = manga.sourceId,
            sourceName = manga.sourceName,
            chapterId = chapter.id,
            chapterTitle = chapter.title,
            chapterUrl = chapter.url,
            lastPageIndex = pageIndex,
            timestampMs = System.currentTimeMillis()
        )
        _uiState.update { state ->
            val updated = listOf(record) + state.historyRecords.filterNot { it.id == record.id }
            prefs.saveHistory(updated)
            state.copy(historyRecords = updated)
        }
    }

    fun clearReadingHistory() {
        prefs.saveHistory(emptyList())
        _uiState.update { it.copy(historyRecords = emptyList(), statusBannerMessage = "Cleared reading history") }
    }

    /**
     * Imports a real Tachiyomi (.tachibk / .proto.gz), JSON, or Kotatsu (.zip) backup URI from Android SAF.
     * Merges with existing saved series while preserving Saved Library and Favorite ★ flags.
     */
    fun importBackupFromUri(uri: Uri, displayFileName: String) {
        viewModelScope.launch {
            val appContext = getApplication<Application>().applicationContext
            val rawBytes = withContext(Dispatchers.IO) {
                runCatching {
                    appContext.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                }.getOrNull()
            }

            if (rawBytes == null || rawBytes.isEmpty()) {
                _uiState.update {
                    it.copy(statusBannerMessage = "Could not read backup file: $displayFileName")
                }
                return@launch
            }

            val result = withContext(Dispatchers.Default) {
                TachiyomiBackupEngine.importBackupBytes(
                    rawBytes = rawBytes,
                    fileName = displayFileName,
                    existingSources = _uiState.value.sources
                )
            }

            result.onSuccess { payload ->
                _uiState.update { state ->
                    val mergedSources = (state.sources + payload.customSites).distinctBy { it.id }
                    prefs.saveCustomSources(mergedSources)

                    val mergedSaved = (payload.seriesList + state.savedLibrarySeries)
                        .distinctBy { "${it.sourceId}:${it.title.lowercase()}" }
                    prefs.saveSavedLibrarySeries(mergedSaved)

                    val mergedCategories = (state.categories + payload.categories).distinct()

                    state.copy(
                        sources = mergedSources,
                        savedLibrarySeries = mergedSaved,
                        showStarterCatalog = false,
                        favoritesOnlyFilter = false,
                        categories = mergedCategories,
                        lastBackupSummary = payload.summary,
                        statusBannerMessage = payload.summary.message
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(statusBannerMessage = "Backup import failed: ${err.localizedMessage ?: "Invalid format"}")
                }
            }
        }
    }

    /**
     * Exports the current saved library into a real GZIP-compressed Tachiyomi Protobuf (.tachibk) file.
     */
    fun exportBackupToUri(uri: Uri) {
        viewModelScope.launch {
            val appContext = getApplication<Application>().applicationContext
            val state = _uiState.value
            val seriesToExport = state.savedLibrarySeries.ifEmpty { state.displayedLibrarySeries }

            val gzBytes = withContext(Dispatchers.Default) {
                TachiyomiBackupEngine.exportTachiyomiProtoGz(
                    seriesList = seriesToExport,
                    categories = state.categories,
                    sources = state.sources
                )
            }

            val success = withContext(Dispatchers.IO) {
                runCatching {
                    appContext.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(gzBytes)
                        out.flush()
                    }
                    true
                }.getOrDefault(false)
            }

            _uiState.update {
                it.copy(
                    statusBannerMessage = if (success) {
                        "Exported ${seriesToExport.size} series to Tachiyomi .tachibk backup (${gzBytes.size / 1024} KB)"
                    } else {
                        "Failed to write backup file."
                    }
                )
            }
        }
    }

    fun setAdBlockEnabled(enabled: Boolean) {
        prefs.adBlockEnabled = enabled
        _uiState.update { it.copy(adBlockEnabled = enabled) }
    }

    fun setDataSaverEnabled(enabled: Boolean) {
        prefs.dataSaverEnabled = enabled
        _uiState.update { it.copy(dataSaverEnabled = enabled) }
    }

    fun setAmoledDarkMode(enabled: Boolean) {
        prefs.amoledDarkMode = enabled
        _uiState.update { it.copy(amoledDarkMode = enabled) }
    }

    fun setDefaultReaderMode(mode: ReaderMode) {
        prefs.defaultReaderMode = mode
        _uiState.update { it.copy(defaultReaderMode = mode) }
    }

    fun clearDiskImageCache() {
        viewModelScope.launch(Dispatchers.IO) {
            ImageCacheManager.clearDiskCache()
            _uiState.update { it.copy(statusBannerMessage = "Cleared image disk & memory cache") }
        }
    }
}
