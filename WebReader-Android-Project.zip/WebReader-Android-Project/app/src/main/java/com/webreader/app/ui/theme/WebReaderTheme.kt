package com.webreader.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

/**
 * Centralized Design System, Dark / True-AMOLED Palette, and System-Bar Controller for WebReader.
 * Ensures consistent colors, WCAG AA/AAA text contrast, scalable typography (supporting 1.5x font scale),
 * and synchronized Android status/navigation bar styling across all screens, bottom sheets, and dialogs.
 */
object WebReaderPalette {
    // Hex constants for non-Compose model defaults
    const val PrimaryBlueHex: Long = 0xFF2563EB

    // Core Surfaces (Obsidian Dark vs. True AMOLED Pitch-Black)
    val ObsidianBackground = Color(0xFF0A0E17)
    val AmoledPureBlack = Color(0xFF000000)
    val NavySurface = Color(0xFF0F1624)
    val AmoledSurface = Color(0xFF06090F)
    val ElevatedCardSurface = Color(0xFF151E30)
    val AmoledCardSurface = Color(0xFF0C121E)
    val InteractiveSurface = Color(0xFF1E293B)
    val SubtleBorder = Color(0xFF334155)
    val GlassScrim = Color(0xCC0A0E17)
    val GlassPillOverlay = Color(0xE60F172A)

    // Brand & Semantic Status Colors
    val PrimaryBlue = Color(0xFF2563EB)
    val AccentSky = Color(0xFF38BDF8)
    val SecondaryIndigo = Color(0xFF6366F1)
    val FavoriteGold = Color(0xFFFBBF24)
    val SuccessEmerald = Color(0xFF10B981)
    val WarningAmber = Color(0xFFF59E0B)
    val DangerRose = Color(0xFFEF4444)

    // Typography Colors (Verified WCAG AA/AAA Contrast against Obsidian & AMOLED Black)
    // TextPrimary (#F8FAFC) vs #0A0E17 = 18.6:1 (AAA) | vs #151E30 = 14.9:1 (AAA)
    // TextSecondary (#CBD5E1) vs #0A0E17 = 12.8:1 (AAA) | vs #151E30 = 10.2:1 (AAA)
    // TextMuted (#94A3B8) vs #0A0E17 = 6.7:1 (AA) | vs #151E30 = 5.4:1 (AA)
    val TextPrimary = Color(0xFFF8FAFC)
    val TextSecondary = Color(0xFFCBD5E1)
    val TextMuted = Color(0xFF94A3B8)
}

object WebReaderShapes {
    val SearchPill = RoundedCornerShape(24.dp)
    val CoverCard = RoundedCornerShape(16.dp)
    val CoverTitleOverlay = RoundedCornerShape(12.dp)
    val ElevatedCard = RoundedCornerShape(16.dp)
    val FloatingHudPill = RoundedCornerShape(20.dp)
    val FilterChip = RoundedCornerShape(20.dp)
    val BadgePill = RoundedCornerShape(8.dp)
    val BottomSheetTop = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    val Circle = CircleShape

    val MaterialShapes = Shapes(
        extraSmall = RoundedCornerShape(8.dp),
        small = RoundedCornerShape(12.dp),
        medium = RoundedCornerShape(16.dp),
        large = RoundedCornerShape(20.dp),
        extraLarge = RoundedCornerShape(24.dp)
    )
}

val WebReaderTypography = Typography(
    headlineSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 21.sp,
        lineHeight = 28.sp,
        letterSpacing = (-0.2).sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp,
        lineHeight = 24.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 15.sp,
        lineHeight = 21.sp
    ),
    titleSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp,
        lineHeight = 18.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 17.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 12.sp,
        lineHeight = 16.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 15.sp
    )
)

@Composable
fun WebReaderTheme(
    amoledDarkMode: Boolean,
    content: @Composable () -> Unit
) {
    val colorScheme = darkColorScheme(
        primary = WebReaderPalette.PrimaryBlue,
        onPrimary = WebReaderPalette.TextPrimary,
        primaryContainer = Color(0xFF1D4ED8),
        onPrimaryContainer = WebReaderPalette.TextPrimary,
        secondary = WebReaderPalette.AccentSky,
        onSecondary = WebReaderPalette.ObsidianBackground,
        tertiary = WebReaderPalette.SuccessEmerald,
        background = if (amoledDarkMode) WebReaderPalette.AmoledPureBlack else WebReaderPalette.ObsidianBackground,
        onBackground = WebReaderPalette.TextPrimary,
        surface = if (amoledDarkMode) WebReaderPalette.AmoledSurface else WebReaderPalette.NavySurface,
        onSurface = WebReaderPalette.TextPrimary,
        surfaceVariant = if (amoledDarkMode) WebReaderPalette.AmoledCardSurface else WebReaderPalette.ElevatedCardSurface,
        onSurfaceVariant = WebReaderPalette.TextSecondary,
        outline = WebReaderPalette.SubtleBorder,
        error = WebReaderPalette.DangerRose,
        onError = WebReaderPalette.TextPrimary
    )

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.surface.toArgb()
            val insetsController = WindowCompat.getInsetsController(window, view)
            insetsController.isAppearanceLightStatusBars = false
            insetsController.isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = WebReaderTypography,
        shapes = WebReaderShapes.MaterialShapes,
        content = content
    )
}
