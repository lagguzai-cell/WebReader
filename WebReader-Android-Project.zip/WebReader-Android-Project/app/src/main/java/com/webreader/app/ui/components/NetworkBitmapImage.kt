package com.webreader.app.ui.components

import android.graphics.Bitmap
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.webreader.app.data.ImageCacheManager
import com.webreader.app.ui.theme.WebReaderPalette
import com.webreader.app.ui.theme.WebReaderShapes

/**
 * Loads and displays real remote manga cover images with:
 * - Animated shimmer skeleton placeholder during network fetch
 * - Monogram + source badge fallback when a cover URL is missing or blocked
 * - Accessible semantics and scalable typography that supports 1.5x system font scale
 */
@Composable
fun MangaCoverImage(
    coverUrl: String,
    title: String,
    refererUrl: String,
    accentColorHex: Long,
    modifier: Modifier = Modifier,
    sourceBadgeText: String = "",
    contentScale: ContentScale = ContentScale.Crop
) {
    var bitmap by remember(coverUrl) { mutableStateOf<Bitmap?>(null) }
    var isLoading by remember(coverUrl) { mutableStateOf(coverUrl.isNotBlank()) }
    var retryKey by remember(coverUrl) { mutableIntStateOf(0) }

    LaunchedEffect(coverUrl, retryKey) {
        if (coverUrl.isBlank()) {
            isLoading = false
            bitmap = null
            return@LaunchedEffect
        }
        isLoading = true
        bitmap = ImageCacheManager.loadBitmap(coverUrl, referer = refererUrl)
        isLoading = false
    }

    val accentColor = Color(accentColorHex)
    val surfaceVariantColor = MaterialTheme.colorScheme.surfaceVariant
    val backgroundColor = MaterialTheme.colorScheme.background

    val transition = rememberInfiniteTransition(label = "coverShimmer")
    val shimmerAlpha by transition.animateFloat(
        initialValue = 0.22f,
        targetValue = 0.55f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 950, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "shimmerAlpha"
    )

    Box(
        modifier = modifier
            .semantics {
                contentDescription = "Cover image for $title"
                role = Role.Image
            }
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        accentColor.copy(alpha = if (isLoading) shimmerAlpha else 0.78f),
                        surfaceVariantColor,
                        backgroundColor
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        val loadedBitmap = bitmap
        if (loadedBitmap != null) {
            Image(
                bitmap = loadedBitmap.asImageBitmap(),
                contentDescription = title,
                contentScale = contentScale,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Decorative geometric rings for missing-cover / loading skeleton state
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    color = accentColor.copy(alpha = 0.14f),
                    radius = size.minDimension * 0.44f,
                    center = Offset(size.width * 0.8f, size.height * 0.2f)
                )
                drawCircle(
                    color = WebReaderPalette.AccentSky.copy(alpha = 0.08f),
                    radius = size.minDimension * 0.35f,
                    center = Offset(size.width * 0.2f, size.height * 0.75f)
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 8.dp, vertical = 28.dp)
            ) {
                val initials = title
                    .split(" ", "-", ":")
                    .filter { it.isNotBlank() }
                    .take(2)
                    .joinToString("") { it.first().uppercase() }
                    .ifBlank { "WR" }

                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(WebReaderPalette.GlassPillOverlay)
                        .border(1.dp, accentColor.copy(alpha = 0.55f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp,
                            color = WebReaderPalette.AccentSky
                        )
                    } else {
                        Text(
                            text = initials,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = WebReaderPalette.TextPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = WebReaderPalette.TextPrimary.copy(alpha = 0.92f),
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                )

                if (!isLoading) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        color = WebReaderPalette.GlassPillOverlay,
                        shape = WebReaderShapes.BadgePill,
                        modifier = Modifier
                            .clickable { retryKey++ }
                            .semantics { contentDescription = "Retry loading cover for $title" }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Icon(
                                imageVector = if (coverUrl.isNotBlank()) Icons.Default.Refresh else Icons.Default.MenuBook,
                                contentDescription = null,
                                tint = WebReaderPalette.AccentSky,
                                modifier = Modifier.size(11.dp)
                            )
                            Text(
                                text = if (sourceBadgeText.isNotBlank()) " $sourceBadgeText" else " Retry",
                                style = MaterialTheme.typography.labelSmall,
                                color = WebReaderPalette.TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Full-bleed comic/manga reader page image with non-blocking multi-touch zoom & pan:
 * - At 1x scale with 1 finger down, drag events are NOT consumed so HorizontalPager (left/right page swipes)
 *   and LazyColumn (vertical Webtoon scroll) work smoothly without gesture conflict.
 * - With 2+ fingers down (pinch) or when already zoomed in (scale > 1.01f), zoom (1x..4x) and pan
 *   events are consumed smoothly.
 * - Supports double-tap zoom (1x <-> 2.25x), single-tap HUD toggle, and orientation-safe zoom state.
 */
@Composable
fun ComicReaderPageImage(
    imageUrl: String,
    pageNumber: Int,
    totalPages: Int,
    refererUrl: String,
    enablePinchZoom: Boolean,
    onSingleTap: () -> Unit,
    modifier: Modifier = Modifier
) {
    var bitmap by remember(imageUrl) { mutableStateOf<Bitmap?>(null) }
    var isLoading by remember(imageUrl) { mutableStateOf(true) }
    var reloadTrigger by remember(imageUrl) { mutableIntStateOf(0) }

    var scale by rememberSaveable(imageUrl) { mutableFloatStateOf(1f) }
    var offsetX by rememberSaveable(imageUrl) { mutableFloatStateOf(0f) }
    var offsetY by rememberSaveable(imageUrl) { mutableFloatStateOf(0f) }

    LaunchedEffect(imageUrl, reloadTrigger) {
        isLoading = true
        bitmap = ImageCacheManager.loadBitmap(imageUrl, referer = refererUrl)
        isLoading = false
    }

    val gestureModifier = Modifier
        .pointerInput(imageUrl, enablePinchZoom) {
            if (!enablePinchZoom) return@pointerInput
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false)
                do {
                    val event = awaitPointerEvent()
                    val pointerCount = event.changes.count { it.pressed }
                    val zoomChange = event.calculateZoom()
                    val panChange = event.calculatePan()

                    // Only intercept and consume events when pinching (2+ pointers) or already zoomed in (>1.01f)
                    if (pointerCount >= 2 || scale > 1.01f || zoomChange != 1f) {
                        val newScale = (scale * zoomChange).coerceIn(1f, 4f)
                        scale = newScale
                        if (newScale > 1.01f) {
                            val maxPanX = 900f * (newScale - 1f)
                            val maxPanY = 1400f * (newScale - 1f)
                            offsetX = (offsetX + panChange.x).coerceIn(-maxPanX, maxPanX)
                            offsetY = (offsetY + panChange.y).coerceIn(-maxPanY, maxPanY)
                        } else {
                            offsetX = 0f
                            offsetY = 0f
                        }
                        event.changes.forEach { change ->
                            if (change.positionChanged()) {
                                change.consume()
                            }
                        }
                    }
                } while (event.changes.any { it.pressed })
            }
        }
        .pointerInput(imageUrl) {
            detectTapGestures(
                onDoubleTap = {
                    if (scale > 1.05f) {
                        scale = 1f
                        offsetX = 0f
                        offsetY = 0f
                    } else {
                        scale = 2.25f
                    }
                },
                onTap = { onSingleTap() }
            )
        }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(WebReaderPalette.AmoledPureBlack)
            .then(gestureModifier),
        contentAlignment = Alignment.Center
    ) {
        val loaded = bitmap
        when {
            loaded != null -> {
                val aspectRatio = loaded.width.toFloat().coerceAtLeast(1f) / loaded.height.toFloat().coerceAtLeast(1f)
                Image(
                    bitmap = loaded.asImageBitmap(),
                    contentDescription = "Page $pageNumber of $totalPages",
                    contentScale = ContentScale.FillWidth,
                    modifier = Modifier
                        .fillMaxWidth()
                        .graphicsLayer(
                            scaleX = scale,
                            scaleY = scale,
                            translationX = offsetX,
                            translationY = offsetY
                        )
                )
                if (aspectRatio < 0.01f) {
                    Spacer(modifier = Modifier.height(1.dp))
                }
            }
            isLoading -> {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(420.dp)
                        .padding(24.dp)
                ) {
                    CircularProgressIndicator(color = WebReaderPalette.AccentSky)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Loading Page $pageNumber / $totalPages...",
                        color = WebReaderPalette.TextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            else -> {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 320.dp)
                        .padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.BrokenImage,
                        contentDescription = "Failed to load page $pageNumber",
                        tint = WebReaderPalette.DangerRose,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Page $pageNumber could not be loaded directly",
                        color = WebReaderPalette.TextPrimary,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "The host site may require Referer headers or Clean Browser mode.",
                        color = WebReaderPalette.TextMuted,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    FilledTonalButton(
                        onClick = { reloadTrigger++ },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = WebReaderPalette.PrimaryBlue,
                            contentColor = WebReaderPalette.TextPrimary
                        ),
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .minimumInteractiveComponentSize()
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Text("  Retry Page $pageNumber")
                    }
                }
            }
        }
    }
}
