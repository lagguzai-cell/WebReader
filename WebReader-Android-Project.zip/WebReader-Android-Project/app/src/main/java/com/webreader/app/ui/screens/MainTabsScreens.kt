package com.webreader.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddLink
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.webreader.app.model.ChapterItem
import com.webreader.app.model.LibrarySortOption
import com.webreader.app.model.MangaSeries
import com.webreader.app.model.MangaSourceSite
import com.webreader.app.model.PageBookmarkItem
import com.webreader.app.model.ReaderMode
import com.webreader.app.model.ReadingHistoryRecord
import com.webreader.app.ui.WebReaderUiState
import com.webreader.app.ui.components.MangaCoverImage
import com.webreader.app.ui.theme.WebReaderPalette
import com.webreader.app.ui.theme.WebReaderShapes
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun LibraryTabScreen(
    uiState: WebReaderUiState,
    onSelectCategory: (String) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onToggleStarterCatalog: (Boolean) -> Unit,
    onToggleFavoritesOnly: (Boolean?) -> Unit,
    onToggleUnreadOnly: (Boolean?) -> Unit,
    onToggleDownloadedOnly: (Boolean?) -> Unit,
    onSelectStatusFilter: (String) -> Unit,
    onSelectLanguageFilter: (String) -> Unit,
    onSelectSortOption: (LibrarySortOption) -> Unit,
    onResetFilters: () -> Unit,
    onOpenMangaDetail: (MangaSeries) -> Unit,
    onToggleSavedInLibrary: (MangaSeries) -> Unit,
    onToggleFavorite: (MangaSeries) -> Unit,
    onRequestImportBackup: () -> Unit,
    onOpenAddWebsiteDialog: () -> Unit,
    onSwitchToBrowseTab: () -> Unit
) {
    val displayed = uiState.displayedLibrarySeries
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    var showFilterBottomSheet by rememberSaveable { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Multi-Row Responsive Top Header:
        // Tested for 320dp width & 1.5x font scale — Title + 48dp Icon Actions on Row 1,
        // Full-Width Search Pill on Row 2 (292dp wide at 320dp!), and Scrollable Filter Chips on Row 3.
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                // Row 1: Compact Title + 3 Accessible 48dp Icon Buttons (never clips at 320dp or 1.5x font scale)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 8.dp)
                    ) {
                        Text(
                            text = "WebReader",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = when {
                                uiState.favoritesOnlyFilter -> "Favorites ★ (${displayed.size})"
                                uiState.showStarterCatalog -> "All Catalog (${displayed.size})"
                                else -> "Saved Library (${displayed.size})"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = WebReaderPalette.AccentSky,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Filter Bottom Sheet Trigger with Active Badge (48dp minimum touch target)
                        FilledTonalIconButton(
                            onClick = { showFilterBottomSheet = true },
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = if (uiState.activeFilterCount > 0) {
                                    WebReaderPalette.PrimaryBlue
                                } else {
                                    WebReaderPalette.InteractiveSurface
                                },
                                contentColor = WebReaderPalette.TextPrimary
                            ),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .semantics { contentDescription = "Open library filters and sorting" }
                        ) {
                            BadgedBox(
                                badge = {
                                    if (uiState.activeFilterCount > 0) {
                                        Badge(
                                            containerColor = WebReaderPalette.FavoriteGold,
                                            contentColor = WebReaderPalette.ObsidianBackground
                                        ) {
                                            Text("${uiState.activeFilterCount}")
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Tune,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        // Quick Import .tachibk Backup Icon Button (48dp touch target)
                        FilledTonalIconButton(
                            onClick = onRequestImportBackup,
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = WebReaderPalette.InteractiveSurface,
                                contentColor = WebReaderPalette.AccentSky
                            ),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .semantics { contentDescription = "Import Tachiyomi or Kotatsu backup" }
                        ) {
                            Icon(
                                imageVector = Icons.Default.FileUpload,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Quick Add Custom Website Icon Button (48dp touch target)
                        FilledTonalIconButton(
                            onClick = onOpenAddWebsiteDialog,
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = WebReaderPalette.PrimaryBlue,
                                contentColor = WebReaderPalette.TextPrimary
                            ),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .semantics { contentDescription = "Add custom manga website" }
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddLink,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Row 2: Dedicated Full-Width Search Pill (292dp wide on 320dp screens — zero text clipping at 1.5x font scale)
                OutlinedTextField(
                    value = uiState.librarySearchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = {
                        Text(
                            text = "Search title, author, source...",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodyMedium,
                            color = WebReaderPalette.TextMuted
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search library",
                            tint = WebReaderPalette.AccentSky
                        )
                    },
                    trailingIcon = {
                        if (uiState.librarySearchQuery.isNotEmpty()) {
                            IconButton(
                                onClick = {
                                    onSearchQueryChange("")
                                    focusManager.clearFocus()
                                },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear search query"
                                )
                            }
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(
                        onSearch = {
                            focusManager.clearFocus()
                            keyboardController?.hide()
                        }
                    ),
                    shape = WebReaderShapes.SearchPill,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Row 3: Separated Saved Library vs. Favorites ★ vs. Starter Catalog + Category Pills
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    item {
                        val savedSelected = !uiState.showStarterCatalog && !uiState.favoritesOnlyFilter
                        FilterChip(
                            selected = savedSelected,
                            onClick = {
                                onToggleStarterCatalog(false)
                                onToggleFavoritesOnly(false)
                            },
                            label = {
                                Text(
                                    text = "Saved (${uiState.savedLibrarySeries.size})",
                                    fontWeight = if (savedSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Bookmark,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp)
                                )
                            },
                            shape = WebReaderShapes.FilterChip,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = WebReaderPalette.PrimaryBlue,
                                selectedLabelColor = WebReaderPalette.TextPrimary,
                                selectedLeadingIconColor = WebReaderPalette.TextPrimary
                            )
                        )
                    }

                    item {
                        val favCount = uiState.savedLibrarySeries.count { it.isFavorite }
                        FilterChip(
                            selected = uiState.favoritesOnlyFilter,
                            onClick = {
                                onToggleStarterCatalog(false)
                                onToggleFavoritesOnly(!uiState.favoritesOnlyFilter)
                            },
                            label = {
                                Text(
                                    text = "Favorites ★ ($favCount)",
                                    fontWeight = if (uiState.favoritesOnlyFilter) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            shape = WebReaderShapes.FilterChip,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = WebReaderPalette.FavoriteGold.copy(alpha = 0.22f),
                                selectedLabelColor = WebReaderPalette.FavoriteGold
                            )
                        )
                    }

                    item {
                        FilterChip(
                            selected = uiState.showStarterCatalog,
                            onClick = {
                                onToggleFavoritesOnly(false)
                                onToggleStarterCatalog(!uiState.showStarterCatalog)
                            },
                            label = {
                                Text(
                                    text = "All Catalog (${uiState.starterCatalogSeries.size})",
                                    fontWeight = if (uiState.showStarterCatalog) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            shape = WebReaderShapes.FilterChip,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = WebReaderPalette.SecondaryIndigo,
                                selectedLabelColor = WebReaderPalette.TextPrimary
                            )
                        )
                    }

                    items(uiState.categories) { cat ->
                        val selected = cat == uiState.selectedCategory
                        FilterChip(
                            selected = selected,
                            onClick = { onSelectCategory(cat) },
                            label = {
                                Text(
                                    text = cat,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            shape = WebReaderShapes.FilterChip,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = WebReaderPalette.InteractiveSurface,
                                selectedLabelColor = WebReaderPalette.AccentSky
                            )
                        )
                    }
                }
            }
        }

        // Empty / Filtered-Out State with Clear Recovery Actions
        if (displayed.isEmpty()) {
            LibraryEmptyOrFilteredState(
                hasSavedSeries = uiState.savedLibrarySeries.isNotEmpty(),
                hasActiveFilters = uiState.activeFilterCount > 0 || uiState.librarySearchQuery.isNotBlank(),
                favoritesOnly = uiState.favoritesOnlyFilter,
                onResetFilters = {
                    onSearchQueryChange("")
                    onResetFilters()
                },
                onShowStarterCatalog = { onToggleStarterCatalog(true) },
                onRequestImportBackup = onRequestImportBackup,
                onSwitchToBrowseTab = onSwitchToBrowseTab
            )
        } else {
            // Adaptive Cover Grid: minSize = 128.dp guarantees 2 roomy columns (142dp each) on 320dp screens,
            // 3 columns on 412dp+ phones, and 4-6 columns on tablets/landscape without 1.5x font clipping.
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 128.dp),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(displayed, key = { it.id }) { manga ->
                    MangaGridCard(
                        manga = manga,
                        onClick = { onOpenMangaDetail(manga) },
                        onToggleSaved = { onToggleSavedInLibrary(manga) },
                        onToggleFavorite = { onToggleFavorite(manga) }
                    )
                }
            }
        }
    }

    if (showFilterBottomSheet) {
        LibraryFilterBottomSheet(
            uiState = uiState,
            onDismiss = { showFilterBottomSheet = false },
            onToggleFavoritesOnly = onToggleFavoritesOnly,
            onToggleUnreadOnly = onToggleUnreadOnly,
            onToggleDownloadedOnly = onToggleDownloadedOnly,
            onSelectStatusFilter = onSelectStatusFilter,
            onSelectLanguageFilter = onSelectLanguageFilter,
            onSelectSortOption = onSelectSortOption,
            onResetFilters = onResetFilters
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LibraryEmptyOrFilteredState(
    hasSavedSeries: Boolean,
    hasActiveFilters: Boolean,
    favoritesOnly: Boolean,
    onResetFilters: () -> Unit,
    onShowStarterCatalog: () -> Unit,
    onRequestImportBackup: () -> Unit,
    onSwitchToBrowseTab: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            color = WebReaderPalette.InteractiveSurface,
            shape = CircleShape,
            modifier = Modifier.size(64.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = if (hasActiveFilters) Icons.Default.FilterList else Icons.Default.BookmarkBorder,
                    contentDescription = null,
                    tint = WebReaderPalette.AccentSky,
                    modifier = Modifier.size(30.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = when {
                favoritesOnly && hasSavedSeries -> "No starred Favorites ★ yet"
                hasActiveFilters -> "No series match your active filters"
                else -> "Your Saved Library is empty"
            },
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = when {
                favoritesOnly && hasSavedSeries ->
                    "Your ordinary saved series are still safe in Saved Library! Tap ★ on any cover card to mark it as a Favorite, or switch back to Saved Library."
                hasActiveFilters ->
                    "Try clearing your search or filter selections to see all saved titles."
                else ->
                    "Import your existing Tachiyomi (.tachibk) or Kotatsu (.zip) backup, browse live sources, or view the built-in starter catalog."
            },
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(18.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (hasActiveFilters) {
                Button(
                    onClick = onResetFilters,
                    colors = ButtonDefaults.buttonColors(containerColor = WebReaderPalette.PrimaryBlue),
                    modifier = Modifier.heightIn(min = 48.dp)
                ) {
                    Text("Reset Filters")
                }
            }
            if (!hasSavedSeries) {
                Button(
                    onClick = onRequestImportBackup,
                    colors = ButtonDefaults.buttonColors(containerColor = WebReaderPalette.PrimaryBlue),
                    modifier = Modifier.heightIn(min = 48.dp)
                ) {
                    Icon(Icons.Default.FileUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                    Text("  Import .tachibk Backup")
                }
                FilledTonalButton(
                    onClick = onShowStarterCatalog,
                    modifier = Modifier.heightIn(min = 48.dp)
                ) {
                    Text("Show Starter Catalog")
                }
            }
            OutlinedButton(
                onClick = onSwitchToBrowseTab,
                modifier = Modifier.heightIn(min = 48.dp)
            ) {
                Icon(Icons.Default.Explore, contentDescription = null, modifier = Modifier.size(16.dp))
                Text("  Browse Live Sources")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun LibraryFilterBottomSheet(
    uiState: WebReaderUiState,
    onDismiss: () -> Unit,
    onToggleFavoritesOnly: (Boolean?) -> Unit,
    onToggleUnreadOnly: (Boolean?) -> Unit,
    onToggleDownloadedOnly: (Boolean?) -> Unit,
    onSelectStatusFilter: (String) -> Unit,
    onSelectLanguageFilter: (String) -> Unit,
    onSelectSortOption: (LibrarySortOption) -> Unit,
    onResetFilters: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface,
        shape = WebReaderShapes.BottomSheetTop
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Filters & Sorting",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                TextButton(
                    onClick = onResetFilters,
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Text("Reset All", color = WebReaderPalette.AccentSky)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Language Filter Pills
            Text(
                text = "Language",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("All" to "All Languages", "EN" to "English", "JP" to "Japanese", "KR" to "Korean", "ZH" to "Chinese").forEach { (code, label) ->
                    val selected = uiState.selectedLanguageFilter == code
                    FilterChip(
                        selected = selected,
                        onClick = { onSelectLanguageFilter(code) },
                        label = { Text(label) },
                        shape = WebReaderShapes.FilterChip,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = WebReaderPalette.TextPrimary,
                            selectedLabelColor = WebReaderPalette.ObsidianBackground
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Publication Status Filter
            Text(
                text = "Publication Status",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("All", "Ongoing", "Completed").forEach { status ->
                    val selected = uiState.selectedStatusFilter == status
                    FilterChip(
                        selected = selected,
                        onClick = { onSelectStatusFilter(status) },
                        label = { Text(status) },
                        shape = WebReaderShapes.FilterChip,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = WebReaderPalette.PrimaryBlue,
                            selectedLabelColor = WebReaderPalette.TextPrimary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Collection Filters (Separating Saved Series from Favorites ★)
            Text(
                text = "Collection & Progress Filters",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = uiState.favoritesOnlyFilter,
                    onClick = { onToggleFavoritesOnly(!uiState.favoritesOnlyFilter) },
                    label = { Text("Favorites Only ★") },
                    shape = WebReaderShapes.FilterChip,
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = WebReaderPalette.FavoriteGold.copy(alpha = 0.24f),
                        selectedLabelColor = WebReaderPalette.FavoriteGold
                    )
                )
                FilterChip(
                    selected = uiState.unreadOnlyFilter,
                    onClick = { onToggleUnreadOnly(!uiState.unreadOnlyFilter) },
                    label = { Text("Unread Only") },
                    shape = WebReaderShapes.FilterChip,
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = WebReaderPalette.PrimaryBlue,
                        selectedLabelColor = WebReaderPalette.TextPrimary
                    )
                )
                FilterChip(
                    selected = uiState.downloadedOnlyFilter,
                    onClick = { onToggleDownloadedOnly(!uiState.downloadedOnlyFilter) },
                    label = { Text("Downloaded Offline") },
                    shape = WebReaderShapes.FilterChip,
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = WebReaderPalette.SuccessEmerald.copy(alpha = 0.25f),
                        selectedLabelColor = WebReaderPalette.SuccessEmerald
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Sort By
            Text(
                text = "Sort Library By",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                LibrarySortOption.values().forEach { option ->
                    val selected = uiState.sortOption == option
                    FilterChip(
                        selected = selected,
                        onClick = { onSelectSortOption(option) },
                        label = { Text(option.label) },
                        shape = WebReaderShapes.FilterChip,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = WebReaderPalette.PrimaryBlue,
                            selectedLabelColor = WebReaderPalette.TextPrimary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(
                    containerColor = WebReaderPalette.PrimaryBlue,
                    contentColor = WebReaderPalette.TextPrimary
                ),
                shape = WebReaderShapes.SearchPill,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
            ) {
                Text("Apply", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

/**
 * Polished Dark/AMOLED Manga Cover Card tested for 320dp width & 1.5x font scale:
 * - Single constrained top Row prevents source badge from colliding with unread/favorite controls
 * - Both Favorite ★ and Save-to-Library buttons provide full 48dp accessible hit targets
 * - Glassmorphic bottom overlay scales cleanly with 1.5x system font size without line-height clipping
 */
@Composable
fun MangaGridCard(
    manga: MangaSeries,
    onClick: () -> Unit,
    onToggleSaved: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    Card(
        shape = WebReaderShapes.CoverCard,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(0.8.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f), WebReaderShapes.CoverCard)
            .clickable { onClick() }
            .semantics {
                contentDescription = "${manga.title} by ${manga.author}, source ${manga.sourceName}"
            }
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 236.dp)
        ) {
            MangaCoverImage(
                coverUrl = manga.coverUrl,
                title = manga.title,
                refererUrl = manga.mangaUrl,
                accentColorHex = manga.coverColorHex,
                sourceBadgeText = manga.sourceName,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(236.dp)
            )

            // Top gradient scrim for source badge & quick save/favorite actions
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Black.copy(alpha = 0.72f), Color.Transparent)
                        )
                    )
            )

            // Constrained Top Row: Source Pill (weight 1f) + Unread Badge + Accessible 48dp Favorite ★ Button
            Row(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .padding(start = 6.dp, end = 2.dp, top = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    color = WebReaderPalette.GlassPillOverlay,
                    shape = WebReaderShapes.BadgePill,
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    Text(
                        text = manga.sourceName,
                        color = WebReaderPalette.AccentSky,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    if (manga.unreadCount > 0) {
                        Surface(
                            color = WebReaderPalette.PrimaryBlue,
                            shape = WebReaderShapes.BadgePill
                        ) {
                            Text(
                                text = "${manga.unreadCount}",
                                color = WebReaderPalette.TextPrimary,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.ExtraBold,
                                maxLines = 1,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }

                    // 48dp accessible Star Favorite toggle (independent of Saved Library membership)
                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .semantics {
                                contentDescription = if (manga.isFavorite) {
                                    "Remove ${manga.title} from Favorites"
                                } else {
                                    "Mark ${manga.title} as Favorite"
                                }
                            }
                    ) {
                        Surface(
                            color = WebReaderPalette.GlassPillOverlay,
                            shape = CircleShape,
                            modifier = Modifier.size(30.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = if (manga.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                    contentDescription = null,
                                    tint = if (manga.isFavorite) WebReaderPalette.FavoriteGold else WebReaderPalette.TextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Bottom Glassmorphic Title + Author Overlay Pill (scales cleanly at 1.5x font scale)
            Surface(
                color = WebReaderPalette.GlassPillOverlay,
                shape = WebReaderShapes.CoverTitleOverlay,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(6.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 2.dp, end = 8.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // 48dp accessible Saved-in-Library status indicator / toggle button
                    IconButton(
                        onClick = onToggleSaved,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .semantics {
                                contentDescription = if (manga.isSavedInLibrary) {
                                    "Saved in Library. Tap to remove ${manga.title}"
                                } else {
                                    "Save ${manga.title} to Library"
                                }
                            }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(26.dp)
                                .clip(CircleShape)
                                .background(
                                    if (manga.isSavedInLibrary) WebReaderPalette.PrimaryBlue.copy(alpha = 0.28f)
                                    else WebReaderPalette.InteractiveSurface
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (manga.isSavedInLibrary) WebReaderPalette.AccentSky else WebReaderPalette.SubtleBorder,
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (manga.isSavedInLibrary) Icons.Default.CheckCircle else Icons.Default.BookmarkBorder,
                                contentDescription = null,
                                tint = if (manga.isSavedInLibrary) WebReaderPalette.AccentSky else WebReaderPalette.TextMuted,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = manga.title,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = WebReaderPalette.TextPrimary,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = manga.author.ifBlank { manga.sourceName },
                            style = MaterialTheme.typography.labelSmall,
                            color = WebReaderPalette.TextMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun BrowseSourcesTabScreen(
    uiState: WebReaderUiState,
    onSelectSource: (String) -> Unit,
    onQueryChange: (String) -> Unit,
    onExecuteSearch: (String) -> Unit,
    onOpenMangaDetail: (MangaSeries) -> Unit,
    onToggleSavedInLibrary: (MangaSeries) -> Unit,
    onToggleFavorite: (MangaSeries) -> Unit,
    onOpenSourceInWebView: (MangaSourceSite) -> Unit,
    onOpenAddWebsiteDialog: () -> Unit
) {
    val activeSource = uiState.activeSource
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 8.dp)
                    ) {
                        Text(
                            text = "Explore & Sources (${uiState.sources.size})",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "7 Built-In Engines + Custom Websites",
                            style = MaterialTheme.typography.bodySmall,
                            color = WebReaderPalette.TextMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilledTonalIconButton(
                            onClick = { onOpenSourceInWebView(activeSource) },
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = WebReaderPalette.InteractiveSurface,
                                contentColor = WebReaderPalette.AccentSky
                            ),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .semantics { contentDescription = "Open ${activeSource.name} in Clean Browser" }
                        ) {
                            Icon(Icons.Default.OpenInBrowser, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                        FilledTonalIconButton(
                            onClick = onOpenAddWebsiteDialog,
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = WebReaderPalette.PrimaryBlue,
                                contentColor = WebReaderPalette.TextPrimary
                            ),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .semantics { contentDescription = "Add custom manga website" }
                        ) {
                            Icon(Icons.Default.AddLink, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Horizontal Source Selector Chips (All 7 built-in + Custom sites)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(uiState.sources, key = { it.id }) { source ->
                        val isSelected = source.id == activeSource.id
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSelectSource(source.id) },
                            label = {
                                Text(
                                    text = if (source.isBuiltIn) "★ ${source.name}" else "🌐 ${source.name}",
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            shape = WebReaderShapes.FilterChip,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(source.accentColorHex).copy(alpha = 0.28f),
                                selectedLabelColor = WebReaderPalette.TextPrimary
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Search bar for active source with keyboard ImeAction.Search handling
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = uiState.browseQuery,
                        onValueChange = onQueryChange,
                        placeholder = {
                            Text(
                                text = "Search ${activeSource.name} or paste URL...",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = null, tint = WebReaderPalette.AccentSky)
                        },
                        trailingIcon = {
                            if (uiState.browseQuery.isNotEmpty()) {
                                IconButton(
                                    onClick = {
                                        onQueryChange("")
                                        onExecuteSearch("")
                                        focusManager.clearFocus()
                                    },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear search")
                                }
                            }
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(
                            onSearch = {
                                focusManager.clearFocus()
                                keyboardController?.hide()
                                val q = uiState.browseQuery.trim()
                                if (q.startsWith("http://") || q.startsWith("https://")) {
                                    onOpenSourceInWebView(activeSource.copy(baseUrl = q))
                                } else {
                                    onExecuteSearch(q)
                                }
                            }
                        ),
                        shape = WebReaderShapes.SearchPill,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            focusManager.clearFocus()
                            keyboardController?.hide()
                            val q = uiState.browseQuery.trim()
                            if (q.startsWith("http://") || q.startsWith("https://")) {
                                onOpenSourceInWebView(activeSource.copy(baseUrl = q))
                            } else {
                                onExecuteSearch(q)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = WebReaderPalette.PrimaryBlue),
                        shape = WebReaderShapes.SearchPill,
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Text("Go", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Active Source Info & Direct WebView Banner
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${activeSource.name} • ${activeSource.parserType.displayName}",
                        color = WebReaderPalette.AccentSky,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = activeSource.baseUrl,
                        color = WebReaderPalette.TextMuted,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                TextButton(
                    onClick = { onOpenSourceInWebView(activeSource) },
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Default.Language, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Open Site", style = MaterialTheme.typography.labelMedium, color = WebReaderPalette.AccentSky)
                }
            }
        }

        // Offline / Website-Blocked (Cloudflare) Info Banner when present
        uiState.browseErrorMessage?.let { warningText ->
            Surface(
                color = WebReaderPalette.WarningAmber.copy(alpha = 0.14f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudOff,
                            contentDescription = null,
                            tint = WebReaderPalette.WarningAmber,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = warningText,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    TextButton(
                        onClick = { onExecuteSearch(uiState.browseQuery) },
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                        Text(" Retry", style = MaterialTheme.typography.labelMedium, color = WebReaderPalette.WarningAmber)
                    }
                }
            }
        }

        when {
            uiState.isBrowseLoading -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = WebReaderPalette.AccentSky)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Scraping live catalog from ${activeSource.name}...",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            uiState.browseResults.isEmpty() -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.CloudOff,
                            contentDescription = null,
                            tint = WebReaderPalette.WarningAmber,
                            modifier = Modifier.size(42.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Direct catalog scrape unavailable on ${activeSource.name}",
                            color = MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "${activeSource.name} may use interactive Cloudflare verification or device is offline. Open the site in Clean Browser Reader to pass verification and extract chapters directly.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { onExecuteSearch(uiState.browseQuery) },
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("  Retry Scrape")
                            }
                            Button(
                                onClick = { onOpenSourceInWebView(activeSource) },
                                colors = ButtonDefaults.buttonColors(containerColor = WebReaderPalette.PrimaryBlue),
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Icon(Icons.Default.OpenInBrowser, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Open Clean Browser")
                            }
                        }
                    }
                }
            }
            else -> {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 128.dp),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(uiState.browseResults, key = { it.id }) { manga ->
                        MangaGridCard(
                            manga = manga,
                            onClick = { onOpenMangaDetail(manga) },
                            onToggleSaved = { onToggleSavedInLibrary(manga) },
                            onToggleFavorite = { onToggleFavorite(manga) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryAndBookmarksTabScreen(
    uiState: WebReaderUiState,
    onResumeHistoryItem: (ReadingHistoryRecord) -> Unit,
    onOpenBookmarkItem: (PageBookmarkItem) -> Unit,
    onRemoveBookmark: (String) -> Unit,
    onClearHistory: () -> Unit,
    onOpenChapterUpdate: (MangaSeries, ChapterItem) -> Unit
) {
    var selectedSubTab by rememberSaveable { mutableIntStateOf(0) }
    val dateFormat = remember { SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()) }

    // Recent chapter updates across saved library & catalog
    val recentUpdates = remember(uiState.savedLibrarySeries, uiState.starterCatalogSeries) {
        val base = (uiState.savedLibrarySeries + uiState.starterCatalogSeries).distinctBy { it.id }
        base.flatMap { series ->
            series.chapters.take(2).map { ch -> series to ch }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Surface(color = MaterialTheme.colorScheme.surface) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Activity, Bookmarks & Updates",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (selectedSubTab == 0 && uiState.historyRecords.isNotEmpty()) {
                        TextButton(
                            onClick = onClearHistory,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Clear", color = WebReaderPalette.DangerRose)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(
                            selected = selectedSubTab == 0,
                            onClick = { selectedSubTab = 0 },
                            label = { Text("History (${uiState.historyRecords.size})") },
                            shape = WebReaderShapes.FilterChip
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedSubTab == 1,
                            onClick = { selectedSubTab = 1 },
                            label = { Text("Bookmarks (${uiState.pageBookmarks.size})") },
                            shape = WebReaderShapes.FilterChip
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedSubTab == 2,
                            onClick = { selectedSubTab = 2 },
                            label = { Text("Updates (${recentUpdates.size})") },
                            shape = WebReaderShapes.FilterChip
                        )
                    }
                }
            }
        }

        when (selectedSubTab) {
            0 -> {
                if (uiState.historyRecords.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(28.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = null,
                                tint = WebReaderPalette.TextMuted,
                                modifier = Modifier.size(44.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "No reading history yet",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Open any manga or webtoon chapter to automatically track your reading progress here.",
                                style = MaterialTheme.typography.bodySmall,
                                color = WebReaderPalette.TextMuted,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(uiState.historyRecords, key = { it.id }) { rec ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                shape = WebReaderShapes.ElevatedCard,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onResumeHistoryItem(rec) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    MangaCoverImage(
                                        coverUrl = rec.mangaCoverUrl,
                                        title = rec.mangaTitle,
                                        refererUrl = rec.chapterUrl,
                                        accentColorHex = WebReaderPalette.PrimaryBlueHex,
                                        modifier = Modifier
                                            .size(width = 52.dp, height = 72.dp)
                                            .clip(WebReaderShapes.BadgePill)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = rec.mangaTitle,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${rec.chapterTitle} • Page ${rec.lastPageIndex + 1}",
                                            color = WebReaderPalette.AccentSky,
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                        Text(
                                            text = "${rec.sourceName} • ${dateFormat.format(Date(rec.timestampMs))}",
                                            color = WebReaderPalette.TextMuted,
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                    FilledTonalButton(
                                        onClick = { onResumeHistoryItem(rec) },
                                        modifier = Modifier.heightIn(min = 48.dp)
                                    ) {
                                        Text("Resume", style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            1 -> {
                if (uiState.pageBookmarks.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(28.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.BookmarkBorder,
                                contentDescription = null,
                                tint = WebReaderPalette.TextMuted,
                                modifier = Modifier.size(44.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "No bookmarked pages yet",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Tap the Bookmark icon inside the comic reader toolbar to save favorite panels and pages.",
                                style = MaterialTheme.typography.bodySmall,
                                color = WebReaderPalette.TextMuted,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(uiState.pageBookmarks, key = { it.id }) { bm ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                shape = WebReaderShapes.ElevatedCard,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onOpenBookmarkItem(bm) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Bookmark,
                                        contentDescription = null,
                                        tint = WebReaderPalette.FavoriteGold
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = bm.mangaTitle,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${bm.chapterTitle} • Saved Page ${bm.pageIndex + 1}",
                                            color = WebReaderPalette.AccentSky,
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                    IconButton(
                                        onClick = { onRemoveBookmark(bm.id) },
                                        modifier = Modifier.minimumInteractiveComponentSize()
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteOutline,
                                            contentDescription = "Delete bookmark",
                                            tint = WebReaderPalette.DangerRose
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else -> {
                if (recentUpdates.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(28.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Open a series in your Library to fetch its latest chapter updates.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(recentUpdates, key = { "${it.first.id}_${it.second.id}" }) { (series, chapter) ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                shape = WebReaderShapes.ElevatedCard,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onOpenChapterUpdate(series, chapter) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    MangaCoverImage(
                                        coverUrl = series.coverUrl,
                                        title = series.title,
                                        refererUrl = series.mangaUrl,
                                        accentColorHex = series.coverColorHex,
                                        modifier = Modifier
                                            .size(width = 48.dp, height = 66.dp)
                                            .clip(WebReaderShapes.BadgePill)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = series.title,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = chapter.title,
                                            color = WebReaderPalette.AccentSky,
                                            style = MaterialTheme.typography.bodySmall,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${series.sourceName} • ${chapter.uploadDateText}",
                                            color = WebReaderPalette.TextMuted,
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                    if (chapter.isDownloaded) {
                                        Icon(
                                            imageVector = Icons.Default.DownloadDone,
                                            contentDescription = "Downloaded",
                                            tint = WebReaderPalette.SuccessEmerald,
                                            modifier = Modifier.padding(end = 6.dp)
                                        )
                                    }
                                    FilledTonalButton(
                                        onClick = { onOpenChapterUpdate(series, chapter) },
                                        modifier = Modifier.heightIn(min = 48.dp)
                                    ) {
                                        Text("Read", style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BackupAndSettingsTabScreen(
    uiState: WebReaderUiState,
    onRequestImportBackup: () -> Unit,
    onRequestExportBackup: () -> Unit,
    onOpenAddWebsiteDialog: () -> Unit,
    onSetAdBlock: (Boolean) -> Unit,
    onSetDataSaver: (Boolean) -> Unit,
    onSetAmoledDark: (Boolean) -> Unit,
    onSetDefaultReaderMode: (ReaderMode) -> Unit,
    onClearImageCache: () -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        item {
            Text(
                text = "Tachiyomi Backup & Settings",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Standard .tachibk / .proto.gz & Kotatsu .zip Compatible",
                style = MaterialTheme.typography.bodySmall,
                color = WebReaderPalette.TextMuted
            )
        }

        // Standard Tachiyomi Backup Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = WebReaderShapes.ElevatedCard
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Backup, contentDescription = null, tint = WebReaderPalette.AccentSky)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Standard Tachiyomi & Kotatsu Backups",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Import your real .tachibk, .proto.gz, JSON, or Kotatsu .zip backup file. WebReader restores series URLs, categories, Saved vs. Favorite status, chapter read progress, and automatically registers custom websites.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onRequestImportBackup,
                            colors = ButtonDefaults.buttonColors(containerColor = WebReaderPalette.PrimaryBlue),
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Icon(Icons.Default.FileUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Import Backup")
                        }
                        OutlinedButton(
                            onClick = onRequestExportBackup,
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Text("Export .tachibk")
                        }
                    }

                    uiState.lastBackupSummary?.let { summary ->
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            color = WebReaderPalette.SuccessEmerald.copy(alpha = 0.15f),
                            shape = WebReaderShapes.CoverTitleOverlay
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "Last Import: ${summary.formatName}",
                                    color = WebReaderPalette.SuccessEmerald,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = "• Restored ${summary.importedMangaCount} series & ${summary.importedChaptersCount} chapters",
                                    color = MaterialTheme.colorScheme.onSurface,
                                    style = MaterialTheme.typography.bodySmall
                                )
                                if (summary.autoCreatedCustomSites.isNotEmpty()) {
                                    Text(
                                        text = "• Auto-added sites: ${summary.autoCreatedCustomSites.joinToString()}",
                                        color = WebReaderPalette.AccentSky,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Custom Website Builder Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = WebReaderShapes.ElevatedCard
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Language, contentDescription = null, tint = WebReaderPalette.SuccessEmerald)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Built-In & Custom Manga Websites (${uiState.sources.size})",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Pre-configured: MangaEffect, ManhwaTop, ManhuaTop, MangaTown, MangaDex, Asura Scans, and Bato.to. Add any other website URL to read without installing external APKs.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    FilledTonalButton(
                        onClick = onOpenAddWebsiteDialog,
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Default.AddLink, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Custom Website URL")
                    }
                }
            }
        }

        // Reader & Theme Preferences Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = WebReaderShapes.ElevatedCard
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = WebReaderPalette.FavoriteGold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Theme, Reader & Ad-Blocker Settings",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Default Reader Mode", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.titleSmall)
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(ReaderMode.values().toList()) { mode ->
                            FilterChip(
                                selected = uiState.defaultReaderMode == mode,
                                onClick = { onSetDefaultReaderMode(mode) },
                                label = { Text(mode.shortTag) },
                                shape = WebReaderShapes.FilterChip
                            )
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outline)

                    SettingToggleRow(
                        title = "Ad-Block & Clean Reader CSS",
                        subtitle = "Blocks popups, ad networks, and overlays in WebView & scrapers",
                        checked = uiState.adBlockEnabled,
                        onCheckedChange = onSetAdBlock
                    )

                    SettingToggleRow(
                        title = "Data Saver (Compressed Images)",
                        subtitle = "Uses compressed MangaDex & proxy images for faster cellular loading",
                        checked = uiState.dataSaverEnabled,
                        onCheckedChange = onSetDataSaver
                    )

                    SettingToggleRow(
                        title = "True AMOLED Pitch-Black Theme",
                        subtitle = "Switch between Pure Black (#000000) and Deep Obsidian (#0A0E17)",
                        checked = uiState.amoledDarkMode,
                        onCheckedChange = onSetAmoledDark
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = onClearImageCache,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                    ) {
                        Text("Clear Disk & Memory Image Cache")
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(end = 12.dp)
        ) {
            Text(text = title, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium, style = MaterialTheme.typography.bodyMedium)
            Text(text = subtitle, color = WebReaderPalette.TextMuted, style = MaterialTheme.typography.bodySmall)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.minimumInteractiveComponentSize()
        )
    }
}

@Composable
fun AddCustomWebsiteDialog(
    onDismiss: () -> Unit,
    onConfirmAdd: (name: String, url: String) -> Unit
) {
    var siteName by rememberSaveable { mutableStateOf("") }
    var siteUrl by rememberSaveable { mutableStateOf("https://") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        titleContentColor = MaterialTheme.colorScheme.onSurface,
        textContentColor = MaterialTheme.colorScheme.onSurfaceVariant,
        title = { Text("Add Custom Manga Website", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Enter any manga, manhwa, or webtoon website (e.g. bato.to, mangabuddy.com, mangakakalot.com). WebReader will enable both native scraping and Clean Ad-Free Browser reading.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = siteName,
                    onValueChange = { siteName = it },
                    label = { Text("Website Name (optional)") },
                    placeholder = { Text("e.g. Bato Mirror / FlameScans") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = siteUrl,
                    onValueChange = { siteUrl = it },
                    label = { Text("Website URL") },
                    placeholder = { Text("https://bato.to") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmAdd(siteName, siteUrl) },
                colors = ButtonDefaults.buttonColors(containerColor = WebReaderPalette.PrimaryBlue),
                modifier = Modifier.heightIn(min = 48.dp)
            ) {
                Text("Add Website")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.heightIn(min = 48.dp)
            ) {
                Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    )
}
