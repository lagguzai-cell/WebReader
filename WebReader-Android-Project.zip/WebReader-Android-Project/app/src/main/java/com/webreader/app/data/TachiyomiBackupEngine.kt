package com.webreader.app.data

import com.webreader.app.model.BackupImportSummary
import com.webreader.app.model.ChapterItem
import com.webreader.app.model.MangaSeries
import com.webreader.app.model.MangaSourceSite
import com.webreader.app.model.ReaderMode
import com.webreader.app.model.ReadingHistoryRecord
import com.webreader.app.model.SourceParserType
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import java.util.zip.ZipInputStream

/**
 * Standard Tachiyomi Backup (.tachibk / .proto.gz) & Kotatsu (.zip) Engine.
 * Preserves real manga URLs, chapter URLs, cover URLs, read progress, saved library status,
 * favorites, and categories so restored series load live chapters and pages immediately!
 */
object TachiyomiBackupEngine {

    data class ParsedBackupPayload(
        val summary: BackupImportSummary,
        val seriesList: List<MangaSeries>,
        val customSites: List<MangaSourceSite>,
        val categories: List<String>,
        val historyRecords: List<ReadingHistoryRecord>
    )

    fun importBackupBytes(
        rawBytes: ByteArray,
        fileName: String,
        existingSources: List<MangaSourceSite>
    ): Result<ParsedBackupPayload> {
        return try {
            if (rawBytes.isEmpty()) {
                return Result.failure(IllegalArgumentException("The selected backup file is empty."))
            }

            // 1. Check ZIP magic bytes (Kotatsu backup .zip)
            if (rawBytes.size >= 4 && rawBytes[0] == 0x50.toByte() && rawBytes[1] == 0x4B.toByte()) {
                return parseKotatsuZipBackup(rawBytes, fileName, existingSources)
            }

            // 2. Decompress GZIP if magic bytes 0x1F 0x8B are present (standard .tachibk / .proto.gz)
            val payloadBytes = if (rawBytes.size >= 2 && rawBytes[0] == 0x1F.toByte() && rawBytes[1] == 0x8B.toByte()) {
                GZIPInputStream(ByteArrayInputStream(rawBytes)).use { it.readBytes() }
            } else {
                rawBytes
            }

            // 3. Check if decompressed payload starts with JSON '{' (0x7B) or '[' (0x5B)
            val trimmedStart = payloadBytes.dropWhile {
                it == 0x20.toByte() || it == 0x0A.toByte() || it == 0x0D.toByte() || it == 0x09.toByte()
            }
            if (trimmedStart.isNotEmpty() && (trimmedStart.first() == 0x7B.toByte() || trimmedStart.first() == 0x5B.toByte())) {
                return parseJsonBackup(payloadBytes.toString(Charsets.UTF_8), fileName, existingSources)
            }

            // 4. Parse standard Tachiyomi Protobuf wire format (.tachibk / .proto.gz)
            parseTachiyomiProtobuf(payloadBytes, fileName, existingSources)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun exportTachiyomiProtoGz(
        seriesList: List<MangaSeries>,
        categories: List<String>,
        sources: List<MangaSourceSite>
    ): ByteArray {
        val rootOut = ByteArrayOutputStream()

        categories.forEachIndexed { index, catName ->
            val catBytes = ProtoWriter().apply {
                writeString(1, catName)
                writeVarintField(2, index.toLong())
            }.toByteArray()
            ProtoWriter.writeBytesFieldTo(rootOut, 2, catBytes)
        }

        sources.forEach { src ->
            val srcBytes = ProtoWriter().apply {
                writeString(1, src.name)
                writeVarintField(2, src.tachiyomiSourceId)
            }.toByteArray()
            ProtoWriter.writeBytesFieldTo(rootOut, 101, srcBytes)
        }

        seriesList.forEach { manga ->
            val matchedSource = sources.find { it.id == manga.sourceId }
            val sourceIdLong = matchedSource?.tachiyomiSourceId ?: (manga.sourceId.hashCode().toLong() and 0x7FFFFFFFL)
            val catIndex = categories.indexOf(manga.categoryName).coerceAtLeast(0)

            val mangaBytes = ProtoWriter().apply {
                writeVarintField(1, sourceIdLong)
                writeString(2, manga.mangaUrl)
                writeString(3, manga.title)
                writeString(4, manga.artist.ifBlank { manga.author })
                writeString(5, manga.author)
                writeString(6, manga.description)
                manga.genres.forEach { g -> writeString(7, g) }
                writeVarintField(8, if (manga.status.equals("Completed", true)) 2L else 1L)
                if (manga.coverUrl.isNotBlank()) writeString(9, manga.coverUrl)
                writeVarintField(13, manga.dateAdded)
                manga.chapters.forEach { ch ->
                    val chBytes = ProtoWriter().apply {
                        writeString(1, ch.url)
                        writeString(2, ch.title)
                        writeString(3, ch.scanlator)
                        writeVarintField(4, if (ch.isRead) 1L else 0L)
                        writeVarintField(5, if (ch.isBookmarked) 1L else 0L)
                        writeVarintField(6, ch.lastPageRead.toLong())
                        writeFloatField(9, ch.number)
                    }.toByteArray()
                    writeBytesField(16, chBytes)
                }
                writeVarintField(17, catIndex.toLong())
                writeVarintField(100, if (manga.isFavorite) 1L else 0L)
                writeVarintField(102, if (manga.isSavedInLibrary) 1L else 0L)
            }.toByteArray()

            ProtoWriter.writeBytesFieldTo(rootOut, 1, mangaBytes)
        }

        val compressedOut = ByteArrayOutputStream()
        GZIPOutputStream(compressedOut).use { gzip ->
            gzip.write(rootOut.toByteArray())
        }
        return compressedOut.toByteArray()
    }

    private fun parseTachiyomiProtobuf(
        bytes: ByteArray,
        fileName: String,
        existingSources: List<MangaSourceSite>
    ): Result<ParsedBackupPayload> {
        val reader = ProtoReader(bytes)
        val rawCategories = mutableMapOf<Int, String>()
        val rawSources = mutableMapOf<Long, String>()
        val rawMangas = mutableListOf<ByteArray>()
        var categoryCounter = 0

        while (!reader.isAtEnd()) {
            val tag = reader.readTag()
            if (tag == 0) break
            val fieldNumber = tag ushr 3
            val wireType = tag and 0x07

            when (fieldNumber) {
                1 -> if (wireType == 2) rawMangas.add(reader.readBytes()) else reader.skipField(wireType)
                2 -> if (wireType == 2) {
                    val catBytes = reader.readBytes()
                    val (catName, catOrder) = parseBackupCategory(catBytes, categoryCounter)
                    rawCategories[catOrder] = catName
                    categoryCounter++
                } else reader.skipField(wireType)
                100, 101 -> if (wireType == 2) {
                    val srcBytes = reader.readBytes()
                    val (srcId, srcName) = parseBackupSource(srcBytes)
                    if (srcName.isNotBlank()) rawSources[srcId] = srcName
                } else reader.skipField(wireType)
                else -> reader.skipField(wireType)
            }
        }

        val discoveredCustomSites = mutableListOf<MangaSourceSite>()
        val importedSeries = mutableListOf<MangaSeries>()
        val importedHistory = mutableListOf<ReadingHistoryRecord>()
        var totalChaptersCount = 0

        rawMangas.forEachIndexed { idx, mangaBytes ->
            val parsed = parseBackupManga(
                mangaBytes = mangaBytes,
                index = idx,
                categoryMap = rawCategories,
                sourceMap = rawSources,
                existingSources = existingSources,
                discoveredCustomSites = discoveredCustomSites,
                historyOut = importedHistory
            )
            if (parsed != null) {
                importedSeries.add(parsed)
                totalChaptersCount += parsed.chapters.size
            }
        }

        val allCategories = (listOf("All", "Manhwa & Webtoons", "Manga", "Manhua") + rawCategories.values)
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()

        val summary = BackupImportSummary(
            formatName = "Tachiyomi Protobuf (.tachibk)",
            importedMangaCount = importedSeries.size,
            importedChaptersCount = totalChaptersCount,
            importedCategories = allCategories,
            autoCreatedCustomSites = discoveredCustomSites.map { "${it.name} (${it.baseUrl})" },
            message = "Restored ${importedSeries.size} series & $totalChaptersCount chapters from $fileName."
        )

        return Result.success(
            ParsedBackupPayload(
                summary = summary,
                seriesList = importedSeries,
                customSites = discoveredCustomSites,
                categories = allCategories,
                historyRecords = importedHistory
            )
        )
    }

    private fun parseBackupCategory(bytes: ByteArray, defaultOrder: Int): Pair<String, Int> {
        val r = ProtoReader(bytes)
        var name = "Imported"
        var order = defaultOrder
        while (!r.isAtEnd()) {
            val tag = r.readTag()
            if (tag == 0) break
            val fn = tag ushr 3
            val wt = tag and 0x07
            when (fn) {
                1 -> if (wt == 2) name = r.readString() else r.skipField(wt)
                2 -> if (wt == 0) order = r.readVarint().toInt() else r.skipField(wt)
                else -> r.skipField(wt)
            }
        }
        return name to order
    }

    private fun parseBackupSource(bytes: ByteArray): Pair<Long, String> {
        val r = ProtoReader(bytes)
        var name = ""
        var sourceId = 0L
        while (!r.isAtEnd()) {
            val tag = r.readTag()
            if (tag == 0) break
            val fn = tag ushr 3
            val wt = tag and 0x07
            when (fn) {
                1 -> if (wt == 2) name = r.readString() else r.skipField(wt)
                2 -> if (wt == 0) sourceId = r.readVarint() else r.skipField(wt)
                else -> r.skipField(wt)
            }
        }
        return sourceId to name
    }

    private fun parseBackupManga(
        mangaBytes: ByteArray,
        index: Int,
        categoryMap: Map<Int, String>,
        sourceMap: Map<Long, String>,
        existingSources: List<MangaSourceSite>,
        discoveredCustomSites: MutableList<MangaSourceSite>,
        historyOut: MutableList<ReadingHistoryRecord>
    ): MangaSeries? {
        val r = ProtoReader(mangaBytes)
        var sourceIdLong = 0L
        var url = ""
        var title = ""
        var artist = ""
        var author = ""
        var description = ""
        val genres = mutableListOf<String>()
        var statusInt = 1
        var thumbnailUrl = ""
        var dateAdded = System.currentTimeMillis()
        val rawChapters = mutableListOf<ByteArray>()
        val categoryIds = mutableListOf<Int>()
        var isFavorite = true
        var isSavedInLibrary = true

        while (!r.isAtEnd()) {
            val tag = r.readTag()
            if (tag == 0) break
            val fn = tag ushr 3
            val wt = tag and 0x07
            when (fn) {
                1 -> if (wt == 0) sourceIdLong = r.readVarint() else r.skipField(wt)
                2 -> if (wt == 2) url = r.readString() else r.skipField(wt)
                3 -> if (wt == 2) title = r.readString() else r.skipField(wt)
                4 -> if (wt == 2) artist = r.readString() else r.skipField(wt)
                5 -> if (wt == 2) author = r.readString() else r.skipField(wt)
                6 -> if (wt == 2) description = r.readString() else r.skipField(wt)
                7 -> if (wt == 2) genres.add(r.readString()) else r.skipField(wt)
                8 -> if (wt == 0) statusInt = r.readVarint().toInt() else r.skipField(wt)
                9 -> if (wt == 2) thumbnailUrl = r.readString() else r.skipField(wt)
                13 -> if (wt == 0) dateAdded = r.readVarint() else r.skipField(wt)
                16 -> if (wt == 2) rawChapters.add(r.readBytes()) else r.skipField(wt)
                17 -> if (wt == 0) categoryIds.add(r.readVarint().toInt())
                else if (wt == 2) {
                    val packed = ProtoReader(r.readBytes())
                    while (!packed.isAtEnd()) categoryIds.add(packed.readVarint().toInt())
                } else r.skipField(wt)
                100 -> if (wt == 0) isFavorite = r.readVarint() != 0L else r.skipField(wt)
                102 -> if (wt == 0) isSavedInLibrary = r.readVarint() != 0L else r.skipField(wt)
                else -> r.skipField(wt)
            }
        }

        if (title.isBlank()) return null

        val backupSourceName = sourceMap[sourceIdLong] ?: ""
        val matchedSite = resolveOrRegisterSource(
            sourceIdLong = sourceIdLong,
            backupSourceName = backupSourceName,
            mangaUrl = url,
            existingSources = existingSources,
            discoveredCustomSites = discoveredCustomSites
        )

        val mangaId = "tachi_${index}_${title.lowercase().replace(Regex("[^a-z0-9]+"), "_").take(24)}"
        val fullMangaUrl = if (url.startsWith("http")) url else "${matchedSite.baseUrl}/${url.trimStart('/')}"

        val parsedChapters = rawChapters.mapIndexed { chIdx, chBytes ->
            parseBackupChapter(chBytes, mangaId, matchedSite.baseUrl, matchedSite.name, chIdx + 1)
        }

        val resolvedCategory = categoryIds.firstNotNullOfOrNull { categoryMap[it] } ?: "All"
        val paletteColors = listOf(0xFF2563EB, 0xFF8B5CF6, 0xFFEF4444, 0xFF10B981, 0xFFF59E0B, 0xFF06B6D4)

        return MangaSeries(
            id = mangaId,
            sourceId = matchedSite.id,
            sourceName = matchedSite.name,
            title = title,
            author = author.ifBlank { matchedSite.name },
            artist = artist,
            description = description.ifBlank { "Restored from Tachiyomi backup (${matchedSite.name}). Tap to refresh live chapters." },
            status = if (statusInt == 2) "Completed" else "Ongoing",
            genres = genres.ifEmpty { listOf(matchedSite.name) },
            mangaUrl = fullMangaUrl,
            coverUrl = thumbnailUrl,
            coverColorHex = paletteColors[index % paletteColors.size],
            isSavedInLibrary = isSavedInLibrary || isFavorite,
            isFavorite = isFavorite,
            categoryName = resolvedCategory,
            preferredReaderMode = matchedSite.defaultReaderMode,
            chapters = parsedChapters,
            dateAdded = dateAdded
        )
    }

    private fun parseBackupChapter(
        bytes: ByteArray,
        mangaId: String,
        baseUrl: String,
        sourceName: String,
        fallbackIndex: Int
    ): ChapterItem {
        val r = ProtoReader(bytes)
        var url = ""
        var name = ""
        var scanlator = ""
        var read = false
        var bookmark = false
        var lastPageRead = 0
        var chapterNumber = fallbackIndex.toFloat()

        while (!r.isAtEnd()) {
            val tag = r.readTag()
            if (tag == 0) break
            val fn = tag ushr 3
            val wt = tag and 0x07
            when (fn) {
                1 -> if (wt == 2) url = r.readString() else r.skipField(wt)
                2 -> if (wt == 2) name = r.readString() else r.skipField(wt)
                3 -> if (wt == 2) scanlator = r.readString() else r.skipField(wt)
                4 -> if (wt == 0) read = r.readVarint() != 0L else r.skipField(wt)
                5 -> if (wt == 0) bookmark = r.readVarint() != 0L else r.skipField(wt)
                6 -> if (wt == 0) lastPageRead = r.readVarint().toInt() else r.skipField(wt)
                9 -> if (wt == 5) chapterNumber = r.readFloat() else r.skipField(wt)
                else -> r.skipField(wt)
            }
        }

        val fullUrl = if (url.startsWith("http")) url else "$baseUrl/${url.trimStart('/')}"
        val cleanNumber = if (chapterNumber >= 0f) chapterNumber else fallbackIndex.toFloat()
        return ChapterItem(
            id = "${mangaId}_ch_$fallbackIndex",
            mangaId = mangaId,
            title = name.ifBlank { "Chapter ${cleanNumber.toInt()}" },
            number = cleanNumber,
            url = fullUrl,
            uploadDateText = "Restored",
            scanlator = scanlator.ifBlank { sourceName },
            isRead = read,
            isBookmarked = bookmark,
            lastPageRead = lastPageRead
        )
    }

    private fun resolveOrRegisterSource(
        sourceIdLong: Long,
        backupSourceName: String,
        mangaUrl: String,
        existingSources: List<MangaSourceSite>,
        discoveredCustomSites: MutableList<MangaSourceSite>
    ): MangaSourceSite {
        val allKnown = existingSources + discoveredCustomSites
        allKnown.find { it.tachiyomiSourceId == sourceIdLong }?.let { return it }

        val searchTarget = "$backupSourceName $mangaUrl".lowercase()
        allKnown.find { site ->
            searchTarget.contains(site.id) || searchTarget.contains(site.name.lowercase().replace(" ", ""))
        }?.let { return it }

        val cleanName = backupSourceName.ifBlank {
            if (mangaUrl.startsWith("http")) SourceCatalogEngine.extractDomainLabel(mangaUrl) else "MangaDex"
        }
        val slug = cleanName.lowercase().replace(Regex("[^a-z0-9]+"), "").ifBlank { "source_$sourceIdLong" }
        val inferredUrl = if (mangaUrl.startsWith("http")) {
            val parts = mangaUrl.split("/")
            if (parts.size >= 3) "${parts[0]}//${parts[2]}" else "https://$slug.com"
        } else {
            "https://$slug.com"
        }

        val newSite = MangaSourceSite(
            id = "custom_$slug",
            tachiyomiSourceId = if (sourceIdLong != 0L) sourceIdLong else slug.hashCode().toLong(),
            name = cleanName,
            baseUrl = inferredUrl,
            mirrors = listOf(inferredUrl),
            language = "EN",
            parserType = SourceParserType.CUSTOM_SMART,
            defaultReaderMode = ReaderMode.AUTO,
            isPinnedFavorite = true,
            isBuiltIn = false,
            accentColorHex = 0xFF0EA5E9
        )
        discoveredCustomSites.add(newSite)
        return newSite
    }

    private fun parseJsonBackup(
        jsonText: String,
        fileName: String,
        existingSources: List<MangaSourceSite>
    ): Result<ParsedBackupPayload> {
        val root = JSONObject(jsonText)
        val mangaArr = root.optJSONArray("backupManga")
            ?: root.optJSONArray("mangas")
            ?: root.optJSONArray("favourites")
            ?: JSONArray()

        val discoveredSites = mutableListOf<MangaSourceSite>()
        val importedSeries = mutableListOf<MangaSeries>()

        for (i in 0 until mangaArr.length()) {
            val obj = mangaArr.optJSONObject(i) ?: continue
            val title = obj.optString("title").ifBlank { obj.optString("name", "Manga #${i + 1}") }
            val url = obj.optString("url", "https://mangadex.org")
            val cover = obj.optString("thumbnailUrl").ifBlank { obj.optString("coverUrl", "") }
            val sourceName = obj.optString("sourceName").ifBlank { obj.optString("source", "MangaDex") }
            val site = resolveOrRegisterSource(0L, sourceName, url, existingSources, discoveredSites)
            val mangaId = "json_${i}_${title.lowercase().replace(Regex("[^a-z0-9]+"), "_").take(20)}"
            val isFav = obj.optBoolean("isFavorite", true)

            importedSeries.add(
                MangaSeries(
                    id = mangaId,
                    sourceId = site.id,
                    sourceName = site.name,
                    title = title,
                    author = obj.optString("author", site.name),
                    description = obj.optString("description", "Restored from $fileName."),
                    status = obj.optString("status", "Ongoing"),
                    genres = listOf(site.name),
                    mangaUrl = if (url.startsWith("http")) url else "${site.baseUrl}/${url.trimStart('/')}",
                    coverUrl = cover,
                    coverColorHex = site.accentColorHex,
                    isSavedInLibrary = true,
                    isFavorite = isFav,
                    categoryName = obj.optString("category", "All"),
                    preferredReaderMode = site.defaultReaderMode
                )
            )
        }

        val summary = BackupImportSummary(
            formatName = "JSON Backup",
            importedMangaCount = importedSeries.size,
            importedChaptersCount = 0,
            importedCategories = listOf("All", "Manhwa & Webtoons", "Manga", "Manhua"),
            autoCreatedCustomSites = discoveredSites.map { it.name },
            message = "Restored ${importedSeries.size} series from $fileName."
        )
        return Result.success(
            ParsedBackupPayload(
                summary = summary,
                seriesList = importedSeries,
                customSites = discoveredSites,
                categories = summary.importedCategories,
                historyRecords = emptyList()
            )
        )
    }

    private fun parseKotatsuZipBackup(
        zipBytes: ByteArray,
        fileName: String,
        existingSources: List<MangaSourceSite>
    ): Result<ParsedBackupPayload> {
        val discoveredSites = mutableListOf<MangaSourceSite>()
        val importedSeries = mutableListOf<MangaSeries>()

        ZipInputStream(ByteArrayInputStream(zipBytes)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && (entry.name.contains("favourites") || entry.name.contains("history"))) {
                    val content = zis.readBytes().toString(Charsets.UTF_8)
                    val arr = if (content.trim().startsWith("[")) JSONArray(content) else JSONObject(content).optJSONArray("favourites") ?: JSONArray()
                    for (i in 0 until arr.length()) {
                        val item = arr.optJSONObject(i) ?: continue
                        val mangaObj = item.optJSONObject("manga") ?: item
                        val title = mangaObj.optString("title", "Kotatsu Manga #${i + 1}")
                        val url = mangaObj.optString("public_url").ifBlank { mangaObj.optString("url", "https://mangadex.org") }
                        val cover = mangaObj.optString("cover_url").ifBlank { mangaObj.optString("large_cover_url", "") }
                        val source = mangaObj.optString("source", "MangaDex")
                        val site = resolveOrRegisterSource(0L, source, url, existingSources, discoveredSites)
                        val mangaId = "kotatsu_${i}_${title.lowercase().replace(Regex("[^a-z0-9]+"), "_").take(20)}"
                        importedSeries.add(
                            MangaSeries(
                                id = mangaId,
                                sourceId = site.id,
                                sourceName = site.name,
                                title = title,
                                author = mangaObj.optString("author", site.name),
                                description = "Restored from Kotatsu backup ($fileName).",
                                status = "Ongoing",
                                genres = listOf(site.name),
                                mangaUrl = url,
                                coverUrl = cover,
                                coverColorHex = site.accentColorHex,
                                isSavedInLibrary = true,
                                isFavorite = entry.name.contains("favourites"),
                                categoryName = "All",
                                preferredReaderMode = site.defaultReaderMode
                            )
                        )
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        val summary = BackupImportSummary(
            formatName = "Kotatsu Archive (.zip)",
            importedMangaCount = importedSeries.size,
            importedChaptersCount = 0,
            importedCategories = listOf("All", "Manhwa & Webtoons", "Manga", "Manhua"),
            autoCreatedCustomSites = discoveredSites.map { it.name },
            message = "Restored ${importedSeries.size} series from Kotatsu backup $fileName."
        )
        return Result.success(
            ParsedBackupPayload(
                summary = summary,
                seriesList = importedSeries,
                customSites = discoveredSites,
                categories = summary.importedCategories,
                historyRecords = emptyList()
            )
        )
    }

    private class ProtoReader(private val data: ByteArray) {
        private var pos = 0

        fun isAtEnd(): Boolean = pos >= data.size

        fun readTag(): Int {
            if (isAtEnd()) return 0
            return readVarint().toInt()
        }

        fun readVarint(): Long {
            var result = 0L
            var shift = 0
            while (pos < data.size && shift < 64) {
                val b = data[pos++].toInt()
                result = result or ((b and 0x7F).toLong() shl shift)
                if ((b and 0x80) == 0) return result
                shift += 7
            }
            return result
        }

        fun readBytes(): ByteArray {
            val len = readVarint().toInt().coerceAtLeast(0)
            val safeLen = len.coerceAtMost(data.size - pos)
            val out = data.copyOfRange(pos, pos + safeLen)
            pos += safeLen
            return out
        }

        fun readString(): String = readBytes().toString(Charsets.UTF_8)

        fun readFloat(): Float {
            if (pos + 4 > data.size) {
                pos = data.size
                return 0f
            }
            val bits = (data[pos].toInt() and 0xFF) or
                ((data[pos + 1].toInt() and 0xFF) shl 8) or
                ((data[pos + 2].toInt() and 0xFF) shl 16) or
                ((data[pos + 3].toInt() and 0xFF) shl 24)
            pos += 4
            return Float.fromBits(bits)
        }

        fun skipField(wireType: Int) {
            when (wireType) {
                0 -> readVarint()
                1 -> pos = (pos + 8).coerceAtMost(data.size)
                2 -> {
                    val len = readVarint().toInt().coerceAtLeast(0)
                    pos = (pos + len).coerceAtMost(data.size)
                }
                5 -> pos = (pos + 4).coerceAtMost(data.size)
                else -> pos = data.size
            }
        }
    }

    private class ProtoWriter {
        private val out = ByteArrayOutputStream()

        fun writeVarintField(fieldNumber: Int, value: Long) {
            writeVarint(out, ((fieldNumber shl 3) or 0).toLong())
            writeVarint(out, value)
        }

        fun writeString(fieldNumber: Int, value: String) {
            writeBytesField(fieldNumber, value.toByteArray(Charsets.UTF_8))
        }

        fun writeBytesField(fieldNumber: Int, bytes: ByteArray) {
            writeBytesFieldTo(out, fieldNumber, bytes)
        }

        fun writeFloatField(fieldNumber: Int, value: Float) {
            writeVarint(out, ((fieldNumber shl 3) or 5).toLong())
            val bits = value.toRawBits()
            out.write(bits and 0xFF)
            out.write((bits ushr 8) and 0xFF)
            out.write((bits ushr 16) and 0xFF)
            out.write((bits ushr 24) and 0xFF)
        }

        fun toByteArray(): ByteArray = out.toByteArray()

        companion object {
            fun writeVarint(stream: ByteArrayOutputStream, value: Long) {
                var v = value
                while (true) {
                    if ((v and 0x7FL.inv()) == 0L) {
                        stream.write(v.toInt())
                        return
                    } else {
                        stream.write((v.toInt() and 0x7F) or 0x80)
                        v = v ushr 7
                    }
                }
            }

            fun writeBytesFieldTo(stream: ByteArrayOutputStream, fieldNumber: Int, bytes: ByteArray) {
                writeVarint(stream, ((fieldNumber shl 3) or 2).toLong())
                writeVarint(stream, bytes.size.toLong())
                stream.write(bytes)
            }
        }
    }
}
