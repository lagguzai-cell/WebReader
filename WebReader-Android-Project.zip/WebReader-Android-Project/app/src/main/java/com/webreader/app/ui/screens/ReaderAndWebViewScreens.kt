package com.webreader.app.ui.screens

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.webreader.app.data.SourceCatalogEngine
import com.webreader.app.model.ChapterItem
import com.webreader.app.model.MangaSeries
import com.webreader.app.model.ReaderMode
import com.webreader.app.ui.WebReaderUiState
import com.webreader.app.ui.components.ComicReaderPageImage
import com.webreader.app.ui.components.MangaCoverImage
import com.webreader.app.ui.theme.WebReaderPalette
import com.webreader.app.ui.theme.WebReaderShapes
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.io.ByteArrayInputStream

/**
 * Manga / Manhwa Series Detail & Chapter List Overlay Screen.
 * Clearly separates "Save in Library" from "Favorite ★" and adapts cleanly
 * on narrow 320dp screens and 1.5x system font scales.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun MangaDetailSheetScreen(
    manga: MangaSeries,
    isLoading: Boolean,
    statusMessage: String?,
    onBack: () -> Unit,
    onToggleSavedInLibrary: () -> Unit,
    onToggleFavorite: () -> Unit,
    onRefreshChapters: () -> Unit,
    onOpenChapter: (ChapterItem) -> Unit,
    onDownloadChapter: (ChapterItem) -> Unit,
    onOpenInWebView: (String, String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = manga.title,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            navigationIcon = {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onSurface)
                }
            },
            actions = {
                IconButton(
                    onClick = onRefreshChapters,
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh live chapters", tint = WebReaderPalette.AccentSky)
                }
                IconButton(
                    onClick = { onOpenInWebView(manga.mangaUrl, manga.title) },
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Default.OpenInBrowser, contentDescription = "Open in Clean Browser", tint = MaterialTheme.colorScheme.onSurface)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )

        if (isLoading) {
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth(),
                color = WebReaderPalette.AccentSky
            )
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    MangaCoverImage(
                        coverUrl = manga.coverUrl,
                        title = manga.title,
                        refererUrl = manga.mangaUrl,
                        accentColorHex = manga.coverColorHex,
                        sourceBadgeText = manga.sourceName,
                        modifier = Modifier
                            .size(width = 104.dp, height = 156.dp)
                            .clip(WebReaderShapes.CoverCard)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Surface(
                            color = Color(manga.coverColorHex).copy(alpha = 0.25f),
                            shape = WebReaderShapes.BadgePill
                        ) {
                            Text(
                                text = "${manga.sourceName} • ${manga.status}",
                                color = WebReaderPalette.AccentSky,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = manga.title,
                            color = MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.ExtraBold,
                            style = MaterialTheme.typography.titleLarge,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = manga.author,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        // Separated Saved-in-Library & Favorite ★ buttons + Browser Fallback (48dp touch targets)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = onToggleSavedInLibrary,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (manga.isSavedInLibrary) WebReaderPalette.InteractiveSurface else WebReaderPalette.PrimaryBlue
                                ),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Icon(
                                    imageVector = if (manga.isSavedInLibrary) Icons.Default.CheckCircle else Icons.Default.BookmarkBorder,
                                    contentDescription = null,
                                    tint = if (manga.isSavedInLibrary) WebReaderPalette.AccentSky else WebReaderPalette.TextPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (manga.isSavedInLibrary) "In Library" else "Save to Library",
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }

                            FilledTonalButton(
                                onClick = onToggleFavorite,
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = if (manga.isFavorite) {
                                        WebReaderPalette.FavoriteGold.copy(alpha = 0.22f)
                                    } else {
                                        WebReaderPalette.InteractiveSurface
                                    },
                                    contentColor = if (manga.isFavorite) WebReaderPalette.FavoriteGold else WebReaderPalette.TextPrimary
                                ),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Icon(
                                    imageVector = if (manga.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (manga.isFavorite) "Favorite ★" else "Star ★",
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }

                            OutlinedButton(
                                onClick = { onOpenInWebView(manga.mangaUrl, manga.title) },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Icon(Icons.Default.OpenInBrowser, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Browser", style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = manga.description,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            if (statusMessage != null) {
                item {
                    Surface(
                        color = WebReaderPalette.InteractiveSurface,
                        shape = WebReaderShapes.CoverTitleOverlay,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = statusMessage,
                            color = WebReaderPalette.AccentSky,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }

            item {
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Chapters (${manga.chapters.size})",
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                    if (manga.chapters.isNotEmpty()) {
                        val firstUnread = manga.chapters.lastOrNull { !it.isRead } ?: manga.chapters.first()
                        FilledTonalButton(
                            onClick = { onOpenChapter(firstUnread) },
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Start / Resume", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }

            if (manga.chapters.isEmpty() && !isLoading) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = WebReaderShapes.ElevatedCard,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Direct chapter list was blocked or requires JavaScript on ${manga.sourceName}.",
                                color = MaterialTheme.colorScheme.onSurface,
                                style = MaterialTheme.typography.bodyMedium,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { onOpenInWebView(manga.mangaUrl, manga.title) },
                                colors = ButtonDefaults.buttonColors(containerColor = WebReaderPalette.PrimaryBlue),
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Icon(Icons.Default.OpenInBrowser, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Read Series in Clean Browser")
                            }
                        }
                    }
                }
            } else {
                items(manga.chapters, key = { it.id }) { chapter ->
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (chapter.isRead) {
                                MaterialTheme.colorScheme.surface
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant
                            }
                        ),
                        shape = WebReaderShapes.CoverTitleOverlay,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenChapter(chapter) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = chapter.title,
                                    color = if (chapter.isRead) WebReaderPalette.TextMuted else MaterialTheme.colorScheme.onSurface,
                                    fontWeight = if (chapter.isRead) FontWeight.Normal else FontWeight.SemiBold,
                                    style = MaterialTheme.typography.bodyMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${chapter.scanlator.ifBlank { manga.sourceName }} • ${chapter.uploadDateText}",
                                    color = WebReaderPalette.TextMuted,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                            IconButton(
                                onClick = { onDownloadChapter(chapter) },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(
                                    imageVector = if (chapter.isDownloaded) Icons.Default.DownloadDone else Icons.Default.Download,
                                    contentDescription = "Cache Chapter for Offline Reading",
                                    tint = if (chapter.isDownloaded) WebReaderPalette.SuccessEmerald else WebReaderPalette.TextMuted
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Full-Screen Native Comic & Webtoon Reader Screen.
 * - Uses rememberSaveable for showHudBars so toolbar visibility survives orientation changes.
 * - Auto-hides floating HUD pills during vertical Webtoon scroll so comic panels are never obscured.
 * - Enables non-blocking multi-touch pinch-to-zoom (1x..4x) and double-tap zoom in BOTH Webtoon and Paged modes.
 */
@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun NativeComicReaderScreen(
    uiState: WebReaderUiState,
    onCloseReader: () -> Unit,
    onCycleReaderMode: () -> Unit,
    onUpdateCurrentPage: (Int) -> Unit,
    onTogglePageBookmark: () -> Unit,
    onSwitchChapter: (nextChapter: Boolean) -> Unit,
    onFallbackToWebView: (url: String, title: String) -> Unit
) {
    val manga = uiState.activeReadingManga ?: return
    val chapter = uiState.activeReadingChapter ?: return
    val pages = uiState.activeChapterPages
    val totalPages = pages.size.coerceAtLeast(1)

    var showHudBars by rememberSaveable { mutableStateOf(true) }
    val coroutineScope = rememberCoroutineScope()

    val webtoonListState = rememberLazyListState(
        initialFirstVisibleItemIndex = uiState.currentReaderPage.coerceIn(0, (pages.size - 1).coerceAtLeast(0))
    )
    val pagerState = rememberPagerState(
        initialPage = uiState.currentReaderPage.coerceIn(0, (pages.size - 1).coerceAtLeast(0)),
        pageCount = { pages.size.coerceAtLeast(1) }
    )

    val visibleWebtoonPage by remember {
        derivedStateOf { webtoonListState.firstVisibleItemIndex }
    }

    // Automatically hide floating HUD bars when the user starts scrolling in Webtoon mode
    LaunchedEffect(webtoonListState.isScrollInProgress) {
        if (webtoonListState.isScrollInProgress && showHudBars) {
            showHudBars = false
        }
    }

    LaunchedEffect(visibleWebtoonPage, uiState.activeReaderMode) {
        if (uiState.activeReaderMode == ReaderMode.WEBTOON && pages.isNotEmpty()) {
            onUpdateCurrentPage(visibleWebtoonPage)
        }
    }

    LaunchedEffect(pagerState.currentPage, uiState.activeReaderMode) {
        if (uiState.activeReaderMode != ReaderMode.WEBTOON && pages.isNotEmpty()) {
            onUpdateCurrentPage(pagerState.currentPage)
        }
    }

    val isCurrentPageBookmarked = uiState.pageBookmarks.any {
        it.chapterId == chapter.id && it.pageIndex == uiState.currentReaderPage
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(WebReaderPalette.AmoledPureBlack)
    ) {
        when {
            uiState.isReaderLoading -> {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(color = WebReaderPalette.AccentSky)
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Loading ${chapter.title} from ${manga.sourceName}...",
                        color = WebReaderPalette.TextPrimary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            pages.isEmpty() -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = uiState.readerErrorMessage ?: "No direct page images found.",
                        color = WebReaderPalette.TextPrimary,
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { onFallbackToWebView(chapter.url, "${manga.title} - ${chapter.title}") },
                        colors = ButtonDefaults.buttonColors(containerColor = WebReaderPalette.PrimaryBlue),
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Default.OpenInBrowser, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Open in Clean WebView Reader")
                    }
                }
            }
            uiState.activeReaderMode == ReaderMode.WEBTOON -> {
                // Continuous vertical Webtoon scroll with non-blocking multi-touch pinch zoom & double-tap zoom
                LazyColumn(
                    state = webtoonListState,
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(pages) { index, imgUrl ->
                        ComicReaderPageImage(
                            imageUrl = imgUrl,
                            pageNumber = index + 1,
                            totalPages = pages.size,
                            refererUrl = chapter.url,
                            enablePinchZoom = true,
                            onSingleTap = { showHudBars = !showHudBars }
                        )
                    }
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            OutlinedButton(
                                onClick = { onSwitchChapter(false) },
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Icon(Icons.Default.SkipPrevious, contentDescription = null)
                                Text(" Previous Chapter")
                            }
                            Button(
                                onClick = { onSwitchChapter(true) },
                                colors = ButtonDefaults.buttonColors(containerColor = WebReaderPalette.PrimaryBlue),
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Text("Next Chapter ")
                                Icon(Icons.Default.SkipNext, contentDescription = null)
                            }
                        }
                    }
                }
            }
            else -> {
                // Paged Reader (Left-to-Right or Right-to-Left Manga Mode) with non-blocking 1x-4x Pinch-to-Zoom
                val layoutDir = if (uiState.activeReaderMode == ReaderMode.RIGHT_TO_LEFT) {
                    LayoutDirection.Rtl
                } else {
                    LayoutDirection.Ltr
                }
                CompositionLocalProvider(LocalLayoutDirection provides layoutDir) {
                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxSize()
                    ) { pageIdx ->
                        ComicReaderPageImage(
                            imageUrl = pages[pageIdx],
                            pageNumber = pageIdx + 1,
                            totalPages = pages.size,
                            refererUrl = chapter.url,
                            enablePinchZoom = true,
                            onSingleTap = { showHudBars = !showHudBars },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }

        // Minimal non-obscuring page indicator pill when HUD is hidden (tap to expand HUD)
        AnimatedVisibility(
            visible = !showHudBars && pages.isNotEmpty(),
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(12.dp)
        ) {
            Surface(
                color = WebReaderPalette.GlassScrim,
                shape = WebReaderShapes.FilterChip,
                modifier = Modifier
                    .clickable { showHudBars = true }
                    .semantics { contentDescription = "Page ${uiState.currentReaderPage + 1} of $totalPages. Tap to show reader toolbar" }
            ) {
                Text(
                    text = "${uiState.currentReaderPage + 1} / $totalPages • ${uiState.activeReaderMode.shortTag}",
                    color = WebReaderPalette.TextSecondary,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }

        // Top Floating Compact Reader Toolbar (does not span edge-to-edge or obscure comic art)
        AnimatedVisibility(
            visible = showHudBars,
            enter = slideInVertically { -it } + fadeIn(),
            exit = slideOutVertically { -it } + fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            Surface(
                color = WebReaderPalette.GlassPillOverlay,
                shape = WebReaderShapes.FloatingHudPill,
                tonalElevation = 6.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onCloseReader,
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Close reader", tint = WebReaderPalette.TextPrimary)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = manga.title,
                            color = WebReaderPalette.TextPrimary,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${chapter.title} • ${uiState.activeReaderMode.shortTag}",
                            color = WebReaderPalette.AccentSky,
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    FilledTonalButton(
                        onClick = onCycleReaderMode,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .semantics { contentDescription = "Switch reader mode" }
                    ) {
                        Icon(Icons.Default.ScreenRotation, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(uiState.activeReaderMode.shortTag, style = MaterialTheme.typography.labelSmall)
                    }
                    IconButton(
                        onClick = onTogglePageBookmark,
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            imageVector = if (isCurrentPageBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "Bookmark current page",
                            tint = if (isCurrentPageBookmarked) WebReaderPalette.FavoriteGold else WebReaderPalette.TextPrimary
                        )
                    }
                    IconButton(
                        onClick = { onFallbackToWebView(chapter.url, chapter.title) },
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            imageVector = Icons.Default.OpenInBrowser,
                            contentDescription = "Open chapter in Clean Browser",
                            tint = WebReaderPalette.TextPrimary
                        )
                    }
                }
            }
        }

        // Bottom Floating Compact Scrubbing & Chapter Pill
        AnimatedVisibility(
            visible = showHudBars && pages.isNotEmpty(),
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            Surface(
                color = WebReaderPalette.GlassPillOverlay,
                shape = WebReaderShapes.FloatingHudPill,
                tonalElevation = 6.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    IconButton(
                        onClick = { onSwitchChapter(false) },
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipPrevious,
                            contentDescription = "Previous chapter",
                            tint = WebReaderPalette.TextPrimary
                        )
                    }

                    var sliderVal by remember(uiState.currentReaderPage) {
                        mutableFloatStateOf(uiState.currentReaderPage.toFloat())
                    }
                    Slider(
                        value = sliderVal.coerceIn(0f, (totalPages - 1).coerceAtLeast(0).toFloat()),
                        onValueChange = { sliderVal = it },
                        onValueChangeFinished = {
                            val targetPage = sliderVal.toInt().coerceIn(0, (pages.size - 1).coerceAtLeast(0))
                            onUpdateCurrentPage(targetPage)
                            coroutineScope.launch {
                                if (uiState.activeReaderMode == ReaderMode.WEBTOON) {
                                    webtoonListState.scrollToItem(targetPage)
                                } else {
                                    pagerState.scrollToPage(targetPage)
                                }
                            }
                        },
                        valueRange = 0f..(totalPages - 1).coerceAtLeast(1).toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = WebReaderPalette.AccentSky,
                            activeTrackColor = WebReaderPalette.PrimaryBlue
                        ),
                        modifier = Modifier.weight(1f)
                    )

                    Text(
                        text = "${uiState.currentReaderPage + 1}/$totalPages",
                        color = WebReaderPalette.TextPrimary,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )

                    IconButton(
                        onClick = { onSwitchChapter(true) },
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "Next chapter",
                            tint = WebReaderPalette.TextPrimary
                        )
                    }
                }
            }
        }
    }
}

/**
 * In-App Ad-Blocked Clean Browser & Smart Comic Page Extractor.
 * Enforces MIXED_CONTENT_NEVER_ALLOW and blocks ad network requests.
 */
@SuppressLint("SetJavaScriptEnabled")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InAppWebViewReaderScreen(
    url: String,
    title: String,
    adBlockEnabled: Boolean,
    onClose: () -> Unit,
    onExtractPagesToNativeReader: (pageUrl: String, pageTitle: String, imageUrls: List<String>) -> Unit
) {
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var currentUrl by rememberSaveable(url) { mutableStateOf(url) }
    var currentTitle by rememberSaveable(title) { mutableStateOf(title) }
    var isPageLoading by remember { mutableStateOf(true) }
    var cleanReaderCssActive by rememberSaveable { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = {
                Column {
                    Text(
                        text = currentTitle.ifBlank { "Browser Reader" },
                        color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = currentUrl,
                        color = WebReaderPalette.AccentSky,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            },
            navigationIcon = {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close browser", tint = MaterialTheme.colorScheme.onSurface)
                }
            },
            actions = {
                FilledTonalButton(
                    onClick = {
                        val wv = webViewRef ?: return@FilledTonalButton
                        wv.evaluateJavascript(
                            """
                            (function() {
                                var imgs = Array.from(document.querySelectorAll('img'));
                                var urls = imgs.map(function(i) {
                                    return i.getAttribute('data-src') || i.getAttribute('data-lazy-src') || i.getAttribute('data-original') || i.src || '';
                                }).filter(function(u) {
                                    return u.startsWith('http') && !u.includes('logo') && !u.includes('avatar');
                                });
                                return JSON.stringify(urls);
                            })();
                            """.trimIndent()
                        ) { jsonResult ->
                            runCatching {
                                val rawJson = if (jsonResult.startsWith("\"") && jsonResult.endsWith("\"")) {
                                    jsonResult.substring(1, jsonResult.length - 1).replace("\\\"", "\"")
                                } else jsonResult
                                val arr = JSONArray(rawJson)
                                val list = mutableListOf<String>()
                                for (i in 0 until arr.length()) {
                                    val u = arr.optString(i)
                                    if (u.startsWith("http")) list.add(u)
                                }
                                onExtractPagesToNativeReader(currentUrl, currentTitle, list.distinct())
                            }
                        }
                    },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Native Reader", style = MaterialTheme.typography.labelSmall)
                }
                IconButton(
                    onClick = { webViewRef?.reload() },
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Reload webpage", tint = MaterialTheme.colorScheme.onSurface)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )

        if (isPageLoading) {
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth(),
                color = WebReaderPalette.AccentSky
            )
        }

        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.loadsImagesAutomatically = true
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    settings.builtInZoomControls = true
                    settings.displayZoomControls = false
                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    settings.userAgentString =
                        "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

                    webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(
                            view: WebView?,
                            request: WebResourceRequest?
                        ): WebResourceResponse? {
                            val reqUrl = request?.url?.toString() ?: return null
                            if (adBlockEnabled && SourceCatalogEngine.isAdUrl(reqUrl)) {
                                return WebResourceResponse(
                                    "text/plain",
                                    "UTF-8",
                                    ByteArrayInputStream(ByteArray(0))
                                )
                            }
                            return super.shouldInterceptRequest(view, request)
                        }

                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            super.onPageStarted(view, url, favicon)
                            isPageLoading = true
                            if (!url.isNullOrBlank()) currentUrl = url
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                            isPageLoading = false
                            if (!url.isNullOrBlank()) currentUrl = url
                            if (!view?.title.isNullOrBlank()) currentTitle = view?.title ?: currentTitle

                            if (cleanReaderCssActive && adBlockEnabled) {
                                view?.evaluateJavascript(
                                    """
                                    (function() {
                                        var style = document.createElement('style');
                                        style.innerHTML = 'iframe, .ads, .ad-banner, [id*="google_ads"], .popunder, .floating-banner { display: none !important; } body { background-color: #0A0E17 !important; } img { max-width: 100% !important; height: auto !important; display: block !important; margin: 0 auto !important; }';
                                        document.head.appendChild(style);
                                    })();
                                    """.trimIndent(),
                                    null
                                )
                            }
                        }
                    }
                    loadUrl(url)
                    webViewRef = this
                }
            },
            modifier = Modifier.weight(1f)
        )
    }
}
