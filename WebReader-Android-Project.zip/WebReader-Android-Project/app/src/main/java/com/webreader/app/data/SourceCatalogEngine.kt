package com.webreader.app.data

import android.webkit.CookieManager
import com.webreader.app.model.ChapterItem
import com.webreader.app.model.MangaSeries
import com.webreader.app.model.MangaSourceSite
import com.webreader.app.model.ReaderMode
import com.webreader.app.model.SourceParserType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.net.URLEncoder

/**
 * Live Multi-Site Scraper Engine for WebReader v2.0.
 * Implements real HTTP + HTML + JSON parsers for:
 * - MangaDex Official REST API v5 (api.mangadex.org/manga, /feed, /at-home/server)
 * - Madara WordPress Engine (MangaEffect, ManhwaTop, ManhuaTop)
 * - MangaTown (www.mangatown.com)
 * - Bato.to (bato.to / batotwo.com / batocomic.org)
 * - Asura Scans (asuracomic.net)
 * - Any Custom Manga Website URL
 */
object SourceCatalogEngine {

    private const val MOBILE_UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

    val defaultBuiltInSources: List<MangaSourceSite> = listOf(
        MangaSourceSite(
            id = "mangadex",
            tachiyomiSourceId = 2499283573021220255L,
            name = "MangaDex",
            baseUrl = "https://mangadex.org",
            mirrors = listOf("https://mangadex.org"),
            language = "EN",
            parserType = SourceParserType.MANGADEX_API,
            defaultReaderMode = ReaderMode.LEFT_TO_RIGHT,
            isPinnedFavorite = true,
            isBuiltIn = true,
            accentColorHex = 0xFFF97316
        ),
        MangaSourceSite(
            id = "mangaeffect",
            tachiyomiSourceId = 41001L,
            name = "MangaEffect",
            baseUrl = "https://mangaeffect.com",
            mirrors = listOf("https://mangaeffect.com", "https://mangaeffect.org", "https://mangaeffect.net"),
            language = "EN",
            parserType = SourceParserType.MADARA,
            defaultReaderMode = ReaderMode.WEBTOON,
            isPinnedFavorite = true,
            isBuiltIn = true,
            accentColorHex = 0xFFEF4444
        ),
        MangaSourceSite(
            id = "manhwatop",
            tachiyomiSourceId = 41002L,
            name = "ManhwaTop",
            baseUrl = "https://manhwatop.com",
            mirrors = listOf("https://manhwatop.com", "https://manhwatop.org"),
            language = "EN",
            parserType = SourceParserType.MADARA,
            defaultReaderMode = ReaderMode.WEBTOON,
            isPinnedFavorite = true,
            isBuiltIn = true,
            accentColorHex = 0xFF8B5CF6
        ),
        MangaSourceSite(
            id = "manhuatop",
            tachiyomiSourceId = 41003L,
            name = "ManhuaTop",
            baseUrl = "https://manhuatop.org",
            mirrors = listOf("https://manhuatop.org", "https://manhuatop.com"),
            language = "EN",
            parserType = SourceParserType.MADARA,
            defaultReaderMode = ReaderMode.WEBTOON,
            isPinnedFavorite = true,
            isBuiltIn = true,
            accentColorHex = 0xFFF59E0B
        ),
        MangaSourceSite(
            id = "mangatown",
            tachiyomiSourceId = 41004L,
            name = "MangaTown",
            baseUrl = "https://www.mangatown.com",
            mirrors = listOf("https://www.mangatown.com"),
            language = "EN",
            parserType = SourceParserType.MANGATOWN,
            defaultReaderMode = ReaderMode.RIGHT_TO_LEFT,
            isPinnedFavorite = true,
            isBuiltIn = true,
            accentColorHex = 0xFF10B981
        ),
        MangaSourceSite(
            id = "asurascans",
            tachiyomiSourceId = 41005L,
            name = "Asura Scans",
            baseUrl = "https://asuracomic.net",
            mirrors = listOf("https://asuracomic.net", "https://asurascans.us"),
            language = "EN",
            parserType = SourceParserType.ASURA,
            defaultReaderMode = ReaderMode.WEBTOON,
            isPinnedFavorite = true,
            isBuiltIn = true,
            accentColorHex = 0xFF6366F1
        ),
        MangaSourceSite(
            id = "batoto",
            tachiyomiSourceId = 41006L,
            name = "Bato.to",
            baseUrl = "https://bato.to",
            mirrors = listOf("https://bato.to", "https://batotwo.com", "https://batocomic.org", "https://batotoo.com"),
            language = "EN",
            parserType = SourceParserType.BATOTO,
            defaultReaderMode = ReaderMode.WEBTOON,
            isPinnedFavorite = true,
            isBuiltIn = true,
            accentColorHex = 0xFF06B6D4
        )
    )

    private val blockedAdKeywords = listOf(
        "doubleclick.net", "googlesyndication.com", "popads.net", "exoclick.com",
        "propellerads.com", "adsterra.com", "juicyads.com", "onclickads.net",
        "trafficjunky.net", "bidgear.com", "outbrain.com", "taboola.com"
    )

    fun isAdUrl(url: String): Boolean {
        val lower = url.lowercase()
        return blockedAdKeywords.any { lower.contains(it) }
    }

    fun normalizeWebsiteUrl(rawInput: String): String {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return ""
        return when {
            trimmed.startsWith("https://", ignoreCase = true) -> trimmed.trimEnd('/')
            trimmed.startsWith("http://", ignoreCase = true) -> "https://" + trimmed.substring(7).trimEnd('/')
            else -> "https://${trimmed.trimEnd('/')}"
        }
    }

    fun extractDomainLabel(url: String): String {
        return try {
            val host = URI(normalizeWebsiteUrl(url)).host ?: url
            host.removePrefix("www.")
                .split(".")
                .firstOrNull()
                ?.replaceFirstChar { it.uppercase() }
                ?: "CustomSite"
        } catch (_: Exception) {
            "CustomSite"
        }
    }

    /**
     * Real Verified Starter Library (backed by live URLs on MangaDex, ManhwaTop, ManhuaTop,
     * MangaEffect, MangaTown, Asura Scans, and Bato.to).
     * On app startup and when opened, WebReader fetches live covers, chapters, and pages from the source!
     */
    fun starterCatalogSeries(): List<MangaSeries> = listOf(
        MangaSeries(
            id = "md_32d76d19-8a05-4db0-9fc2-e0b0648fe9d0",
            sourceId = "mangadex",
            sourceName = "MangaDex",
            title = "Solo Leveling",
            author = "Chugong / DUBU (Redice Studio)",
            artist = "DUBU",
            description = "In a world where hunters—humans who possess magical abilities—must battle deadly monsters to protect the human race from certain annihilation, a notoriously weak hunter named Sung Jinwoo finds himself in a seemingly endless struggle for survival.",
            status = "Completed",
            genres = listOf("Manhwa", "Action", "Fantasy", "Webtoon"),
            mangaUrl = "https://mangadex.org/title/32d76d19-8a05-4db0-9fc2-e0b0648fe9d0/solo-leveling",
            coverUrl = "https://uploads.mangadex.org/covers/32d76d19-8a05-4db0-9fc2-e0b0648fe9d0/e90bdc47-c8b9-4df7-b2c0-17641b645ee1.jpg.256.jpg",
            coverColorHex = 0xFFF97316,
            isFavorite = false,
            categoryName = "Manhwa & Webtoons",
            preferredReaderMode = ReaderMode.WEBTOON
        ),
        MangaSeries(
            id = "md_a1c7c817-4e59-43b7-9365-09675a149a6f",
            sourceId = "mangadex",
            sourceName = "MangaDex",
            title = "One Piece",
            author = "Oda Eiichiro",
            artist = "Oda Eiichiro",
            description = "Gol D. Roger, a man referred to as the King of the Pirates, is set to be executed by the World Government. But just before his demise, he confirms the existence of a great treasure, One Piece, located somewhere within the vast ocean known as the Grand Line.",
            status = "Ongoing",
            genres = listOf("Manga", "Action", "Adventure", "Shounen"),
            mangaUrl = "https://mangadex.org/title/a1c7c817-4e59-43b7-9365-09675a149a6f/one-piece",
            coverUrl = "https://uploads.mangadex.org/covers/a1c7c817-4e59-43b7-9365-09675a149a6f/263983f7-f781-4427-b69d-66c19f9110a0.jpg.256.jpg",
            coverColorHex = 0xFFEF4444,
            isFavorite = false,
            categoryName = "Manga",
            preferredReaderMode = ReaderMode.RIGHT_TO_LEFT
        ),
        MangaSeries(
            id = "md_801513ba-a712-498c-8f57-cae55b38cc92",
            sourceId = "mangadex",
            sourceName = "MangaDex",
            title = "Berserk",
            author = "Miura Kentaro",
            artist = "Miura Kentaro",
            description = "Guts, a former mercenary now known as the Black Swordsman, is out for revenge. After a tumultuous childhood, he finally finds someone he respects and believes he can trust, only to have everything fall apart when this person takes away everything important to Guts.",
            status = "Ongoing",
            genres = listOf("Manga", "Dark Fantasy", "Seinen", "Action"),
            mangaUrl = "https://mangadex.org/title/801513ba-a712-498c-8f57-cae55b38cc92/berserk",
            coverUrl = "https://uploads.mangadex.org/covers/801513ba-a712-498c-8f57-cae55b38cc92/02f9d608-002e-4f16-862f-4c0b097e5921.jpg.256.jpg",
            coverColorHex = 0xFF10B981,
            isFavorite = false,
            categoryName = "Manga",
            preferredReaderMode = ReaderMode.RIGHT_TO_LEFT
        ),
        MangaSeries(
            id = "mwt_villainess_turns_hourglass",
            sourceId = "manhwatop",
            sourceName = "ManhwaTop",
            title = "The Villainess Turns the Hourglass",
            author = "Sansobee / Ant Studio",
            artist = "Ant Studio",
            description = "Sent back into the past by a mysterious hourglass right before her execution, Aria decides to outsmart her stepsister Mielle by becoming an even sharper villainess. Tap to load live chapters from ManhwaTop.",
            status = "Completed",
            genres = listOf("Manhwa", "Romance", "Fantasy"),
            mangaUrl = "https://manhwatop.com/manhwa/the-villainess-turns-the-hourglass/",
            coverUrl = "https://manhwatop.com/wp-content/uploads/2020/07/The-Villainess-Turns-the-Hourglass-193x278.jpg",
            coverColorHex = 0xFF8B5CF6,
            isFavorite = false,
            categoryName = "Manhwa & Webtoons",
            preferredReaderMode = ReaderMode.WEBTOON
        ),
        MangaSeries(
            id = "mht_martial_peak",
            sourceId = "manhuatop",
            sourceName = "ManhuaTop",
            title = "Martial Peak",
            author = "Momo / Pikapi",
            artist = "Pikapi",
            description = "The journey to the martial peak is a lonely, solitary and long one. In the face of adversity, Yang Kai must survive and remain unyielding to pierce through the heavens. Tap to load live chapters from ManhuaTop.",
            status = "Ongoing",
            genres = listOf("Manhua", "Cultivation", "Martial Arts"),
            mangaUrl = "https://manhuatop.org/manhua/martial-peak/",
            coverUrl = "https://manhuatop.org/wp-content/uploads/2020/04/Martial-Peak-193x278.jpg",
            coverColorHex = 0xFFF59E0B,
            isFavorite = false,
            categoryName = "Manhua",
            preferredReaderMode = ReaderMode.WEBTOON
        ),
        MangaSeries(
            id = "me_lightning_degree",
            sourceId = "mangaeffect",
            sourceName = "MangaEffect",
            title = "Lightning Degree",
            author = "Aolhoti",
            artist = "Aolhoti",
            description = "Ryu-Yeon loses his parents at a young age and is taken in by an eccentric martial arts master on Mount Hwa, learning the legendary Lightning Knives technique.",
            status = "Ongoing",
            genres = listOf("Martial Arts", "Murim", "Comedy"),
            mangaUrl = "https://mangaeffect.com/manga/lightning-degree/",
            coverUrl = "",
            coverColorHex = 0xFFEF4444,
            isFavorite = false,
            categoryName = "Manhwa & Webtoons",
            preferredReaderMode = ReaderMode.WEBTOON
        ),
        MangaSeries(
            id = "mt_kingdom",
            sourceId = "mangatown",
            sourceName = "MangaTown",
            title = "Kingdom",
            author = "Hara Yasuhisa",
            artist = "Hara Yasuhisa",
            description = "During the Warring States period in ancient China, war orphans Shin and Hyou dream of proving themselves on the battlefield and unifying the seven kingdoms.",
            status = "Ongoing",
            genres = listOf("Historical", "Seinen", "Action"),
            mangaUrl = "https://www.mangatown.com/manga/kingdom/",
            coverUrl = "",
            coverColorHex = 0xFF10B981,
            isFavorite = false,
            categoryName = "Manga",
            preferredReaderMode = ReaderMode.RIGHT_TO_LEFT
        ),
        MangaSeries(
            id = "bato_omniscient_reader",
            sourceId = "batoto",
            sourceName = "Bato.to",
            title = "Omniscient Reader's Viewpoint",
            author = "Sing N Song / Sleepy-C",
            artist = "Sleepy-C",
            description = "Kim Dokja is the sole reader of a web novel titled 'Three Ways to Survive in a Ruined World'. When the world suddenly turns into the novel's premise, only he knows how it ends.",
            status = "Ongoing",
            genres = listOf("Manhwa", "Action", "Fantasy"),
            mangaUrl = "https://bato.to/title/81517-omniscient-reader-s-viewpoint",
            coverUrl = "",
            coverColorHex = 0xFF06B6D4,
            isFavorite = false,
            categoryName = "Manhwa & Webtoons",
            preferredReaderMode = ReaderMode.WEBTOON
        )
    )

    /**
     * Fetches the live catalog (Popular or Search query) from a selected source website!
     */
    suspend fun fetchSourceCatalog(
        site: MangaSourceSite,
        searchQuery: String = ""
    ): Result<List<MangaSeries>> = withContext(Dispatchers.IO) {
        try {
            when (site.parserType) {
                SourceParserType.MANGADEX_API -> fetchMangaDexCatalog(site, searchQuery)
                SourceParserType.MADARA -> fetchMadaraCatalog(site, searchQuery)
                SourceParserType.MANGATOWN -> fetchMangaTownCatalog(site, searchQuery)
                SourceParserType.BATOTO -> fetchBatoCatalog(site, searchQuery)
                SourceParserType.ASURA -> fetchGenericSiteCatalog(site, searchQuery, "${site.baseUrl}/series")
                SourceParserType.CUSTOM_SMART -> fetchGenericSiteCatalog(site, searchQuery, site.baseUrl)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Fetches the real chapter list (and cover/description if missing) for a MangaSeries from its website!
     */
    suspend fun fetchChaptersForSeries(
        series: MangaSeries,
        site: MangaSourceSite?
    ): Result<MangaSeries> = withContext(Dispatchers.IO) {
        try {
            // 1. Check if MangaDex UUID
            if (series.sourceId == "mangadex" || series.mangaUrl.contains("mangadex.org")) {
                val mdUuid = extractMangaDexUuid(series.id, series.mangaUrl)
                if (mdUuid != null) {
                    return@withContext fetchMangaDexSeriesAndChapters(series, mdUuid)
                }
            }

            // 2. Fetch HTML from mangaUrl
            val html = httpGet(series.mangaUrl, site?.baseUrl ?: series.mangaUrl)
            if (html.isBlank()) {
                return@withContext Result.failure(IllegalStateException("Website required browser verification. Tap 'Open in Clean WebView' to read directly."))
            }

            // Extract cover image if missing
            val ogImage = Regex("""property=["']og:image["']\s+content=["'](https?://[^"']+)["']""", RegexOption.IGNORE_CASE)
                .find(html)?.groupValues?.getOrNull(1)
                ?: Regex("""content=["'](https?://[^"']+)["']\s+property=["']og:image["']""", RegexOption.IGNORE_CASE)
                    .find(html)?.groupValues?.getOrNull(1)
                ?: Regex("""class=["'][^"']*summary_image[^"']*["'][\s\S]{0,400}?(?:data-src|data-lazy-src|src)=["'](https?://[^"']+)["']""", RegexOption.IGNORE_CASE)
                    .find(html)?.groupValues?.getOrNull(1)
                ?: series.coverUrl

            // Try Madara AJAX chapters endpoint first if Madara site
            var chaptersHtml = html
            if (site?.parserType == SourceParserType.MADARA || html.contains("wp-manga")) {
                val ajaxUrl = series.mangaUrl.trimEnd('/') + "/ajax/chapters/"
                val ajaxResp = runCatching { httpPost(ajaxUrl, series.mangaUrl) }.getOrDefault("")
                if (ajaxResp.contains("wp-manga-chapter") || ajaxResp.contains("<a")) {
                    chaptersHtml = ajaxResp + "\n" + html
                }
            }

            val parsedChapters = extractChaptersFromHtml(chaptersHtml, series.id, series.mangaUrl, series.sourceName)
            if (parsedChapters.isEmpty()) {
                return@withContext Result.failure(IllegalStateException("Could not parse chapter links directly. Tap 'Open in Clean WebView' to browse chapters."))
            }

            // Merge read/download flags from existing chapters
            val existingByUrl = series.chapters.associateBy { it.url }
            val mergedChapters = parsedChapters.map { ch ->
                val old = existingByUrl[ch.url]
                if (old != null) {
                    ch.copy(
                        isRead = old.isRead,
                        isBookmarked = old.isBookmarked,
                        isDownloaded = old.isDownloaded,
                        lastPageRead = old.lastPageRead,
                        pageUrls = old.pageUrls.ifEmpty { ch.pageUrls }
                    )
                } else {
                    ch
                }
            }

            Result.success(
                series.copy(
                    coverUrl = ogImage.trim(),
                    chapters = mergedChapters
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Fetches the real comic page image URLs for a chapter!
     */
    suspend fun fetchPageUrlsForChapter(
        series: MangaSeries,
        chapter: ChapterItem
    ): Result<List<String>> = withContext(Dispatchers.IO) {
        try {
            if (chapter.pageUrls.isNotEmpty() && chapter.pageUrls.first().startsWith("http")) {
                return@withContext Result.success(chapter.pageUrls)
            }

            // 1. Check if MangaDex chapter UUID
            if (series.sourceId == "mangadex" || chapter.url.contains("mangadex.org/chapter/")) {
                val chUuid = chapter.url.substringAfter("chapter/").substringBefore("/").ifBlank { chapter.id.removePrefix("md_ch_") }
                val atHomeUrl = "https://api.mangadex.org/at-home/server/$chUuid"
                val jsonText = httpGet(atHomeUrl, "https://mangadex.org/")
                if (jsonText.isNotBlank()) {
                    val root = JSONObject(jsonText)
                    val baseUrl = root.optString("baseUrl", "https://uploads.mangadex.org")
                    val chObj = root.optJSONObject("chapter")
                    val hash = chObj?.optString("hash").orEmpty()
                    val dataSaver = chObj?.optJSONArray("dataSaver")
                    val dataFull = chObj?.optJSONArray("data")
                    val pages = mutableListOf<String>()
                    if (dataSaver != null && dataSaver.length() > 0) {
                        for (i in 0 until dataSaver.length()) {
                            pages.add("$baseUrl/data-saver/$hash/${dataSaver.getString(i)}")
                        }
                    } else if (dataFull != null && dataFull.length() > 0) {
                        for (i in 0 until dataFull.length()) {
                            pages.add("$baseUrl/data/$hash/${dataFull.getString(i)}")
                        }
                    }
                    if (pages.isNotEmpty()) {
                        return@withContext Result.success(pages)
                    }
                }
            }

            // 2. Fetch HTML from chapter.url (Madara, Bato.to, MangaTown, Asura, Custom)
            val html = httpGet(chapter.url, series.mangaUrl)
            if (html.isBlank()) {
                return@withContext Result.failure(IllegalStateException("Chapter page protected by Cloudflare. Switching to Clean Reader WebView."))
            }

            val extracted = extractComicImagesFromHtml(html, chapter.url)
            if (extracted.isNotEmpty()) {
                Result.success(extracted)
            } else {
                Result.failure(IllegalStateException("No direct static images found; use Clean Reader WebView mode."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun fetchMangaDexCatalog(site: MangaSourceSite, query: String): Result<List<MangaSeries>> {
        val apiUrl = if (query.isBlank()) {
            "https://api.mangadex.org/manga?limit=24&includes[]=cover_art&includes[]=author&order[followedCount]=desc&contentRating[]=safe&contentRating[]=suggestive"
        } else {
            "https://api.mangadex.org/manga?limit=24&title=${URLEncoder.encode(query, "UTF-8")}&includes[]=cover_art&includes[]=author&order[relevance]=desc"
        }

        val jsonText = httpGet(apiUrl, "https://mangadex.org/")
        if (jsonText.isBlank()) {
            return Result.failure(IllegalStateException("Could not reach api.mangadex.org"))
        }

        val root = JSONObject(jsonText)
        val dataArr = root.optJSONArray("data") ?: return Result.success(emptyList())
        val results = mutableListOf<MangaSeries>()

        for (i in 0 until dataArr.length()) {
            val item = dataArr.optJSONObject(i) ?: continue
            val uuid = item.optString("id")
            val attrs = item.optJSONObject("attributes") ?: continue
            val titleObj = attrs.optJSONObject("title")
            val title = titleObj?.optString("en")
                ?.ifBlank {
                    titleObj.keys().asSequence().firstOrNull()?.let { k -> titleObj.optString(k) } ?: "MangaDex Title"
                } ?: "MangaDex Title"

            val descObj = attrs.optJSONObject("description")
            val description = descObj?.optString("en")?.take(500) ?: "Live series from MangaDex."
            val status = attrs.optString("status", "ongoing").replaceFirstChar { it.uppercase() }

            var coverFileName = ""
            var authorName = "MangaDex Creator"
            val rels = item.optJSONArray("relationships")
            if (rels != null) {
                for (r in 0 until rels.length()) {
                    val rel = rels.optJSONObject(r) ?: continue
                    val type = rel.optString("type")
                    val relAttrs = rel.optJSONObject("attributes")
                    if (type == "cover_art" && relAttrs != null) {
                        coverFileName = relAttrs.optString("fileName")
                    } else if (type == "author" && relAttrs != null) {
                        authorName = relAttrs.optString("name", authorName)
                    }
                }
            }

            val coverUrl = if (coverFileName.isNotBlank()) {
                "https://uploads.mangadex.org/covers/$uuid/$coverFileName.256.jpg"
            } else {
                ""
            }

            val tagsArr = attrs.optJSONArray("tags")
            val genres = mutableListOf<String>()
            if (tagsArr != null) {
                for (t in 0 until tagsArr.length().coerceAtMost(4)) {
                    val tagName = tagsArr.optJSONObject(t)
                        ?.optJSONObject("attributes")
                        ?.optJSONObject("name")
                        ?.optString("en")
                    if (!tagName.isNullOrBlank()) genres.add(tagName)
                }
            }

            results.add(
                MangaSeries(
                    id = "md_$uuid",
                    sourceId = site.id,
                    sourceName = site.name,
                    title = title,
                    author = authorName,
                    description = description,
                    status = status,
                    genres = genres.ifEmpty { listOf("Manga") },
                    mangaUrl = "https://mangadex.org/title/$uuid",
                    coverUrl = coverUrl,
                    coverColorHex = site.accentColorHex,
                    isFavorite = false,
                    categoryName = "Manga",
                    preferredReaderMode = ReaderMode.AUTO
                )
            )
        }
        return Result.success(results)
    }

    private fun fetchMangaDexSeriesAndChapters(series: MangaSeries, mdUuid: String): Result<MangaSeries> {
        val feedUrl = "https://api.mangadex.org/manga/$mdUuid/feed?translatedLanguage[]=en&order[chapter]=desc&limit=96&includes[]=scanlation_group"
        val jsonText = httpGet(feedUrl, "https://mangadex.org/")
        if (jsonText.isBlank()) {
            return Result.failure(IllegalStateException("Could not load MangaDex chapter feed."))
        }

        val root = JSONObject(jsonText)
        val dataArr = root.optJSONArray("data") ?: return Result.success(series)
        val chapters = mutableListOf<ChapterItem>()
        val seenChapterNumbers = mutableSetOf<String>()

        for (i in 0 until dataArr.length()) {
            val item = dataArr.optJSONObject(i) ?: continue
            val chUuid = item.optString("id")
            val attrs = item.optJSONObject("attributes") ?: continue
            val pagesCount = attrs.optInt("pages", 0)
            val externalUrl = attrs.optString("externalUrl", "")
            if (pagesCount <= 0 && externalUrl.isNotBlank()) continue

            val chNumStr = attrs.optString("chapter", "${dataArr.length() - i}")
            if (!seenChapterNumbers.add(chNumStr)) continue

            val chTitleRaw = attrs.optString("title", "")
            val displayTitle = if (chTitleRaw.isNotBlank() && chTitleRaw != "null") {
                "Ch. $chNumStr - $chTitleRaw"
            } else {
                "Chapter $chNumStr"
            }
            val publishAt = attrs.optString("publishAt", "").take(10)

            var groupName = "MangaDex"
            val rels = item.optJSONArray("relationships")
            if (rels != null) {
                for (r in 0 until rels.length()) {
                    val rel = rels.optJSONObject(r) ?: continue
                    if (rel.optString("type") == "scanlation_group") {
                        groupName = rel.optJSONObject("attributes")?.optString("name", groupName) ?: groupName
                    }
                }
            }

            val existing = series.chapters.find { it.id == "md_ch_$chUuid" }
            chapters.add(
                ChapterItem(
                    id = "md_ch_$chUuid",
                    mangaId = series.id,
                    title = displayTitle,
                    number = chNumStr.toFloatOrNull() ?: (dataArr.length() - i).toFloat(),
                    url = "https://mangadex.org/chapter/$chUuid",
                    uploadDateText = publishAt.ifBlank { "Available" },
                    scanlator = groupName,
                    isRead = existing?.isRead ?: false,
                    isBookmarked = existing?.isBookmarked ?: false,
                    isDownloaded = existing?.isDownloaded ?: false,
                    lastPageRead = existing?.lastPageRead ?: 0,
                    pageUrls = existing?.pageUrls ?: emptyList()
                )
            )
        }

        return Result.success(series.copy(chapters = chapters))
    }

    private fun extractMangaDexUuid(seriesId: String, mangaUrl: String): String? {
        if (seriesId.startsWith("md_")) {
            return seriesId.removePrefix("md_")
        }
        val m = Regex("""([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})""", RegexOption.IGNORE_CASE)
            .find(mangaUrl)
        return m?.groupValues?.getOrNull(1)
    }

    /**
     * Live Madara Scraper for MangaEffect, ManhwaTop, and ManhuaTop
     */
    private fun fetchMadaraCatalog(site: MangaSourceSite, query: String): Result<List<MangaSeries>> {
        val candidateUrls = if (query.isNotBlank()) {
            site.mirrors.map { "${it.trimEnd('/')}/?s=${URLEncoder.encode(query, "UTF-8")}&post_type=wp-manga" }
        } else {
            site.mirrors.flatMap { base ->
                val b = base.trimEnd('/')
                listOf("$b/?s=&post_type=wp-manga&m_orderby=views", "$b/manga/?m_orderby=views", "$b/manhwa/?m_orderby=views", b)
            }
        }

        for (targetUrl in candidateUrls) {
            val html = runCatching { httpGet(targetUrl, site.baseUrl) }.getOrDefault("")
            if (html.isNotBlank()) {
                val parsed = parseHtmlSeriesCards(html, site)
                if (parsed.isNotEmpty()) {
                    return Result.success(parsed)
                }
            }
        }
        return Result.failure(IllegalStateException("${site.name} requires Cloudflare verification; tap 'Open Website in Browser' to unlock cookies."))
    }

    private fun fetchMangaTownCatalog(site: MangaSourceSite, query: String): Result<List<MangaSeries>> {
        val url = if (query.isNotBlank()) {
            "${site.baseUrl}/search?name=${URLEncoder.encode(query, "UTF-8")}"
        } else {
            "${site.baseUrl}/directory/"
        }
        val html = httpGet(url, site.baseUrl)
        val parsed = parseHtmlSeriesCards(html, site)
        return if (parsed.isNotEmpty()) {
            Result.success(parsed)
        } else {
            Result.failure(IllegalStateException("Could not parse MangaTown directory; tap 'Open Website in Browser'."))
        }
    }

    private fun fetchBatoCatalog(site: MangaSourceSite, query: String): Result<List<MangaSeries>> {
        for (mirror in site.mirrors) {
            val url = if (query.isNotBlank()) {
                "${mirror.trimEnd('/')}/search?word=${URLEncoder.encode(query, "UTF-8")}"
            } else {
                "${mirror.trimEnd('/')}/browse?sort=views_d.za"
            }
            val html = runCatching { httpGet(url, mirror) }.getOrDefault("")
            if (html.isNotBlank()) {
                val parsed = parseHtmlSeriesCards(html, site.copy(baseUrl = mirror))
                if (parsed.isNotEmpty()) {
                    return Result.success(parsed)
                }
            }
        }
        return Result.failure(IllegalStateException("Could not reach Bato.to mirrors; tap 'Switch Mirror' or 'Open Website in Browser'."))
    }

    private fun fetchGenericSiteCatalog(site: MangaSourceSite, query: String, fallbackUrl: String): Result<List<MangaSeries>> {
        val url = if (query.isNotBlank()) {
            "${site.baseUrl.trimEnd('/')}/?s=${URLEncoder.encode(query, "UTF-8")}"
        } else {
            fallbackUrl
        }
        val html = httpGet(url, site.baseUrl)
        val parsed = parseHtmlSeriesCards(html, site)
        return if (parsed.isNotEmpty()) {
            Result.success(parsed)
        } else {
            Result.failure(IllegalStateException("Tap 'Open Website in Browser' to browse ${site.name} interactively."))
        }
    }

    /**
     * Universal HTML Series Card Extractor for Madara (MangaEffect, ManhwaTop, ManhuaTop),
     * MangaTown, Bato.to, Asura Scans, and custom manga websites.
     */
    fun parseHtmlSeriesCards(html: String, site: MangaSourceSite): List<MangaSeries> {
        val results = mutableListOf<MangaSeries>()
        val seenUrls = mutableSetOf<String>()

        // Split by common item containers or scan anchor+image pairs
        val blocks = html.split(Regex("""(?=<div[^>]+class=["'][^"']*(?:page-item-detail|c-tabs-item__content|item-thumb|manga_pic_list|item-cover|bsx|utao))""", RegexOption.IGNORE_CASE))
        val targetBlocks = if (blocks.size > 2) blocks.drop(1) else listOf(html)

        val linkRegex = Regex(
            """<a[^>]+href=["'](https?://[^"']+/(?:manga|manhwa|manhua|series|title|webtoon|comic)/[^"']+|/(?:manga|manhwa|manhua|series|title|webtoon|comic)/[^"']+)["'][^>]*>(?:[\s\S]{0,600}?)</a>""",
            RegexOption.IGNORE_CASE
        )
        val imgRegex = Regex(
            """(?:data-src|data-lazy-src|data-original|src)\s*=\s*["']\s*(https?://[^"'\s]+\.(?:jpg|jpeg|png|webp)(?:\?[^"'\s]*)?|/[^"'\s]+\.(?:jpg|jpeg|png|webp)(?:\?[^"'\s]*)?)\s*["']""",
            RegexOption.IGNORE_CASE
        )
        val titleAttrRegex = Regex("""(?:title|alt)\s*=\s*["']([^"']{3,120})["']""", RegexOption.IGNORE_CASE)

        for (block in targetBlocks) {
            val linkMatch = linkRegex.find(block) ?: continue
            val rawHref = linkMatch.groupValues[1].trim()
            if (rawHref.contains("/chapter", ignoreCase = true) || rawHref.contains("#")) continue
            val fullMangaUrl = resolveRelativeUrl(site.baseUrl, rawHref)
            if (!seenUrls.add(fullMangaUrl)) continue

            val rawImg = imgRegex.find(block)?.groupValues?.getOrNull(1)?.trim().orEmpty()
            val fullCoverUrl = if (rawImg.isNotBlank()) resolveRelativeUrl(site.baseUrl, rawImg) else ""

            val rawTitle = titleAttrRegex.find(block)?.groupValues?.getOrNull(1)
                ?: fullMangaUrl.trimEnd('/').substringAfterLast('/').replace("-", " ").replace("_", " ")
            val cleanTitle = decodeHtmlEntities(rawTitle)
                .replace(Regex("(?i)^read\\s+"), "")
                .trim()
                .ifBlank { "${site.name} Series" }

            val slugId = "${site.id}_${fullMangaUrl.hashCode().toUInt()}"
            results.add(
                MangaSeries(
                    id = slugId,
                    sourceId = site.id,
                    sourceName = site.name,
                    title = cleanTitle.replaceFirstChar { it.uppercase() },
                    author = site.name,
                    description = "Loaded live from ${site.name} ($fullMangaUrl). Tap to fetch all chapters.",
                    status = "Ongoing",
                    genres = listOf(site.name, site.defaultReaderMode.label),
                    mangaUrl = fullMangaUrl,
                    coverUrl = fullCoverUrl,
                    coverColorHex = site.accentColorHex,
                    isFavorite = false,
                    categoryName = if (site.defaultReaderMode == ReaderMode.WEBTOON) "Manhwa & Webtoons" else "Manga",
                    preferredReaderMode = site.defaultReaderMode
                )
            )
            if (results.size >= 30) break
        }
        return results
    }

    /**
     * Extracts real chapter links from a manga details page HTML (Madara, MangaTown, Bato.to, Asura, etc.)
     */
    fun extractChaptersFromHtml(
        html: String,
        mangaId: String,
        mangaUrl: String,
        sourceName: String
    ): List<ChapterItem> {
        val baseHost = try {
            val u = URI(mangaUrl)
            "${u.scheme}://${u.host}"
        } catch (_: Exception) {
            mangaUrl
        }

        val anchorRegex = Regex(
            """<a[^>]+href=["']([^"']*(?:chapter|ch-|ch_|/c\d+|/viewer/)[^"']*)["'][^>]*>([\s\S]{1,250}?)</a>""",
            RegexOption.IGNORE_CASE
        )

        val chapters = mutableListOf<ChapterItem>()
        val seenUrls = mutableSetOf<String>()

        for (match in anchorRegex.findAll(html)) {
            val rawHref = match.groupValues[1].trim()
            if (rawHref.startsWith("javascript:") || rawHref.startsWith("#")) continue
            val fullUrl = resolveRelativeUrl(baseHost, rawHref)
            if (!seenUrls.add(fullUrl)) continue

            val innerText = decodeHtmlEntities(
                match.groupValues[2].replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").trim()
            )
            val numMatch = Regex("""(?:chapter|ch\.?|ep\.?)\s*(\d+(?:\.\d+)?)""", RegexOption.IGNORE_CASE).find(innerText)
                ?: Regex("""(\d+(?:\.\d+)?)""").find(fullUrl.substringAfterLast('/'))
            val chNum = numMatch?.groupValues?.getOrNull(1)?.toFloatOrNull() ?: (chapters.size + 1).toFloat()
            val title = innerText.takeIf { it.length in 2..90 } ?: "Chapter ${chNum.toInt()}"

            chapters.add(
                ChapterItem(
                    id = "${mangaId}_ch_${fullUrl.hashCode().toUInt()}",
                    mangaId = mangaId,
                    title = title,
                    number = chNum,
                    url = fullUrl,
                    uploadDateText = "Live",
                    scanlator = sourceName
                )
            )
            if (chapters.size >= 250) break
        }
        return chapters
    }

    /**
     * Extracts comic/manga page image URLs from Madara (wp-manga-chapter-img, data-src, data-lazy-src),
     * Bato.to (imgHttps), MangaTown, and custom reader pages while filtering out site logos/ads.
     */
    fun extractComicImagesFromHtml(html: String, pageUrl: String): List<String> {
        val baseHost = try {
            val u = URI(pageUrl)
            "${u.scheme}://${u.host}"
        } catch (_: Exception) {
            pageUrl
        }

        val results = mutableSetOf<String>()

        // 1. Check Bato.to style JS array images: const imgHttps = ["https://..."]
        val batoScriptMatch = Regex("""imgHttps\s*=\s*\[([\s\S]*?)\]""", RegexOption.IGNORE_CASE).find(html)
        if (batoScriptMatch != null) {
            val urlMatches = Regex("""["'](https?://[^"']+)["']""").findAll(batoScriptMatch.groupValues[1])
            for (m in urlMatches) {
                val u = m.groupValues[1].replace("\\/", "/").trim()
                if (!isAdUrl(u)) results.add(u)
            }
        }

        // 2. Check Madara / standard reader images (data-src, data-lazy-src, data-original, src)
        val imgRegex = Regex(
            """(?:data-src|data-lazy-src|data-original|src)\s*=\s*["']\s*(https?://[^"'\s]+?\.(?:jpg|jpeg|png|webp)(?:\?[^"'\s]*)?)\s*["']""",
            RegexOption.IGNORE_CASE
        )
        for (match in imgRegex.findAll(html)) {
            val imgUrl = match.groupValues[1].trim()
            val lower = imgUrl.lowercase()
            if (
                !isAdUrl(imgUrl) &&
                !lower.contains("logo") &&
                !lower.contains("avatar") &&
                !lower.contains("favicon") &&
                !lower.contains("banner") &&
                !lower.contains("193x278") &&
                !lower.contains("175x238") &&
                !lower.contains("110x150")
            ) {
                results.add(resolveRelativeUrl(baseHost, imgUrl))
            }
        }
        return results.toList()
    }

    private fun resolveRelativeUrl(baseUrl: String, href: String): String {
        val cleanHref = href.trim()
        if (cleanHref.startsWith("http://") || cleanHref.startsWith("https://")) return cleanHref
        if (cleanHref.startsWith("//")) return "https:$cleanHref"
        val cleanBase = baseUrl.trimEnd('/')
        return "$cleanBase/${cleanHref.trimStart('/')}"
    }

    private fun decodeHtmlEntities(input: String): String {
        return input
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&#039;", "'")
            .replace("&#8217;", "'")
            .replace("&#8211;", "-")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
    }

    private fun httpGet(urlString: String, referer: String): String {
        val url = URL(urlString)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8000
            readTimeout = 10000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", MOBILE_UA)
            setRequestProperty("Accept", "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8")
            if (referer.isNotBlank()) {
                setRequestProperty("Referer", referer)
            }
            runCatching {
                val cookie = CookieManager.getInstance().getCookie(urlString)
                if (!cookie.isNullOrBlank()) {
                    setRequestProperty("Cookie", cookie)
                }
            }
        }
        return try {
            val code = conn.responseCode
            if (code !in 200..299) return ""
            val stream = conn.inputStream ?: return ""
            BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun httpPost(urlString: String, referer: String): String {
        val url = URL(urlString)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 7000
            readTimeout = 8000
            setRequestProperty("User-Agent", MOBILE_UA)
            setRequestProperty("X-Requested-With", "XMLHttpRequest")
            if (referer.isNotBlank()) {
                setRequestProperty("Referer", referer)
            }
            runCatching {
                val cookie = CookieManager.getInstance().getCookie(urlString)
                if (!cookie.isNullOrBlank()) {
                    setRequestProperty("Cookie", cookie)
                }
            }
        }
        return try {
            conn.outputStream.use { it.write(ByteArray(0)) }
            if (conn.responseCode !in 200..299) return ""
            val stream = conn.inputStream ?: return ""
            BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }
}
