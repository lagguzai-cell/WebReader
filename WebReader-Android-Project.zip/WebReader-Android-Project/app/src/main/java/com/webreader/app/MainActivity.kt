package com.webreader.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.SettingsBackupRestore
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.webreader.app.model.ChapterItem
import com.webreader.app.model.MangaSeries
import com.webreader.app.ui.WebReaderViewModel
import com.webreader.app.ui.screens.AddCustomWebsiteDialog
import com.webreader.app.ui.screens.BackupAndSettingsTabScreen
import com.webreader.app.ui.screens.BrowseSourcesTabScreen
import com.webreader.app.ui.screens.HistoryAndBookmarksTabScreen
import com.webreader.app.ui.screens.InAppWebViewReaderScreen
import com.webreader.app.ui.screens.LibraryTabScreen
import com.webreader.app.ui.screens.MangaDetailSheetScreen
import com.webreader.app.ui.screens.NativeComicReaderScreen
import com.webreader.app.ui.theme.WebReaderPalette
import com.webreader.app.ui.theme.WebReaderTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val initialSharedUrl = extractIncomingUrl(intent)

        setContent {
            val readerViewModel: WebReaderViewModel = viewModel()
            val uiState by readerViewModel.uiState.collectAsState()

            // Handle incoming VIEW / SEND intent (.tachibk backup or web URL)
            var handledIntent by rememberSaveable { mutableStateOf(false) }
            if (!handledIntent && initialSharedUrl != null) {
                handledIntent = true
                if (initialSharedUrl.startsWith("content://") || initialSharedUrl.startsWith("file://")) {
                    val uri = Uri.parse(initialSharedUrl)
                    val fileName = resolveDisplayFileName(uri)
                    readerViewModel.importBackupFromUri(uri, fileName)
                } else if (initialSharedUrl.startsWith("http://") || initialSharedUrl.startsWith("https://")) {
                    readerViewModel.openInAppWebView(initialSharedUrl, "Shared Link")
                }
            }

            // Android Storage Access Framework (SAF) file picker for importing .tachibk / .proto.gz / .zip backups
            val importBackupLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.OpenDocument()
            ) { uri: Uri? ->
                if (uri != null) {
                    val fileName = resolveDisplayFileName(uri)
                    readerViewModel.importBackupFromUri(uri, fileName)
                }
            }

            // Android SAF file creator for exporting real GZIP-compressed .tachibk backups
            val exportBackupLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.CreateDocument("application/octet-stream")
            ) { uri: Uri? ->
                if (uri != null) {
                    readerViewModel.exportBackupToUri(uri)
                }
            }

            WebReaderTheme(amoledDarkMode = uiState.amoledDarkMode) {
                WebReaderAppRoot(
                    viewModel = readerViewModel,
                    onRequestImportBackup = {
                        importBackupLauncher.launch(arrayOf("*/*"))
                    },
                    onRequestExportBackup = {
                        exportBackupLauncher.launch("webreader_backup.tachibk")
                    }
                )
            }
        }
    }

    private fun extractIncomingUrl(intent: Intent?): String? {
        if (intent == null) return null
        return when (intent.action) {
            Intent.ACTION_VIEW -> intent.dataString
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)
            else -> null
        }
    }

    private fun resolveDisplayFileName(uri: Uri): String {
        return runCatching {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex >= 0 && cursor.moveToFirst()) {
                    cursor.getString(nameIndex)
                } else null
            }
        }.getOrNull() ?: uri.lastPathSegment ?: "backup.tachibk"
    }
}

@Composable
fun WebReaderAppRoot(
    viewModel: WebReaderViewModel,
    onRequestImportBackup: () -> Unit,
    onRequestExportBackup: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedBottomTab by rememberSaveable { mutableIntStateOf(0) }
    var showAddWebsiteDialog by rememberSaveable { mutableStateOf(false) }

    // System Back Button priority handling
    BackHandler(
        enabled = uiState.activeReadingChapter != null ||
            uiState.activeWebViewUrl != null ||
            uiState.activeMangaDetail != null
    ) {
        when {
            uiState.activeReadingChapter != null -> viewModel.closeReader()
            uiState.activeWebViewUrl != null -> viewModel.closeInAppWebView()
            uiState.activeMangaDetail != null -> viewModel.closeMangaDetail()
        }
    }

    if (showAddWebsiteDialog) {
        AddCustomWebsiteDialog(
            onDismiss = { showAddWebsiteDialog = false },
            onConfirmAdd = { name, url ->
                showAddWebsiteDialog = false
                viewModel.addCustomWebsite(name, url)
                selectedBottomTab = 1
            }
        )
    }

    // Full-screen overlays take priority when reading a chapter, browsing via WebView, or viewing series details
    when {
        uiState.activeReadingChapter != null && uiState.activeReadingManga != null -> {
            NativeComicReaderScreen(
                uiState = uiState,
                onCloseReader = { viewModel.closeReader() },
                onCycleReaderMode = { viewModel.cycleReaderMode() },
                onUpdateCurrentPage = { viewModel.updateReaderPage(it) },
                onTogglePageBookmark = { viewModel.toggleCurrentPageBookmark() },
                onSwitchChapter = { next -> viewModel.switchToAdjacentChapter(next) },
                onFallbackToWebView = { url, title ->
                    viewModel.closeReader()
                    viewModel.openInAppWebView(url, title)
                }
            )
        }
        uiState.activeWebViewUrl != null -> {
            InAppWebViewReaderScreen(
                url = uiState.activeWebViewUrl ?: "",
                title = uiState.activeWebViewTitle,
                adBlockEnabled = uiState.adBlockEnabled,
                onClose = { viewModel.closeInAppWebView() },
                onExtractPagesToNativeReader = { pageUrl, pageTitle, imageUrls ->
                    viewModel.launchExtractedWebPagesInNativeReader(pageUrl, pageTitle, imageUrls)
                }
            )
        }
        uiState.activeMangaDetail != null -> {
            val detail = uiState.activeMangaDetail!!
            MangaDetailSheetScreen(
                manga = detail,
                isLoading = uiState.isDetailLoading,
                statusMessage = uiState.detailStatusMessage,
                onBack = { viewModel.closeMangaDetail() },
                onToggleSavedInLibrary = { viewModel.toggleSavedInLibrary(detail) },
                onToggleFavorite = { viewModel.toggleFavorite(detail) },
                onRefreshChapters = { viewModel.openMangaDetail(detail) },
                onOpenChapter = { chapter -> viewModel.openChapterInReader(detail, chapter) },
                onDownloadChapter = { chapter -> viewModel.toggleChapterDownload(detail, chapter) },
                onOpenInWebView = { url, title -> viewModel.openInAppWebView(url, title) }
            )
        }
        else -> {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    val navItemColors = NavigationBarItemDefaults.colors(
                        selectedIconColor = WebReaderPalette.AccentSky,
                        selectedTextColor = WebReaderPalette.AccentSky,
                        indicatorColor = WebReaderPalette.PrimaryBlue.copy(alpha = 0.24f),
                        unselectedIconColor = WebReaderPalette.TextMuted,
                        unselectedTextColor = WebReaderPalette.TextMuted
                    )
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 8.dp
                    ) {
                        NavigationBarItem(
                            selected = selectedBottomTab == 0,
                            onClick = { selectedBottomTab = 0 },
                            icon = { Icon(Icons.Default.CollectionsBookmark, contentDescription = "Library") },
                            label = {
                                Text(
                                    text = "Library",
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontWeight = if (selectedBottomTab == 0) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = navItemColors
                        )
                        NavigationBarItem(
                            selected = selectedBottomTab == 1,
                            onClick = { selectedBottomTab = 1 },
                            icon = { Icon(Icons.Default.Explore, contentDescription = "Sources") },
                            label = {
                                Text(
                                    text = "Sources",
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontWeight = if (selectedBottomTab == 1) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = navItemColors
                        )
                        NavigationBarItem(
                            selected = selectedBottomTab == 2,
                            onClick = { selectedBottomTab = 2 },
                            icon = { Icon(Icons.Default.History, contentDescription = "Activity") },
                            label = {
                                Text(
                                    text = "Activity",
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontWeight = if (selectedBottomTab == 2) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = navItemColors
                        )
                        NavigationBarItem(
                            selected = selectedBottomTab == 3,
                            onClick = { selectedBottomTab = 3 },
                            icon = { Icon(Icons.Default.SettingsBackupRestore, contentDescription = "Backup & Settings") },
                            label = {
                                Text(
                                    text = "Settings",
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontWeight = if (selectedBottomTab == 3) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = navItemColors
                        )
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (selectedBottomTab) {
                        0 -> LibraryTabScreen(
                            uiState = uiState,
                            onSelectCategory = { viewModel.selectCategory(it) },
                            onSearchQueryChange = { viewModel.updateLibrarySearch(it) },
                            onToggleStarterCatalog = { viewModel.toggleStarterCatalogView(it) },
                            onToggleFavoritesOnly = { viewModel.toggleFavoritesOnlyFilter(it) },
                            onToggleUnreadOnly = { viewModel.toggleUnreadOnlyFilter(it) },
                            onToggleDownloadedOnly = { viewModel.toggleDownloadedOnlyFilter(it) },
                            onSelectStatusFilter = { viewModel.selectStatusFilter(it) },
                            onSelectLanguageFilter = { viewModel.selectLanguageFilter(it) },
                            onSelectSortOption = { viewModel.selectSortOption(it) },
                            onResetFilters = { viewModel.resetLibraryFilters() },
                            onOpenMangaDetail = { viewModel.openMangaDetail(it) },
                            onToggleSavedInLibrary = { viewModel.toggleSavedInLibrary(it) },
                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                            onRequestImportBackup = onRequestImportBackup,
                            onOpenAddWebsiteDialog = { showAddWebsiteDialog = true },
                            onSwitchToBrowseTab = { selectedBottomTab = 1 }
                        )
                        1 -> BrowseSourcesTabScreen(
                            uiState = uiState,
                            onSelectSource = { viewModel.selectSource(it) },
                            onQueryChange = { viewModel.updateBrowseQuery(it) },
                            onExecuteSearch = { viewModel.browseActiveSource(it) },
                            onOpenMangaDetail = { viewModel.openMangaDetail(it) },
                            onToggleSavedInLibrary = { viewModel.toggleSavedInLibrary(it) },
                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                            onOpenSourceInWebView = { site ->
                                viewModel.openInAppWebView(site.baseUrl, site.name)
                            },
                            onOpenAddWebsiteDialog = { showAddWebsiteDialog = true }
                        )
                        2 -> HistoryAndBookmarksTabScreen(
                            uiState = uiState,
                            onResumeHistoryItem = { rec ->
                                val matchedManga = (uiState.savedLibrarySeries + uiState.starterCatalogSeries)
                                    .find { it.id == rec.mangaId }
                                    ?: MangaSeries(
                                        id = rec.mangaId,
                                        sourceId = rec.sourceId,
                                        sourceName = rec.sourceName,
                                        title = rec.mangaTitle,
                                        author = rec.sourceName,
                                        description = "",
                                        mangaUrl = rec.chapterUrl,
                                        coverUrl = rec.mangaCoverUrl
                                    )
                                val chapter = ChapterItem(
                                    id = rec.chapterId,
                                    mangaId = rec.mangaId,
                                    title = rec.chapterTitle,
                                    number = 1f,
                                    url = rec.chapterUrl
                                )
                                viewModel.openChapterInReader(matchedManga, chapter, rec.lastPageIndex)
                            },
                            onOpenBookmarkItem = { bm ->
                                val matchedManga = (uiState.savedLibrarySeries + uiState.starterCatalogSeries)
                                    .find { it.id == bm.mangaId }
                                    ?: MangaSeries(
                                        id = bm.mangaId,
                                        sourceId = "mangadex",
                                        sourceName = "Saved Bookmark",
                                        title = bm.mangaTitle,
                                        author = "",
                                        description = "",
                                        mangaUrl = bm.chapterUrl,
                                        coverUrl = bm.pageImageUrl
                                    )
                                val chapter = ChapterItem(
                                    id = bm.chapterId,
                                    mangaId = bm.mangaId,
                                    title = bm.chapterTitle,
                                    number = 1f,
                                    url = bm.chapterUrl
                                )
                                viewModel.openChapterInReader(matchedManga, chapter, bm.pageIndex)
                            },
                            onRemoveBookmark = { viewModel.removePageBookmark(it) },
                            onClearHistory = { viewModel.clearReadingHistory() },
                            onOpenChapterUpdate = { series, chapter ->
                                viewModel.openChapterInReader(series, chapter, 0)
                            }
                        )
                        else -> BackupAndSettingsTabScreen(
                            uiState = uiState,
                            onRequestImportBackup = onRequestImportBackup,
                            onRequestExportBackup = onRequestExportBackup,
                            onOpenAddWebsiteDialog = { showAddWebsiteDialog = true },
                            onSetAdBlock = { viewModel.setAdBlockEnabled(it) },
                            onSetDataSaver = { viewModel.setDataSaverEnabled(it) },
                            onSetAmoledDark = { viewModel.setAmoledDarkMode(it) },
                            onSetDefaultReaderMode = { viewModel.setDefaultReaderMode(it) },
                            onClearImageCache = { viewModel.clearDiskImageCache() }
                        )
                    }

                    // Non-intrusive Status Banner Snackbar at bottom
                    uiState.statusBannerMessage?.let { msg ->
                        Snackbar(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .padding(12.dp),
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = MaterialTheme.colorScheme.onSurface,
                            action = {
                                TextButton(onClick = { viewModel.clearStatusBanner() }) {
                                    Text("OK", color = WebReaderPalette.AccentSky, style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        ) {
                            Text(text = msg, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
