package com.webreader.app.model

/**
 * Core Domain Models for WebReader v2.2
 * Supports direct extension-free reading, live HTML/JSON scraping,
 * custom user websites, separated saved-library vs. favorites state,
 * and standard Tachiyomi (.tachibk / .proto.gz) backups.
 */

enum class SourceParserType(val displayName: String) {
    MANGADEX_API("MangaDex Official API v5"),
    MADARA("Madara WordPress Engine"),
    MANGATOWN("MangaTown HTML Parser"),
    BATOTO("Bato.to Mirror Engine"),
    ASURA("Asura Scans Engine"),
    CUSTOM_SMART("Smart Comic & WebView Extractor")
}

enum class ReaderMode(val label: String, val shortTag: String) {
    WEBTOON("Vertical Webtoon Scroll", "Webtoon"),
    LEFT_TO_RIGHT("Paged (Left to Right)", "L -> R"),
    RIGHT_TO_LEFT("Manga Paged (Right to Left)", "R -> L"),
    AUTO("Smart Auto-Detect", "Auto")
}

enum class LibraryCollectionFilter(val label: String) {
    SAVED_LIBRARY("Saved Library"),
    FAVORITES_ONLY("Favorites ★"),
    STARTER_CATALOG("All Catalog")
}

enum class LibrarySortOption(val label: String) {
    LAST_UPDATED("Recent Activity"),
    ALPHABETICAL("Title (A–Z)"),
    UNREAD_COUNT("Most Unread")
}

data class MangaSourceSite(
    val id: String,
    val tachiyomiSourceId: Long,
    val name: String,
    val baseUrl: String,
    val mirrors: List<String> = listOf(baseUrl),
    val language: String = "EN",
    val parserType: SourceParserType,
    val defaultReaderMode: ReaderMode = ReaderMode.WEBTOON,
    val isPinnedFavorite: Boolean = true,
    val isBuiltIn: Boolean = true,
    val accentColorHex: Long = 0xFF3B82F6
)

data class ChapterItem(
    val id: String,
    val mangaId: String,
    val title: String,
    val number: Float,
    val url: String,
    val uploadDateText: String = "Recently",
    val scanlator: String = "",
    val isRead: Boolean = false,
    val isBookmarked: Boolean = false,
    val lastPageRead: Int = 0,
    val isDownloaded: Boolean = false,
    val pageUrls: List<String> = emptyList()
)

data class MangaSeries(
    val id: String,
    val sourceId: String,
    val sourceName: String,
    val title: String,
    val author: String,
    val artist: String = "",
    val description: String,
    val status: String = "Ongoing",
    val genres: List<String> = emptyList(),
    val mangaUrl: String,
    val coverUrl: String,
    val coverColorHex: Long = 0xFF2563EB,
    val isSavedInLibrary: Boolean = false,
    val isFavorite: Boolean = false,
    val categoryName: String = "All",
    val preferredReaderMode: ReaderMode = ReaderMode.AUTO,
    val chapters: List<ChapterItem> = emptyList(),
    val dateAdded: Long = System.currentTimeMillis(),
    val lastReadAt: Long = 0L
) {
    val unreadCount: Int
        get() = chapters.count { !it.isRead }

    val downloadedCount: Int
        get() = chapters.count { it.isDownloaded }

    val latestChapterTitle: String
        get() = chapters.firstOrNull()?.title ?: "Tap to load live chapters"
}

data class ReadingHistoryRecord(
    val id: String,
    val mangaId: String,
    val mangaTitle: String,
    val mangaCoverUrl: String,
    val sourceId: String,
    val sourceName: String,
    val chapterId: String,
    val chapterTitle: String,
    val chapterUrl: String,
    val lastPageIndex: Int,
    val timestampMs: Long
)

data class PageBookmarkItem(
    val id: String,
    val mangaId: String,
    val mangaTitle: String,
    val chapterId: String,
    val chapterTitle: String,
    val chapterUrl: String,
    val pageIndex: Int,
    val pageImageUrl: String,
    val createdAtMs: Long
)

data class BackupImportSummary(
    val formatName: String,
    val importedMangaCount: Int,
    val importedChaptersCount: Int,
    val importedCategories: List<String>,
    val autoCreatedCustomSites: List<String>,
    val message: String
)
