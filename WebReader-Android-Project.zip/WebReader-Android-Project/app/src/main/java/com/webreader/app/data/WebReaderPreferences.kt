package com.webreader.app.data

import android.content.Context
import com.webreader.app.model.ChapterItem
import com.webreader.app.model.MangaSeries
import com.webreader.app.model.MangaSourceSite
import com.webreader.app.model.PageBookmarkItem
import com.webreader.app.model.ReaderMode
import com.webreader.app.model.ReadingHistoryRecord
import com.webreader.app.model.SourceParserType
import org.json.JSONArray
import org.json.JSONObject

/**
 * Local JSON-backed persistence for WebReader using Android SharedPreferences.
 * Persists saved library series (distinct from starred favorites), custom websites,
 * chapter read/bookmark states, reading history, and app settings across restarts.
 */
class WebReaderPreferences(context: Context) {

    private val prefs = context.getSharedPreferences("webreader_v2_prefs", Context.MODE_PRIVATE)

    var adBlockEnabled: Boolean
        get() = prefs.getBoolean("ad_block_enabled", true)
        set(value) = prefs.edit().putBoolean("ad_block_enabled", value).apply()

    var dataSaverEnabled: Boolean
        get() = prefs.getBoolean("data_saver_enabled", false)
        set(value) = prefs.edit().putBoolean("data_saver_enabled", value).apply()

    var amoledDarkMode: Boolean
        get() = prefs.getBoolean("amoled_dark_mode", true)
        set(value) = prefs.edit().putBoolean("amoled_dark_mode", value).apply()

    var defaultReaderMode: ReaderMode
        get() {
            val raw = prefs.getString("default_reader_mode", ReaderMode.WEBTOON.name) ?: ReaderMode.WEBTOON.name
            return runCatching { ReaderMode.valueOf(raw) }.getOrDefault(ReaderMode.WEBTOON)
        }
        set(value) = prefs.edit().putString("default_reader_mode", value.name).apply()

    fun saveCustomSources(sites: List<MangaSourceSite>) {
        val arr = JSONArray()
        sites.filter { !it.isBuiltIn }.forEach { site ->
            arr.put(
                JSONObject().apply {
                    put("id", site.id)
                    put("tachiyomiSourceId", site.tachiyomiSourceId)
                    put("name", site.name)
                    put("baseUrl", site.baseUrl)
                    put("language", site.language)
                    put("accentColorHex", site.accentColorHex)
                }
            )
        }
        prefs.edit().putString("custom_sources_json", arr.toString()).apply()
    }

    fun loadCustomSources(): List<MangaSourceSite> {
        val raw = prefs.getString("custom_sources_json", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            val list = mutableListOf<MangaSourceSite>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val baseUrl = obj.optString("baseUrl")
                if (baseUrl.isBlank()) continue
                list.add(
                    MangaSourceSite(
                        id = obj.optString("id", "custom_$i"),
                        tachiyomiSourceId = obj.optLong("tachiyomiSourceId", 80000L + i),
                        name = obj.optString("name", "Custom Site"),
                        baseUrl = baseUrl,
                        mirrors = listOf(baseUrl),
                        language = obj.optString("language", "EN"),
                        parserType = SourceParserType.CUSTOM_SMART,
                        defaultReaderMode = ReaderMode.AUTO,
                        isPinnedFavorite = true,
                        isBuiltIn = false,
                        accentColorHex = obj.optLong("accentColorHex", 0xFF0EA5E9)
                    )
                )
            }
            list
        }.getOrDefault(emptyList())
    }

    fun saveSavedLibrarySeries(seriesList: List<MangaSeries>) {
        val arr = JSONArray()
        seriesList.filter { it.isSavedInLibrary || it.isFavorite }.take(500).forEach { s ->
            val chArr = JSONArray()
            s.chapters.take(300).forEach { ch ->
                chArr.put(
                    JSONObject().apply {
                        put("id", ch.id)
                        put("title", ch.title)
                        put("number", ch.number.toDouble())
                        put("url", ch.url)
                        put("uploadDateText", ch.uploadDateText)
                        put("scanlator", ch.scanlator)
                        put("isRead", ch.isRead)
                        put("isBookmarked", ch.isBookmarked)
                        put("lastPageRead", ch.lastPageRead)
                        put("isDownloaded", ch.isDownloaded)
                    }
                )
            }
            val genresArr = JSONArray()
            s.genres.forEach { genresArr.put(it) }

            arr.put(
                JSONObject().apply {
                    put("id", s.id)
                    put("sourceId", s.sourceId)
                    put("sourceName", s.sourceName)
                    put("title", s.title)
                    put("author", s.author)
                    put("artist", s.artist)
                    put("description", s.description)
                    put("status", s.status)
                    put("genres", genresArr)
                    put("mangaUrl", s.mangaUrl)
                    put("coverUrl", s.coverUrl)
                    put("coverColorHex", s.coverColorHex)
                    put("isSavedInLibrary", s.isSavedInLibrary || s.isFavorite)
                    put("isFavorite", s.isFavorite)
                    put("categoryName", s.categoryName)
                    put("preferredReaderMode", s.preferredReaderMode.name)
                    put("chapters", chArr)
                }
            )
        }
        prefs.edit().putString("saved_library_json", arr.toString()).apply()
    }

    fun loadSavedLibrarySeries(): List<MangaSeries> {
        val raw = prefs.getString("saved_library_json", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            val list = mutableListOf<MangaSeries>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val id = obj.optString("id")
                if (id.isBlank()) continue

                val chList = mutableListOf<ChapterItem>()
                val chArr = obj.optJSONArray("chapters") ?: JSONArray()
                for (j in 0 until chArr.length()) {
                    val c = chArr.optJSONObject(j) ?: continue
                    chList.add(
                        ChapterItem(
                            id = c.optString("id", "${id}_ch_$j"),
                            mangaId = id,
                            title = c.optString("title", "Chapter ${j + 1}"),
                            number = c.optDouble("number", (j + 1).toDouble()).toFloat(),
                            url = c.optString("url", ""),
                            uploadDateText = c.optString("uploadDateText", "Saved"),
                            scanlator = c.optString("scanlator", ""),
                            isRead = c.optBoolean("isRead", false),
                            isBookmarked = c.optBoolean("isBookmarked", false),
                            lastPageRead = c.optInt("lastPageRead", 0),
                            isDownloaded = c.optBoolean("isDownloaded", false)
                        )
                    )
                }

                val genresList = mutableListOf<String>()
                val gArr = obj.optJSONArray("genres") ?: JSONArray()
                for (k in 0 until gArr.length()) {
                    val g = gArr.optString(k)
                    if (g.isNotBlank()) genresList.add(g)
                }

                val modeName = obj.optString("preferredReaderMode", ReaderMode.AUTO.name)
                val isFav = obj.optBoolean("isFavorite", false)
                val isSaved = obj.optBoolean("isSavedInLibrary", true)
                list.add(
                    MangaSeries(
                        id = id,
                        sourceId = obj.optString("sourceId", "mangadex"),
                        sourceName = obj.optString("sourceName", "MangaDex"),
                        title = obj.optString("title", "Untitled"),
                        author = obj.optString("author", "Unknown"),
                        artist = obj.optString("artist", ""),
                        description = obj.optString("description", ""),
                        status = obj.optString("status", "Ongoing"),
                        genres = genresList,
                        mangaUrl = obj.optString("mangaUrl", ""),
                        coverUrl = obj.optString("coverUrl", ""),
                        coverColorHex = obj.optLong("coverColorHex", 0xFF2563EB),
                        isSavedInLibrary = isSaved || isFav,
                        isFavorite = isFav,
                        categoryName = obj.optString("categoryName", "All"),
                        preferredReaderMode = runCatching { ReaderMode.valueOf(modeName) }.getOrDefault(ReaderMode.AUTO),
                        chapters = chList
                    )
                )
            }
            list
        }.getOrDefault(emptyList())
    }

    fun saveHistory(records: List<ReadingHistoryRecord>) {
        val arr = JSONArray()
        records.take(100).forEach { r ->
            arr.put(
                JSONObject().apply {
                    put("id", r.id)
                    put("mangaId", r.mangaId)
                    put("mangaTitle", r.mangaTitle)
                    put("mangaCoverUrl", r.mangaCoverUrl)
                    put("sourceId", r.sourceId)
                    put("sourceName", r.sourceName)
                    put("chapterId", r.chapterId)
                    put("chapterTitle", r.chapterTitle)
                    put("chapterUrl", r.chapterUrl)
                    put("lastPageIndex", r.lastPageIndex)
                    put("timestampMs", r.timestampMs)
                }
            )
        }
        prefs.edit().putString("history_json", arr.toString()).apply()
    }

    fun loadHistory(): List<ReadingHistoryRecord> {
        val raw = prefs.getString("history_json", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            val list = mutableListOf<ReadingHistoryRecord>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                list.add(
                    ReadingHistoryRecord(
                        id = o.optString("id"),
                        mangaId = o.optString("mangaId"),
                        mangaTitle = o.optString("mangaTitle"),
                        mangaCoverUrl = o.optString("mangaCoverUrl"),
                        sourceId = o.optString("sourceId"),
                        sourceName = o.optString("sourceName"),
                        chapterId = o.optString("chapterId"),
                        chapterTitle = o.optString("chapterTitle"),
                        chapterUrl = o.optString("chapterUrl"),
                        lastPageIndex = o.optInt("lastPageIndex", 0),
                        timestampMs = o.optLong("timestampMs", System.currentTimeMillis())
                    )
                )
            }
            list
        }.getOrDefault(emptyList())
    }

    fun saveBookmarks(bookmarks: List<PageBookmarkItem>) {
        val arr = JSONArray()
        bookmarks.take(200).forEach { b ->
            arr.put(
                JSONObject().apply {
                    put("id", b.id)
                    put("mangaId", b.mangaId)
                    put("mangaTitle", b.mangaTitle)
                    put("chapterId", b.chapterId)
                    put("chapterTitle", b.chapterTitle)
                    put("chapterUrl", b.chapterUrl)
                    put("pageIndex", b.pageIndex)
                    put("pageImageUrl", b.pageImageUrl)
                    put("createdAtMs", b.createdAtMs)
                }
            )
        }
        prefs.edit().putString("bookmarks_json", arr.toString()).apply()
    }

    fun loadBookmarks(): List<PageBookmarkItem> {
        val raw = prefs.getString("bookmarks_json", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            val list = mutableListOf<PageBookmarkItem>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                list.add(
                    PageBookmarkItem(
                        id = o.optString("id"),
                        mangaId = o.optString("mangaId"),
                        mangaTitle = o.optString("mangaTitle"),
                        chapterId = o.optString("chapterId"),
                        chapterTitle = o.optString("chapterTitle"),
                        chapterUrl = o.optString("chapterUrl"),
                        pageIndex = o.optInt("pageIndex", 0),
                        pageImageUrl = o.optString("pageImageUrl"),
                        createdAtMs = o.optLong("createdAtMs", System.currentTimeMillis())
                    )
                )
            }
            list
        }.getOrDefault(emptyList())
    }
}
