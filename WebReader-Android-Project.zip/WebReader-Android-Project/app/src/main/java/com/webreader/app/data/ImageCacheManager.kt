package com.webreader.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import android.webkit.CookieManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest

/**
 * Production-grade two-tier (Memory LruCache + Disk Cache) Manga Cover & Comic Page Loader.
 * Includes automatic Referer header injection, WebView CookieManager synchronization,
 * and automatic fallback to the wsrv.nl image proxy when hotlink protection or Cloudflare blocks direct image requests.
 */
object ImageCacheManager {

    private const val MOBILE_USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

    private val memoryCache: LruCache<String, Bitmap> = object : LruCache<String, Bitmap>(32 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int {
            return (value.byteCount / 1024).coerceAtLeast(1)
        }
    }

    @Volatile
    private var diskCacheDir: File? = null

    fun init(context: Context) {
        if (diskCacheDir == null) {
            val dir = File(context.cacheDir, "webreader_image_cache")
            if (!dir.exists()) {
                dir.mkdirs()
            }
            diskCacheDir = dir
        }
    }

    fun clearDiskCache() {
        memoryCache.evictAll()
        diskCacheDir?.listFiles()?.forEach { file ->
            runCatching { file.delete() }
        }
    }

    suspend fun loadBitmap(imageUrl: String, referer: String = ""): Bitmap? {
        val cleanUrl = imageUrl.trim()
        if (cleanUrl.isEmpty() || !cleanUrl.startsWith("http")) return null

        val key = sha256Key(cleanUrl)
        memoryCache.get(key)?.let { return it }

        return withContext(Dispatchers.IO) {
            // 1. Check Disk Cache
            val diskFile = diskCacheDir?.let { File(it, "$key.img") }
            if (diskFile != null && diskFile.exists() && diskFile.length() > 128L) {
                val diskBytes = runCatching { diskFile.readBytes() }.getOrNull()
                if (diskBytes != null) {
                    val decoded = decodeSampledBitmap(diskBytes, maxDimension = 1800)
                    if (decoded != null) {
                        memoryCache.put(key, decoded)
                        return@withContext decoded
                    }
                }
            }

            // 2. Try Direct HTTP Download with Referer + WebView Cookies
            val effectiveReferer = referer.ifBlank { inferOriginReferer(cleanUrl) }
            val directBytes = downloadImageBytes(cleanUrl, effectiveReferer)
            if (directBytes != null && directBytes.size > 128) {
                val decoded = decodeSampledBitmap(directBytes, maxDimension = 1800)
                if (decoded != null) {
                    saveToDisk(diskFile, directBytes)
                    memoryCache.put(key, decoded)
                    return@withContext decoded
                }
            }

            // 3. Fallback to wsrv.nl hotlink/Cloudflare image proxy
            val encodedUrl = runCatching { URLEncoder.encode(cleanUrl, "UTF-8") }.getOrDefault("")
            if (encodedUrl.isNotBlank()) {
                val proxyUrl = "https://wsrv.nl/?url=$encodedUrl&n=-1"
                val proxyBytes = downloadImageBytes(proxyUrl, effectiveReferer)
                if (proxyBytes != null && proxyBytes.size > 128) {
                    val decoded = decodeSampledBitmap(proxyBytes, maxDimension = 1800)
                    if (decoded != null) {
                        saveToDisk(diskFile, proxyBytes)
                        memoryCache.put(key, decoded)
                        return@withContext decoded
                    }
                }
            }

            null
        }
    }

    private fun downloadImageBytes(urlString: String, referer: String): ByteArray? {
        var connection: HttpURLConnection? = null
        return try {
            val url = URL(urlString)
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 9000
                readTimeout = 12000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", MOBILE_USER_AGENT)
                setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8")
                if (referer.isNotBlank()) {
                    setRequestProperty("Referer", referer)
                }
                runCatching {
                    val cookies = CookieManager.getInstance().getCookie(urlString)
                    if (!cookies.isNullOrBlank()) {
                        setRequestProperty("Cookie", cookies)
                    }
                }
            }
            if (connection.responseCode !in 200..299) return null
            connection.inputStream.use { input ->
                val buffer = ByteArrayOutputStream()
                val chunk = ByteArray(8192)
                var read: Int
                while (input.read(chunk).also { read = it } != -1) {
                    buffer.write(chunk, 0, read)
                }
                buffer.toByteArray()
            }
        } catch (_: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }

    private fun decodeSampledBitmap(bytes: ByteArray, maxDimension: Int): Bitmap? {
        return try {
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, boundsOpts)
            if (boundsOpts.outWidth <= 0 || boundsOpts.outHeight <= 0) return null

            var sampleSize = 1
            while (
                boundsOpts.outWidth / sampleSize > maxDimension ||
                boundsOpts.outHeight / sampleSize > maxDimension * 2
            ) {
                sampleSize *= 2
            }

            val decodeOpts = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOpts)
        } catch (_: Exception) {
            null
        }
    }

    private fun saveToDisk(file: File?, bytes: ByteArray) {
        if (file == null) return
        runCatching {
            FileOutputStream(file).use { out ->
                out.write(bytes)
                out.flush()
            }
        }
    }

    private fun inferOriginReferer(url: String): String {
        return try {
            val uri = URI(url)
            "${uri.scheme}://${uri.host}/"
        } catch (_: Exception) {
            ""
        }
    }

    private fun sha256Key(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }.take(32)
    }
}
