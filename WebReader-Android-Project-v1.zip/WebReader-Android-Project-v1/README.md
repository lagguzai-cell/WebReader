# WebReader — 64-Bit Native Android Manga & Webtoon App (Tachiyomi + Kotatsu Combined)

**WebReader** (`com.webreader.app`) combines **Tachiyomi's** familiar library, reader, and `.tachibk` backup system with **Kotatsu's** built-in website parsers—specifically designed to install cleanly on **modern 64-bit Android 14 & Android 15 phones**.

## What's Built Inside WebReader

1. **Pre-Loaded Favorite Websites (No Extension APKs Needed)**:
   - **MangaEffect** (`https://mangaeffect.com` + `.org` / `.net` mirrors)
   - **ManhwaTop** (`https://manhwatop.com` + `.org` mirror)
   - **ManhuaTop** (`https://manhuatop.org` + `.com` mirror)
   - **MangaTown** (`https://www.mangatown.com`)
   - **MangaDex** (`https://mangadex.org` + REST API v5)
   - **Asura Scans** (`https://asuracomic.net` + `.us` / `.gg` mirrors)
   - **Bato.to** (`https://bato.to` + `batotoo.com` / `batotwo.com` / `batocomic.org` mirrors)
2. **Paste & Add Any Manga Website**:
   - Tap **"+ Site"** or **"Add Any Website / Paste Link"** on the **Websites** tab to paste any manga website or chapter link.
   - Includes a built-in **Ad-Blocking Browser** and **Smart Image Extractor** that strips pop-up ads and loads comic images straight into the native reader.
3. **Standard Tachiyomi Backup (`.tachibk` / `.proto.gz` / `.json`) & Kotatsu (`.zip`) Support**:
   - Open the **Backup** tab (or tap **`.tachibk`** on the Library screen) to import your existing Tachiyomi backup file.
   - Automatically restores your saved manga series, categories, chapters, and reading history, and creates custom sources for any extra websites in your backup.

---

## How to Get Your Installable `.apk` File (No Coding Needed!)

Because compiling an Android `.apk` requires Google's Android SDK tools in the cloud, this project includes an automated **1-Click GitHub Cloud APK Builder**:

### Option 1: Free 1-Click Cloud Build on GitHub (Easiest — No Software Installation)
1. Create a free account at [github.com](https://github.com) and click **New repository** (name it `WebReader`).
2. Unzip `WebReader-Android-Project.zip` on your phone or computer and upload all files inside it to your GitHub repository (make sure the `.github` folder is included).
3. Click the **Actions** tab at the top of your GitHub repository.
4. You will see **"Build WebReader 64-Bit Android APK"** running automatically (it takes about 2 minutes).
5. Once it shows a green checkmark, click the workflow run and download **`WebReader-64bit-Installable-APK`** at the bottom under **Artifacts**—unzip it and tap `app-debug.apk` on your phone to install!

### Option 2: Build Locally in Android Studio
1. Open the unzipped `WebReader-Android-Project` folder in **Android Studio**.
2. Wait for Gradle sync to finish, then click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. Your installable APK will be saved at `app/build/outputs/apk/debug/app-debug.apk`.
