package com.webreader.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.webreader.app.data.SourceCatalogEngine
import com.webreader.app.data.TachiyomiBackupEngine
import com.webreader.app.data.WebReaderPreferences
import com.webreader.app.model.AppThemePalette
import com.webreader.app.model.BackupImportSummary
import com.webreader.app.model.ChapterItem
import com.webreader.app.model.ColorFilterPreset
import com.webreader.app.model.MangaSeries
import com.webreader.app.model.MangaSourceSite
import com.webreader.app.model.PageBookmark
import com.webreader.app.model.ReaderMode
import com.webreader.app.model.ReadingHistoryRecord
import com.webreader.app.model.SourceParserType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class WebReaderUiState(
    val sources: List<MangaSourceSite> = emptyList(),
    val seriesList: List<MangaSeries> = emptyList(),
    val categories: List<String> = listOf("All", "Manhwa & Webtoons", "Manga", "Manhua", "Completed"),
    val selectedCategory: String = "All",
    val librarySearchQuery: String = "",
    val unreadOnlyFilter: Boolean = false,
    val downloadedOnlyFilter: Boolean = false,
    val activeSourceFilterId: String? = null,
    val globalSearchQuery: String = "",
    val historyRecords: List<ReadingHistoryRecord> = emptyList(),
    val bookmarks: List<PageBookmark> = emptyList(),
    val activeSeriesId: String? = null,
    val activeReaderChapterId: String? = null,
    val activeWebViewUrl: String? = null,
    val activeWebViewTitle: String = "",
    val defaultReaderMode: ReaderMode = ReaderMode.AUTO,
    val colorFilterPreset: ColorFilterPreset = ColorFilterPreset.NONE,
    val themePalette: AppThemePalette = AppThemePalette.TACHIYOMI_BLUE,
    val adBlockEnabled: Boolean = true,
    val autoMirrorSwitchEnabled: Boolean = true,
    val imageProxyEnabled: Boolean = true,
    val isLoadingWebsite: Boolean = false,
    val lastBackupSummary: BackupImportSummary? = null,
    val statusBannerMessage: String? = null
)

class WebReaderViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = WebReaderPreferences(application)
    private val _uiState = MutableStateFlow(WebReaderUiState())
    val uiState: StateFlow<WebReaderUiState> = _uiState.asStateFlow()

    init {
        val savedCustomSites = prefs.loadCustomSites()
        val initialSources = SourceCatalogEngine.defaultBuiltInSources + savedCustomSites
        val starterSeries = SourceCatalogEngine.starterCatalogSeries()
        val initialHistory = starterSeries.take(3).mapIndexed { index, series ->
            val ch = series.chapters.first()
            ReadingHistoryRecord(
                id = "init_hist_$index",
                mangaId = series.id,
                mangaTitle = series.title,
                sourceName = series.sourceName,
                chapterId = ch.id,
                chapterTitle = ch.title,
                pageIndex = ch.lastPageRead,
                timestamp = System.currentTimeMillis() - (index * 3600_000L),
                readDurationSeconds = 420 + (index * 180)
            )
        }

        _uiState.value = WebReaderUiState(
            sources = initialSources,
            seriesList = starterSeries,
            historyRecords = initialHistory,
            themePalette = prefs.getThemePalette(),
            adBlockEnabled = prefs.getAdBlockEnabled(),
            autoMirrorSwitchEnabled = prefs.getAutoMirrorEnabled(),
            imageProxyEnabled = prefs.getImageProxyEnabled()
        )
    }

    fun selectCategory(category: String) {
        _uiState.update { it.copy(selectedCategory = category) }
    }

    fun updateLibrarySearch(query: String) {
        _uiState.update { it.copy(librarySearchQuery = query) }
    }

    fun toggleUnreadOnlyFilter() {
        _uiState.update { it.copy(unreadOnlyFilter = !it.unreadOnlyFilter) }
    }

    fun toggleDownloadedOnlyFilter() {
        _uiState.update { it.copy(downloadedOnlyFilter = !it.downloadedOnlyFilter) }
    }

    fun updateGlobalSearch(query: String) {
        _uiState.update { it.copy(globalSearchQuery = query) }
    }

    fun selectBrowseSource(sourceId: String?) {
        _uiState.update { it.copy(activeSourceFilterId = sourceId) }
    }

    fun openSeriesDetails(seriesId: String) {
        _uiState.update { it.copy(activeSeriesId = seriesId) }
    }

    fun closeSeriesDetails() {
        _uiState.update { it.copy(activeSeriesId = null) }
    }

    fun openReader(seriesId: String, chapterId: String) {
        val state = _uiState.value
        val series = state.seriesList.find { it.id == seriesId } ?: return
        val chapter = series.chapters.find { it.id == chapterId } ?: series.chapters.firstOrNull() ?: return

        val newRecord = ReadingHistoryRecord(
            id = "hist_${System.currentTimeMillis()}",
            mangaId = series.id,
            mangaTitle = series.title,
            sourceName = series.sourceName,
            chapterId = chapter.id,
            chapterTitle = chapter.title,
            pageIndex = chapter.lastPageRead,
            timestamp = System.currentTimeMillis()
        )

        _uiState.update {
            it.copy(
                activeSeriesId = seriesId,
                activeReaderChapterId = chapter.id,
                historyRecords = listOf(newRecord) + it.historyRecords.filterNot { h -> h.chapterId == chapter.id }
            )
        }
    }

    fun closeReader() {
        _uiState.update { it.copy(activeReaderChapterId = null) }
    }

    fun openWebView(url: String, title: String) {
        val normalized = SourceCatalogEngine.normalizeWebsiteUrl(url)
        if (normalized.isNotBlank()) {
            _uiState.update { it.copy(activeWebViewUrl = normalized, activeWebViewTitle = title) }
        }
    }

    fun closeWebView() {
        _uiState.update { it.copy(activeWebViewUrl = null, activeWebViewTitle = "") }
    }

    fun toggleFavorite(seriesId: String) {
        _uiState.update { state ->
            val updated = state.seriesList.map { series ->
                if (series.id == seriesId) series.copy(isFavorite = !series.isFavorite) else series
            }
            state.copy(seriesList = updated)
        }
    }

    fun assignSeriesCategory(seriesId: String, categoryName: String) {
        _uiState.update { state ->
            val updatedCategories = if (categoryName in state.categories) state.categories else state.categories + categoryName
            val updatedSeries = state.seriesList.map { series ->
                if (series.id == seriesId) series.copy(categoryName = categoryName, isFavorite = true) else series
            }
            state.copy(
                categories = updatedCategories,
                seriesList = updatedSeries,
                statusBannerMessage = "Moved to category '$categoryName'."
            )
        }
    }

    fun addCustomCategory(name: String) {
        val clean = name.trim()
        if (clean.isBlank()) return
        _uiState.update { state ->
            if (clean in state.categories) state
            else state.copy(
                categories = state.categories + clean,
                statusBannerMessage = "Created category '$clean'."
            )
        }
    }

    fun markChapterRead(seriesId: String, chapterId: String, isRead: Boolean, lastPage: Int = 0) {
        _uiState.update { state ->
            val updated = state.seriesList.map { series ->
                if (series.id != seriesId) series
                else series.copy(
                    chapters = series.chapters.map { ch ->
                        if (ch.id == chapterId) ch.copy(isRead = isRead, lastPageRead = lastPage) else ch
                    }
                )
            }
            state.copy(seriesList = updated)
        }
    }

    fun toggleChapterDownload(seriesId: String, chapterId: String) {
        _uiState.update { state ->
            val updated = state.seriesList.map { series ->
                if (series.id != seriesId) series
                else series.copy(
                    chapters = series.chapters.map { ch ->
                        if (ch.id == chapterId) ch.copy(isDownloaded = !ch.isDownloaded) else ch
                    }
                )
            }
            state.copy(
                seriesList = updated,
                statusBannerMessage = "Updated offline chapter download queue."
            )
        }
    }

    fun downloadAllUnreadForSeries(seriesId: String) {
        _uiState.update { state ->
            val updated = state.seriesList.map { series ->
                if (series.id != seriesId) series
                else series.copy(
                    chapters = series.chapters.map { ch ->
                        if (!ch.isRead) ch.copy(isDownloaded = true) else ch
                    }
                )
            }
            state.copy(
                seriesList = updated,
                statusBannerMessage = "Queued all unread chapters for offline reading."
            )
        }
    }

    fun togglePageBookmark(seriesId: String, chapterId: String, pageIndex: Int) {
        val state = _uiState.value
        val series = state.seriesList.find { it.id == seriesId } ?: return
        val chapter = series.chapters.find { it.id == chapterId } ?: return
        val bookmarkId = "${chapterId}_p_$pageIndex"
        val exists = state.bookmarks.any { it.id == bookmarkId }

        val updatedBookmarks = if (exists) {
            state.bookmarks.filterNot { it.id == bookmarkId }
        } else {
            listOf(
                PageBookmark(
                    id = bookmarkId,
                    mangaId = series.id,
                    mangaTitle = series.title,
                    chapterId = chapter.id,
                    chapterTitle = chapter.title,
                    pageIndex = pageIndex,
                    note = "Page ${pageIndex + 1} of ${chapter.title}",
                    timestamp = System.currentTimeMillis()
                )
            ) + state.bookmarks
        }

        _uiState.update {
            it.copy(
                bookmarks = updatedBookmarks,
                statusBannerMessage = if (exists) "Removed page bookmark." else "Bookmarked Page ${pageIndex + 1}!"
            )
        }
    }

    fun setSeriesReaderMode(seriesId: String, mode: ReaderMode) {
        _uiState.update { state ->
            val updated = state.seriesList.map { s ->
                if (s.id == seriesId) s.copy(preferredReaderMode = mode) else s
            }
            state.copy(seriesList = updated, defaultReaderMode = mode)
        }
    }

    fun setColorFilter(preset: ColorFilterPreset) {
        _uiState.update { it.copy(colorFilterPreset = preset) }
    }

    fun setThemePalette(palette: AppThemePalette) {
        prefs.setThemePalette(palette)
        _uiState.update { it.copy(themePalette = palette) }
    }

    fun toggleAdBlocker(enabled: Boolean) {
        prefs.setAdBlockEnabled(enabled)
        _uiState.update { it.copy(adBlockEnabled = enabled) }
    }

    fun toggleAutoMirror(enabled: Boolean) {
        prefs.setAutoMirrorEnabled(enabled)
        _uiState.update { it.copy(autoMirrorSwitchEnabled = enabled) }
    }

    fun toggleImageProxy(enabled: Boolean) {
        prefs.setImageProxyEnabled(enabled)
        _uiState.update { it.copy(imageProxyEnabled = enabled) }
    }

    fun toggleSourcePinned(sourceId: String) {
        _uiState.update { state ->
            val updated = state.sources.map { s ->
                if (s.id == sourceId) s.copy(isPinnedFavorite = !s.isPinnedFavorite) else s
            }
            prefs.saveCustomSites(updated)
            state.copy(sources = updated)
        }
    }

    fun switchSourceMirror(sourceId: String) {
        _uiState.update { state ->
            val updated = state.sources.map { s ->
                if (s.id != sourceId || s.mirrors.size <= 1) s
                else {
                    val currentIndex = s.mirrors.indexOf(s.baseUrl)
                    val nextUrl = s.mirrors[(currentIndex + 1) % s.mirrors.size]
                    s.copy(baseUrl = nextUrl)
                }
            }
            state.copy(
                sources = updated,
                statusBannerMessage = "Switched active mirror domain for $sourceId."
            )
        }
    }

    /**
     * One-tap "Switch Site" (Kotatsu Alternatives + Tachiyomi Migration):
     * Migrates a manga series to another website while keeping all read chapter progress!
     */
    fun migrateSeriesToSource(seriesId: String, targetSource: MangaSourceSite) {
        _uiState.update { state ->
            val updated = state.seriesList.map { series ->
                if (series.id != seriesId) series
                else {
                    val slug = series.title.lowercase().replace(Regex("[^a-z0-9]+"), "-")
                    series.copy(
                        sourceId = targetSource.id,
                        sourceName = targetSource.name,
                        mangaUrl = "${targetSource.baseUrl}/manga/$slug",
                        preferredReaderMode = targetSource.defaultReaderMode,
                        chapters = series.chapters.map { ch ->
                            ch.copy(
                                url = "${targetSource.baseUrl}/manga/$slug/chapter-${ch.number.toInt()}",
                                scanlator = targetSource.name
                            )
                        }
                    )
                }
            }
            state.copy(
                seriesList = updated,
                statusBannerMessage = "Migrated series & reading progress to ${targetSource.name}!"
            )
        }
    }

    /**
     * Adds any user-supplied manga website (e.g., Bato.to mirror, MangaEffect, ManhwaTop, or any URL)
     * as a permanent source AND extracts/adds the manga series to the library.
     */
    fun addCustomWebsiteOrMangaUrl(
        rawName: String,
        rawUrl: String,
        openInReaderImmediately: Boolean = false
    ) {
        val cleanUrl = SourceCatalogEngine.normalizeWebsiteUrl(rawUrl)
        if (cleanUrl.isBlank()) {
            _uiState.update { it.copy(statusBannerMessage = "Please enter a valid website URL.") }
            return
        }

        val domainLabel = rawName.trim().ifBlank { SourceCatalogEngine.extractDomainLabel(cleanUrl) }
        val sourceId = "custom_${domainLabel.lowercase().replace(Regex("[^a-z0-9]+"), "")}"

        val uriHost = try {
            val parts = cleanUrl.split("/")
            if (parts.size >= 3) "${parts[0]}//${parts[2]}" else cleanUrl
        } catch (_: Exception) {
            cleanUrl
        }

        val currentSources = _uiState.value.sources
        val existingSource = currentSources.find {
            it.id == sourceId || cleanUrl.contains(it.baseUrl.removePrefix("https://").removePrefix("www."), ignoreCase = true)
        }

        val targetSource = existingSource ?: MangaSourceSite(
            id = sourceId,
            tachiyomiSourceId = sourceId.hashCode().toLong() and 0x7FFFFFFFL,
            name = domainLabel,
            baseUrl = uriHost,
            mirrors = listOf(uriHost),
            language = "EN",
            parserType = SourceParserType.CUSTOM_SMART,
            defaultReaderMode = ReaderMode.AUTO,
            isPinnedFavorite = true,
            isBuiltIn = false,
            accentColorHex = 0xFF0EA5E9
        )

        val updatedSources = if (existingSource == null) currentSources + targetSource else currentSources
        prefs.saveCustomSites(updatedSources)
        _uiState.update { it.copy(sources = updatedSources, isLoadingWebsite = true) }

        viewModelScope.launch {
            val fetchedResult = SourceCatalogEngine.fetchLiveWebsiteOrManga(cleanUrl, targetSource)
            fetchedResult.onSuccess { newSeries ->
                _uiState.update { state ->
                    val mergedSeries = listOf(newSeries) + state.seriesList.filterNot { it.mangaUrl == newSeries.mangaUrl }
                    state.copy(
                        seriesList = mergedSeries,
                        isLoadingWebsite = false,
                        activeSeriesId = if (openInReaderImmediately) newSeries.id else state.activeSeriesId,
                        activeReaderChapterId = if (openInReaderImmediately) newSeries.chapters.firstOrNull()?.id else state.activeReaderChapterId,
                        statusBannerMessage = "Added '${newSeries.title}' from ${targetSource.name}!"
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isLoadingWebsite = false,
                        statusBannerMessage = "Saved ${targetSource.name}: ${err.message ?: "Ready in WebView"}"
                    )
                }
            }
        }
    }

    /**
     * Creates a new series chapter from images extracted live inside the Ad-Blocking WebView.
     */
    fun saveExtractedWebViewImagesToReader(pageTitle: String, pageUrl: String, imageUrls: List<String>) {
        if (imageUrls.isEmpty()) {
            _uiState.update { it.copy(statusBannerMessage = "No comic strip images detected on this page yet.") }
            return
        }
        val domainName = SourceCatalogEngine.extractDomainLabel(pageUrl)
        val seriesId = "webview_${System.currentTimeMillis()}"
        val chapterId = "${seriesId}_ch_1"
        val chapter = ChapterItem(
            id = chapterId,
            mangaId = seriesId,
            title = pageTitle.ifBlank { "Extracted Chapter" },
            number = 1f,
            url = pageUrl,
            uploadDateText = "Extracted Live",
            scanlator = domainName,
            isRead = false,
            pageUrls = imageUrls
        )
        val newSeries = MangaSeries(
            id = seriesId,
            sourceId = "custom_${domainName.lowercase()}",
            sourceName = domainName,
            title = pageTitle.ifBlank { "$domainName Manga" },
            author = domainName,
            description = "Extracted ${imageUrls.size} comic images directly from $pageUrl.",
            status = "Ongoing",
            genres = listOf(domainName, "WebView Extracted"),
            mangaUrl = pageUrl,
            coverColorHex = 0xFF0EA5E9,
            isFavorite = true,
            categoryName = "All",
            preferredReaderMode = ReaderMode.WEBTOON,
            chapters = listOf(chapter)
        )
        _uiState.update { state ->
            state.copy(
                seriesList = listOf(newSeries) + state.seriesList,
                activeWebViewUrl = null,
                activeSeriesId = seriesId,
                activeReaderChapterId = chapterId,
                statusBannerMessage = "Loaded ${imageUrls.size} pages into the native reader!"
            )
        }
    }

    /**
     * Imports a Standard Tachiyomi (.tachibk / .proto.gz / .json) or Kotatsu (.zip) backup file.
     */
    fun importBackupFile(bytes: ByteArray, fileName: String) {
        val currentState = _uiState.value
        val result = TachiyomiBackupEngine.importBackupBytes(
            rawBytes = bytes,
            fileName = fileName,
            existingSources = currentState.sources
        )
        result.onSuccess { payload ->
            val mergedSources = (currentState.sources + payload.customSites).distinctBy { it.id }
            prefs.saveCustomSites(mergedSources)
            val existingUrls = currentState.seriesList.map { it.mangaUrl }.toSet()
            val newSeries = payload.seriesList.filterNot { it.mangaUrl in existingUrls }
            val mergedSeries = newSeries + currentState.seriesList
            val mergedCategories = (currentState.categories + payload.categories).distinct()
            val mergedHistory = (payload.historyRecords + currentState.historyRecords).distinctBy { it.id }

            _uiState.update {
                it.copy(
                    sources = mergedSources,
                    seriesList = mergedSeries,
                    categories = mergedCategories,
                    historyRecords = mergedHistory,
                    lastBackupSummary = payload.summary,
                    statusBannerMessage = payload.summary.message
                )
            }
        }.onFailure { err ->
            _uiState.update {
                it.copy(statusBannerMessage = "Backup import error: ${err.message ?: "Invalid format"}")
            }
        }
    }

    fun loadDemoTachiyomiBackup() {
        val sampleBytes = TachiyomiBackupEngine.generateSampleTachiyomiBackupBytes(_uiState.value.sources)
        importBackupFile(sampleBytes, "eu.kanade.tachiyomi_sample_backup.tachibk")
    }

    fun exportTachiyomiBackupBytes(): ByteArray {
        val state = _uiState.value
        return TachiyomiBackupEngine.exportTachiyomiProtoGz(
            seriesList = state.seriesList.filter { it.isFavorite },
            categories = state.categories,
            sources = state.sources
        )
    }

    fun clearBannerMessage() {
        _uiState.update { it.copy(statusBannerMessage = null) }
    }
}
