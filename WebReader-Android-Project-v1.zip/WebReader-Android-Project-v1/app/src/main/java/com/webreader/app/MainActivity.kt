package com.webreader.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.SettingsBackupRestore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.webreader.app.ui.WebReaderUiState
import com.webreader.app.ui.WebReaderViewModel
import com.webreader.app.ui.screens.AdFreeWebViewScreen
import com.webreader.app.ui.screens.BackupAndSettingsTabScreen
import com.webreader.app.ui.screens.BrowseAndWebsitesTabScreen
import com.webreader.app.ui.screens.HistoryAndBookmarksTabScreen
import com.webreader.app.ui.screens.LibraryTabScreen
import com.webreader.app.ui.screens.SeriesDetailScreen
import com.webreader.app.ui.screens.UnifiedReaderScreen
import com.webreader.app.ui.screens.UpdatesAndDownloadsTabScreen

class MainActivity : ComponentActivity() {

    private val viewModel: WebReaderViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Handle deep-link URLs if user opens a manga link from outside the app
        intent?.dataString?.takeIf { it.startsWith("http") }?.let { deepLinkUrl ->
            viewModel.addCustomWebsiteOrMangaUrl(
                rawName = "",
                rawUrl = deepLinkUrl,
                openInReaderImmediately = false
            )
        }

        setContent {
            val state by viewModel.uiState.collectAsState()
            val colorScheme = darkColorScheme(
                primary = Color(state.themePalette.primaryHex),
                secondary = Color(state.themePalette.secondaryHex),
                background = Color(0xFF0B1120),
                surface = Color(0xFF111827),
                surfaceVariant = Color(0xFF1E293B)
            )

            MaterialTheme(colorScheme = colorScheme) {
                WebReaderRootApp(
                    state = state,
                    viewModel = viewModel
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WebReaderRootApp(
    state: WebReaderUiState,
    viewModel: WebReaderViewModel
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var showAddWebsiteDialog by rememberSaveable { mutableStateOf(false) }

    // File Picker for importing .tachibk / .proto.gz / .json / .zip backups
    val importBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            val name = uri.lastPathSegment ?: "backup.tachibk"
            if (bytes != null) {
                viewModel.importBackupFile(bytes, name)
            }
        }
    }

    // File Saver for exporting .tachibk backups
    val exportBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/gzip")
    ) { uri: Uri? ->
        if (uri != null) {
            val bytes = viewModel.exportTachiyomiBackupBytes()
            context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
        }
    }

    LaunchedEffect(state.statusBannerMessage) {
        val msg = state.statusBannerMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearBannerMessage()
        }
    }

    // 1. Fullscreen Ad-Free WebView Mode
    val activeWebViewUrl = state.activeWebViewUrl
    if (!activeWebViewUrl.isNullOrBlank()) {
        AdFreeWebViewScreen(
            initialUrl = activeWebViewUrl,
            title = state.activeWebViewTitle,
            adBlockEnabled = state.adBlockEnabled,
            onClose = { viewModel.closeWebView() },
            onSaveSiteToCatalog = { title, url ->
                viewModel.addCustomWebsiteOrMangaUrl(title, url, openInReaderImmediately = false)
            },
            onExtractImagesToReader = { title, url, imgs ->
                viewModel.saveExtractedWebViewImagesToReader(title, url, imgs)
            }
        )
        return
    }

    // 2. Fullscreen Manga & Webtoon Reader Mode
    val activeSeries = state.seriesList.find { it.id == state.activeSeriesId }
    val activeChapter = activeSeries?.chapters?.find { it.id == state.activeReaderChapterId }
    if (activeSeries != null && activeChapter != null) {
        UnifiedReaderScreen(
            series = activeSeries,
            chapter = activeChapter,
            allSources = state.sources,
            bookmarks = state.bookmarks,
            colorFilterPreset = state.colorFilterPreset,
            onBack = { viewModel.closeReader() },
            onSelectChapter = { chId -> viewModel.openReader(activeSeries.id, chId) },
            onMarkReadProgress = { chId, isRead, lastPage ->
                viewModel.markChapterRead(activeSeries.id, chId, isRead, lastPage)
            },
            onTogglePageBookmark = { pageIdx ->
                viewModel.togglePageBookmark(activeSeries.id, activeChapter.id, pageIdx)
            },
            onChangeReaderMode = { mode ->
                viewModel.setSeriesReaderMode(activeSeries.id, mode)
            },
            onChangeColorFilter = { preset ->
                viewModel.setColorFilter(preset)
            },
            onSwitchSource = { targetSite ->
                viewModel.migrateSeriesToSource(activeSeries.id, targetSite)
            },
            onOpenInWebView = { url, title ->
                viewModel.openWebView(url, title)
            }
        )
        return
    }

    // 3. Series Details View
    if (activeSeries != null) {
        SeriesDetailScreen(
            series = activeSeries,
            categories = state.categories,
            allSources = state.sources,
            onBack = { viewModel.closeSeriesDetails() },
            onToggleFavorite = { viewModel.toggleFavorite(activeSeries.id) },
            onChangeCategory = { cat -> viewModel.assignSeriesCategory(activeSeries.id, cat) },
            onOpenReader = { chId -> viewModel.openReader(activeSeries.id, chId) },
            onToggleChapterDownload = { chId -> viewModel.toggleChapterDownload(activeSeries.id, chId) },
            onDownloadAllUnread = { viewModel.downloadAllUnreadForSeries(activeSeries.id) },
            onOpenInWebView = { url, title -> viewModel.openWebView(url, title) },
            onMigrateToSource = { targetSite -> viewModel.migrateSeriesToSource(activeSeries.id, targetSite) }
        )
        return
    }

    // 4. Main 5-Tab Scaffold
    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.LibraryBooks, contentDescription = null) },
                    label = { Text("Library") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Explore, contentDescription = null) },
                    label = { Text("Websites") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.CloudDownload, contentDescription = null) },
                    label = { Text("Updates") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.History, contentDescription = null) },
                    label = { Text("History") }
                )
                NavigationBarItem(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    icon = { Icon(Icons.Default.SettingsBackupRestore, contentDescription = null) },
                    label = { Text("Backup") }
                )
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (selectedTab) {
                0 -> LibraryTabScreen(
                    state = state,
                    onSelectCategory = { viewModel.selectCategory(it) },
                    onSearchQueryChange = { viewModel.updateLibrarySearch(it) },
                    onToggleUnreadOnly = { viewModel.toggleUnreadOnlyFilter() },
                    onToggleDownloadedOnly = { viewModel.toggleDownloadedOnlyFilter() },
                    onOpenSeries = { viewModel.openSeriesDetails(it) },
                    onOpenAddWebsiteDialog = { showAddWebsiteDialog = true },
                    onPickBackupFile = { importBackupLauncher.launch(arrayOf("*/*")) },
                    onAddCategory = { viewModel.addCustomCategory(it) }
                )
                1 -> BrowseAndWebsitesTabScreen(
                    state = state,
                    onSelectSource = { viewModel.selectBrowseSource(it) },
                    onGlobalSearchChange = { viewModel.updateGlobalSearch(it) },
                    onOpenSeries = { viewModel.openSeriesDetails(it) },
                    onOpenWebsiteBrowser = { url, title -> viewModel.openWebView(url, title) },
                    onOpenAddWebsiteDialog = { showAddWebsiteDialog = true },
                    onTogglePinSource = { viewModel.toggleSourcePinned(it) },
                    onSwitchSourceMirror = { viewModel.switchSourceMirror(it) }
                )
                2 -> UpdatesAndDownloadsTabScreen(
                    state = state,
                    onOpenReader = { sId, chId -> viewModel.openReader(sId, chId) },
                    onToggleDownload = { sId, chId -> viewModel.toggleChapterDownload(sId, chId) }
                )
                3 -> HistoryAndBookmarksTabScreen(
                    state = state,
                    onResumeChapter = { sId, chId -> viewModel.openReader(sId, chId) }
                )
                4 -> BackupAndSettingsTabScreen(
                    state = state,
                    onPickBackupFileToImport = { importBackupLauncher.launch(arrayOf("*/*")) },
                    onCreateBackupFileToExport = { exportBackupLauncher.launch("webreader_backup.tachibk") },
                    onLoadSampleTachiyomiBackup = { viewModel.loadDemoTachiyomiBackup() },
                    onSelectThemePalette = { viewModel.setThemePalette(it) },
                    onToggleAdBlocker = { viewModel.toggleAdBlocker(it) },
                    onToggleAutoMirror = { viewModel.toggleAutoMirror(it) },
                    onToggleImageProxy = { viewModel.toggleImageProxy(it) }
                )
            }
        }
    }

    if (showAddWebsiteDialog) {
        var siteNameInput by remember { mutableStateOf("") }
        var siteUrlInput by remember { mutableStateOf("https://") }

        val quickPresets = listOf(
            "MangaEffect" to "https://mangaeffect.com",
            "ManhwaTop" to "https://manhwatop.com",
            "ManhuaTop" to "https://manhuatop.org",
            "MangaTown" to "https://www.mangatown.com",
            "Bato.to" to "https://bato.to",
            "Asura Scans" to "https://asuracomic.net",
            "MangaDex" to "https://mangadex.org"
        )

        AlertDialog(
            onDismissRequest = { showAddWebsiteDialog = false },
            title = { Text("Add Any Manga Website or Series Link") },
            text = {
                Column {
                    Text(
                        text = "Paste any manga website domain or chapter link below (such as Bato.to, MangaEffect, ManhwaTop, ManhuaTop, MangaTown, or any other site):",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = siteNameInput,
                        onValueChange = { siteNameInput = it },
                        label = { Text("Website or Manga Name (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = siteUrlInput,
                        onValueChange = { siteUrlInput = it },
                        label = { Text("Website URL (https://...)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "Quick Fill Favorites:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        quickPresets.forEach { (presetName, presetUrl) ->
                            AssistChip(
                                onClick = {
                                    siteNameInput = presetName
                                    siteUrlInput = presetUrl
                                },
                                label = { Text(presetName) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = {
                            showAddWebsiteDialog = false
                            viewModel.openWebView(siteUrlInput, siteNameInput.ifBlank { "Manga Browser" })
                        }
                    ) {
                        Text("Open Browser")
                    }
                    Button(
                        onClick = {
                            showAddWebsiteDialog = false
                            viewModel.addCustomWebsiteOrMangaUrl(
                                rawName = siteNameInput,
                                rawUrl = siteUrlInput,
                                openInReaderImmediately = false
                            )
                        }
                    ) {
                        Text("Add to Library")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddWebsiteDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
