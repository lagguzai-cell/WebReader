package com.webreader.app.model

enum class SourceParserType(val label: String) {
    MADARA("Madara WordPress Engine"),
    MANGADEX_API("MangaDex REST API v5"),
    MANGATOWN("MangaTown HTML Parser"),
    BATOTO("Bato.to Multi-Mirror Parser"),
    ASURA("Asura Scans NextJS/HTML Parser"),
    CUSTOM_SMART("Smart Auto-Extractor + Ad-Free WebView")
}

enum class ReaderMode(val label: String, val description: String) {
    AUTO("Auto-Detect (Recommended)", "Webtoon vertical scroll for Manhwa/Manhua, Page-by-Page for Manga"),
    WEBTOON("Webtoon Continuous Scroll", "Smooth vertical strip scrolling for Manhwa & Manhua"),
    LEFT_TO_RIGHT("Left-to-Right Pager", "Standard comic book page flipping"),
    RIGHT_TO_LEFT("Right-to-Left Manga Pager", "Traditional Japanese manga page flipping"),
    DOUBLE_PAGE("Double-Page Spread", "Two pages side-by-side for tablets & landscape")
}

enum class ColorFilterPreset(val label: String) {
    NONE("Original Colors"),
    WARM_NIGHT("Eye-Care Warm Amber"),
    DIM_DARK("Dimmed Night Contrast"),
    GRAYSCALE("High-Contrast Monochrome")
}

enum class AppThemePalette(val label: String, val primaryHex: Long, val secondaryHex: Long) {
    TACHIYOMI_BLUE("Tachiyomi Classic Blue", 0xFF2563EB, 0xFF38BDF8),
    KOTATSU_EMERALD("Kotatsu Emerald", 0xFF059669, 0xFF34D399),
    MIDNIGHT_DUSK("Midnight Dusk Purple", 0xFF7C3AED, 0xFFA78BFA),
    CRIMSON_EMBER("Crimson Ember", 0xFFE11D48, 0xFFFB7185)
}

data class MangaSourceSite(
    val id: String,
    val tachiyomiSourceId: Long,
    val name: String,
    val baseUrl: String,
    val mirrors: List<String>,
    val language: String,
    val parserType: SourceParserType,
    val defaultReaderMode: ReaderMode,
    val isPinnedFavorite: Boolean = true,
    val isBuiltIn: Boolean = true,
    val accentColorHex: Long = 0xFF2563EB
)

data class ChapterItem(
    val id: String,
    val mangaId: String,
    val title: String,
    val number: Float,
    val url: String,
    val uploadDateText: String,
    val scanlator: String = "",
    val isRead: Boolean = false,
    val isBookmarked: Boolean = false,
    val isDownloaded: Boolean = false,
    val lastPageRead: Int = 0,
    val pageUrls: List<String> = emptyList()
)

data class PageBookmark(
    val id: String,
    val mangaId: String,
    val mangaTitle: String,
    val chapterId: String,
    val chapterTitle: String,
    val pageIndex: Int,
    val note: String,
    val timestamp: Long
)

data class ReadingHistoryRecord(
    val id: String,
    val mangaId: String,
    val mangaTitle: String,
    val sourceName: String,
    val chapterId: String,
    val chapterTitle: String,
    val pageIndex: Int,
    val timestamp: Long,
    val readDurationSeconds: Int = 180
)

data class MangaSeries(
    val id: String,
    val sourceId: String,
    val sourceName: String,
    val title: String,
    val author: String,
    val artist: String = "",
    val description: String,
    val status: String,
    val genres: List<String>,
    val mangaUrl: String,
    val coverColorHex: Long,
    val isFavorite: Boolean = false,
    val categoryName: String = "All",
    val preferredReaderMode: ReaderMode = ReaderMode.AUTO,
    val chapters: List<ChapterItem> = emptyList(),
    val dateAdded: Long = System.currentTimeMillis()
) {
    val unreadCount: Int
        get() = chapters.count { !it.isRead }

    val downloadedCount: Int
        get() = chapters.count { it.isDownloaded }
}

data class BackupImportSummary(
    val formatName: String,
    val importedMangaCount: Int,
    val importedChaptersCount: Int,
    val importedCategories: List<String>,
    val importedHistoryCount: Int,
    val autoCreatedCustomSites: List<String>,
    val message: String
)
