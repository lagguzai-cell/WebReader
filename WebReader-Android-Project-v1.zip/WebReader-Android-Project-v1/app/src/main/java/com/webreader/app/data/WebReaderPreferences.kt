package com.webreader.app.data

import android.content.Context
import com.webreader.app.model.AppThemePalette
import com.webreader.app.model.MangaSourceSite
import com.webreader.app.model.ReaderMode
import com.webreader.app.model.SourceParserType
import org.json.JSONArray
import org.json.JSONObject

class WebReaderPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("webreader_prefs", Context.MODE_PRIVATE)

    fun loadCustomSites(): List<MangaSourceSite> {
        val raw = prefs.getString("custom_sites_json", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { idx ->
                val obj = arr.optJSONObject(idx) ?: return@mapNotNull null
                val baseUrl = obj.optString("baseUrl")
                MangaSourceSite(
                    id = obj.optString("id"),
                    tachiyomiSourceId = obj.optLong("tachiyomiSourceId", idx + 90000L),
                    name = obj.optString("name"),
                    baseUrl = baseUrl,
                    mirrors = listOf(baseUrl),
                    language = obj.optString("language", "EN"),
                    parserType = SourceParserType.CUSTOM_SMART,
                    defaultReaderMode = ReaderMode.AUTO,
                    isPinnedFavorite = obj.optBoolean("isPinnedFavorite", true),
                    isBuiltIn = false,
                    accentColorHex = obj.optLong("accentColorHex", 0xFF0EA5E9)
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveCustomSites(sites: List<MangaSourceSite>) {
        val arr = JSONArray()
        sites.filter { !it.isBuiltIn }.forEach { site ->
            val obj = JSONObject().apply {
                put("id", site.id)
                put("tachiyomiSourceId", site.tachiyomiSourceId)
                put("name", site.name)
                put("baseUrl", site.baseUrl)
                put("language", site.language)
                put("isPinnedFavorite", site.isPinnedFavorite)
                put("accentColorHex", site.accentColorHex)
            }
            arr.put(obj)
        }
        prefs.edit().putString("custom_sites_json", arr.toString()).apply()
    }

    fun getThemePalette(): AppThemePalette {
        val name = prefs.getString("theme_palette", AppThemePalette.TACHIYOMI_BLUE.name)
        return AppThemePalette.entries.find { it.name == name } ?: AppThemePalette.TACHIYOMI_BLUE
    }

    fun setThemePalette(palette: AppThemePalette) {
        prefs.edit().putString("theme_palette", palette.name).apply()
    }

    fun getAdBlockEnabled(): Boolean = prefs.getBoolean("ad_block_enabled", true)
    fun setAdBlockEnabled(enabled: Boolean) = prefs.edit().putBoolean("ad_block_enabled", enabled).apply()

    fun getAutoMirrorEnabled(): Boolean = prefs.getBoolean("auto_mirror_enabled", true)
    fun setAutoMirrorEnabled(enabled: Boolean) = prefs.edit().putBoolean("auto_mirror_enabled", enabled).apply()

    fun getImageProxyEnabled(): Boolean = prefs.getBoolean("image_proxy_enabled", true)
    fun setImageProxyEnabled(enabled: Boolean) = prefs.edit().putBoolean("image_proxy_enabled", enabled).apply()
}
